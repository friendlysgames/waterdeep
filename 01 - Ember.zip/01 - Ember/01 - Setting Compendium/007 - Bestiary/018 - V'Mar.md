# V'Mar

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Once humanoids, these beings were warped into monstrous creatures. They may or not be winged but are almost always thin and disjointed monsters with maws a thin sharp teeth. They may also bear magical markings or visual indicators of Malae's magical curse that still affects them.