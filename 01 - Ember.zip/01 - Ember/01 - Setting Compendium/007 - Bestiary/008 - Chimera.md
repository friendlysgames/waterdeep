# Chimera

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Chimera are monstrous creatures, typically infused with Abyssal energy though some kinds are amalgamations of various natural creatures created by mages of Ember in the distant past. They are often violent, aggressive, and extremely dangerous monsters that are either territorial or predatory towards mortals.