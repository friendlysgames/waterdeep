# Vampyres

- 
Keywords: Blood, Death, Immortal

- 
Ember Type: Monster

- 
Type: Undead

Mortal ancestors on the World of Ember know a great deal about Vampyres from the tales and stories of Moiran refugees who fled the Evernight and from the continuing experience of the Lumek, who regularly encounter them during the cycles of Fire and death. This shared knowledge contains many truths but also a few misconceptions and exaggerations.

A Vampyre retains its appearance from life; it can appear extraordinarily hale and healthy, almost pristine, without marks, and the appearance of aging appears graceful and firm. This does not mean all Vampyres are youthful-looking, and their appearances range across the age ranges of every ancestry. This serene appearance can change dramatically on a whim, however, and when a Vampyre is hunting, or angry or upon command its facial features twist unnaturally, as its regular teeth extend and grow sharp, especially the canines that elongate dramatically. Often, this means a slight distortion of the entire jaw to fit the new row of more prominent, sharper teeth.

A Vampyre is said to have no heartbeat and requires blood from mortals to survive. This is primarily true from my own accounts, and Vampyres are undead in every sense of the word, but they do not require blood to survive and do eat and consume normal food types like bread and fruits when needed. Unfortunately, the transformation into a Vampyre has a dramatic mental effect and causes the vast majority of Vampyres to become extremely predatory. This results in them feeding and hunting mortals and consuming them. It's said that a Vampyre has an unending hunger for blood only, but in reality, some Vampyres only feel the need to kill and the thrill of the hunt, while others seek to consume flesh instead.

It's said that Vampyres are created by allowing a mortal to feed from them instead, offering their own tainted blood that transforms the mortal into an immortal monster. This is partly true, but the process is more complex and requires the original Vampyre to imbue a certain amount of its power into the process, which drains them for days or even months. Thus, despite what many believe, the act of creating more Vampyres is not performed regularly, and most Vampyres tend to avoid creating more of their kind unless a situation requires it.

Vampyrism is thought to be a curse upon the living and a curse specifically created to target and punish the Moiran people for some ancient folly or injustice. Surviving Moiran families believe this wholeheartedly despite some evidence to suggest that it may be a magical process created by some ancient being. Regardless of the origin, Vampyres are not only undead and immortal but are extremely powerful monsters and among the strongest undead. They can move incredibly quickly, with some mortals believing that they have an innate ability to teleport and move instantly through space. Vampyres possess greater physical strength than most mortals, and their skin cannot be pieced by ordinary weapons.

## Overview

Vampyres are monsters of blood and undeath. They feed upon the blood of mortal creatures and are considered malicious, evil, and utterly without remorse. They are rare outside of the Moiran lands in the south of the Aterican continent but can be found among many cultures preying upon the helpless. Most of their fearsome reputation comes from their first appearances in Ember around the time of the Evernight, and they are greatly feared by all mortals.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Among monsters and especially undead, Vampyres, are incredibly unusual in that they are not consumed by evil upon being inflicted by undeath. Vampyres are generally considered to be sane and possess free will from the monent the are transformed. Unfortunately, The majority lean towards evil due to their instinctual changes and desires that occur during the transformation process. Still, there are rare examples of Vampyres in Ember that have rejected evil in every form and fought against their nature or even combat their own kind and other undead.</p><p>It's not known precisely how or why Vampyre came into existence, but it's believed Elwin Davos is the original Vampyre that created all the others. Though some Vampyres dispute this and suggest that there were, in fact, several Vampyres at first that spread the curse.</p><h3 class="divider">Weaknesses</h3><p>Some people believe that Vampyres cannot stand the light of Lantyr and that sunlight somehow burns them. Unfortunately, this is untrue; Vampyres can stride through sunlight without damage or aversion. Despite what some think, they have no innate weaknesses to fire or silver either. Vampyres have very few actual weaknesses, and they are terrifying entities that, once they fixate on a hunt, can be single-minded and almost impossible to destroy.</p><p>The little-known but only true weakness of Vampyres is that they are repelled and extremely sensitive to Lifeforce. Lifeforce is often the origin of many holy spells used by clerics, priests, and druids, and it can greatly harm a Vampyre if used directly against them.</p><h3 class="divider">Known Vampyres</h3><ul><li><p>Elwin Davos</p></li><li><p>Menis Valegar</p></li><li><p>Amelia Naxan</p></li></ul>
</section>