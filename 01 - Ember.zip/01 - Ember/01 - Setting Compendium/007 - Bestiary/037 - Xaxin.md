# Xaxin

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Very little is known about the Xaxin, only that they are the dominant ancestry of the Undersurface of Ember and have remained so since Creation itself.