# Wyrms

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Wyrms are the mythical creatures that once populated the Order moon of Akon. Long-dead since the events of the Shattering, these enigmatic serpents gave rise to Ember's three species of Dragons.