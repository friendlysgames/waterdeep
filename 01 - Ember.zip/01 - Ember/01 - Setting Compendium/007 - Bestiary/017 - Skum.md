# Skum

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Skum are terrifying creatures that resemble a horrific blend of humanoid and fish. They are monsters that first appeared after the events of the Abyssal Shear, since then they have spread across the surface world of Ember like a malignant plague.