# Wargs

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Wargs are corrupted wolf like creatures that prowl dark forests and wild places of the world.