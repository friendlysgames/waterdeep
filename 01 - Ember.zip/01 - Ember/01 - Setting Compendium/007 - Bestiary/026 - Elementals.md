# Elementals

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Elementals are creatures of raw primeval power native to the Elemental Moons of the Cosmos (Aura, Akon, Cora, Mayis, Orbis, and Ragen) and the Inner Realms (Luxarum, Primordis, and Signara). Embodiments of the respective forces of these cosmic landscapes, elementals are as varied as they are unknowable — ranging in both size and power from the tiniest mote to the most colossal destructor, including the remarkably powerful Elemental Sages. Ultimately, the various Elemental Sovereigns of the cosmos are the supreme expression of a particular elemental force, and there is usually only one of these godlike beings in creation at any given point in time.