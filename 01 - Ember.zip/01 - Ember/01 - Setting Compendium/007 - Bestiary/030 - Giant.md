# Giant

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

"Giant" is a broad term that has various uses throughout Ember, but it's most commonly used to describe the ancestry of towering humanoids who originated long ago during the Age of Beasts. The most ancient of these peoples — known as True Giants — no longer exist, having been driven from the Pathways after The Unveiling. Furthermore, the Elder Giants that established the Shent culture have also largely vanished from the world. Only the Inheritor Giants that comprise the Varún and Tolvor Kohatai clans are present in Ember today; and these large folk are quite smaller than their ancient predecessors.