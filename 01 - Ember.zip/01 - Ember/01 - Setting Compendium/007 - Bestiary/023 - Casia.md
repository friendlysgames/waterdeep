# Casia

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Casia are the powerful feline-like beings that rule over the realm of Primordis.