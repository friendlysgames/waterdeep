# Jarn

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

The Jarn, are considered the first true humanoid peoples on the surface world, though some records and legends dispute this. They were the first makers of tools, clothing and language and became the precursor people of the world that almost all other humanoid peoples on the surface of Ember are descended from. They went extinct after the creation of Humans.