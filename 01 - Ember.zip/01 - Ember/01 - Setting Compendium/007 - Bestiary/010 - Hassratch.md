# Hassratch

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Hassratch are monsters that are said to have been created by an evil god and released in large numbers upon Ember during the time of the Shattering. They tend to gather in dark, hidden places where they can hoard secrets, using these discretions to manipulate mortals into servitude; these minions are known to perform a variety of tasks, from the collection of knowledge to the execution of heinous acts. Hassratch are deceptive creatures, often portraying themselves as priestesses or acolytes of noble deities.