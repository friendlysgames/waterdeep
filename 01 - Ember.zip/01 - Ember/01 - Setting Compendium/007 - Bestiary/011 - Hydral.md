# Hydral

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

The reptilian Hydral are large abyssal monsters that possess numerous heads upon their scaled muscular bodies. They are most commonly encountered in Ember's swamps or dense jungles, and are a veritable plague upon the Lowlands subcontinent.