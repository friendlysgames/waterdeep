# Ghouls

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Ghouls are a voracious type of undead that are cursed with an insatiable hunger for the flesh of the living. This drives them to wage wars on bordering lands, emerging from the dark, to rip the living out of their homes. Those they kill but do not eat quickly rise to become new ghouls, and join the ranks.