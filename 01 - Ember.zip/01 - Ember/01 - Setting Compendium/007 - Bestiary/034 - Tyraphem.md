# Tyraphem

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Tyraphem are the powerful beings that reside upon the Inner Realm of Luxarum. Not only are the Tyraphem powerful but they are extremely numerous and combined with an incredibly warlike and martial nature they could become a major threat to the entire Cosmos. Thankfully they have been engaged in a never-ending war with themselves since Creation.