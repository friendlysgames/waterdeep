# Bestiary Overview

There are three broad classifications of life forms in Ember, based upon some key differences between them in a number of areas. Within these broad classifications, there can be a massive variation in type, shape, appearance, and behavior. The First classification is Ancestries, the Second is Creatures, and the third is Monsters.

## Ancestries

These life forms exhibit both sentience and sapience in one form or another. Sentience is the ability to experience feelings and have some kind of awareness of oneself, in addition to the ability to feel pain and grief. While Sapience is the ability to think, the capacity for intelligence, and the ability to reason. There are many Ancestries in the Ember Cosmos and some numbers in the millions, as is the case with humans in the current age. It is possible to be both an Ancestry and a Creature or an Ancestry and a Monster, but this is only a small distinction and rarely used except for perhaps a historical origin or connection. For example, Dragons are technically an Ancestry, but they are regarded as Monsters due to their origin and behavior. Examples of Ancestries include but are not limited to Ashka, Human, Carrow and Casia.

## Creatures

Creatures are life forms created by the effects of the Heart of Ember and Lifeforce. In almost every case, Creatures are referred to as natural, which means animals, beasts, reptiles, birds, and a host of insects and other smaller beings. Technically speaking, this also includes Plants and Fungi as although these life forms do not move they are still natural creatures originating from the Heart of Ember. Creatures may be natural but this does not mean they are peaceful or passive; they can be incredibly aggressive, carnivorous, and deadly. Examples of Creatures include but are not limited to Leviathans, Ancara and Yarnac.

## Monsters

Monsters, on the other hand, are beings introduced during the events of the Shattering. They are young compared to the natural creatures of Ember having only existed for a few thousand years and they are considered "alien" to the cosmos, and almost all are evil, dangerous, and corrupting in various ways. Undead are also classified as Monsters in this sense as they are connected to the alien energies despite them being also connected to once living Creatures or Ancestries. Examples of Monsters include but are not limited to Dragons, Hassratch, Vampyres and Spiders.

## Overview

Since Creation, the Ember Cosmos has been teaming with life in every form imaginable. Some are as ancient as the world and others are so young that they are still trying to find a place to survive and call thier own. Exploring the World of Ember is a dangerous, difficult, and often deadly ordeal; its environments can be extreme and hostile, but they are often overshadowed by the threats posed by natural creatures and monsters. It takes the strength of an extraordinary will to leave the confines of a safe village or city and strike out into the wilds, and sometimes, the monsters in the dark can be very close to home indeed.