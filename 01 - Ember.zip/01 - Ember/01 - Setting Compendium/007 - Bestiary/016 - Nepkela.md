# Nepkela

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Monstrous crustacean-like humanoid creatures that arose during the events of the Abyssal Shear. They are carnivorous, cannibalistic, and extremely dangerous.