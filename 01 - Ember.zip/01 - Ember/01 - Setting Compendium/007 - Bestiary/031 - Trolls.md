# Trolls

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Trolls are vicious, brutal creatures that were once beasts and animals but were transformed into terrifying brutes early on during the Age of Beasts by an ancient Shard God named Savaris. Trolls are a plague upon the northern lands of the Aterican Continent and the only thing keeping them in check are the near-constant clashes between themselves.