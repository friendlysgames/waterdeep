# Vile Dragons

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Vile dragons are the most vicious and dangerous type of Dragon present on the surface of Ember. They are universally reviled by mortals, natural creatures, and the gods. Vile Dragons almost exclusively desire the accumulation of power in various forms. They are not only destructive but sadistic and remorseless and pursue any means to control those around them. Thankfully they are also extremely rare if not mythical monsters and most cultures and mortals are unaware of their existence.