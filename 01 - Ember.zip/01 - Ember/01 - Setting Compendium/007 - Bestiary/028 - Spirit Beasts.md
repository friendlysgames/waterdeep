# Spirit Beasts

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

*Ive always been fascinated by the Moon of Orbis, but unlike many other bodies of the cosmos, I have never set foot upon its surface. I was planning to do so long ago, but was advised against it by Alar during one of our many chance encounters, and although she was most unwilling to share her reasons it was the first time that I learned of the name Spirit Beasts.*