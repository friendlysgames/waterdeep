# Fiend

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Fiends are the servants of the Daemos and live primarily upon Signara, though a few are given tasks by their masters and pursue their own goals upon the surface world.