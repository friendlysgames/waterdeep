# Ancara

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

A ferocious creature from the Corebright Forest, they are common mounts of Kirargy Knights.