# Theroch

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

The Theroch were reportedly among the first sapient mortal creatures that came into being on the surface of Ember. They are rumored to still exist in the far northern continent Jekaros much diminished by the events of the Forsaken War. Very little is now known about the Theroch in the present age but records and lost knowledge of the Aedir are sometimes recovered leading to great speculation among scholars.