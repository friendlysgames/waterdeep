# Yarnac

The Yarnac is a large, woolly creatures highly valued as a work animal by the Bejak people, and came with them when they immigrated to the Arctus Plateau. Because of their even temperament and ease of training, the Yarnac is a celebrated beast for its loyalty, and vital role in daily life and labor across numerous regions.

## Anatomy

The Yarnac’s hardy anatomy is ideally suited for the harsh climates in which it thrives. Its shaggy woolen coat provides exceptional insulation against biting winds and low temperatures, while its dense muscle and fat layers make it capable of sustaining high levels of effort or long distance travel. The creature’s powerful legs and broad feet provide stability and traction on most any terrain, while its long tail aids in balance.

The distinctive antler-crest offers both a tool for fending off predators and a magnificent display for potential mates or rivals.

While Yarnac are mostly used was work animals, their hides are highly prized for their thickness and warmth and can be crafted into durable clothing and accessories. Yarnac meat is fatty and rich, and cooks well.

## Behaviour

Traveling in herds, Yarnacs are social creatures with a naturally gentle disposition. They’re naturally docile, easily adapting to humanoid presence, and are quick to respond to training as beasts of burden. When domesticated, they can tirelessly plow fields, transport goods, draw wagons, and power machines.

Despite their size, they are remarkably placid, with even temperament and long tempers under most circumstances. However, if they or their herd are threatened, their formidable size, power, and antler crests allow them to become incredibly dangerous.

## Overview

This behemoth of a creature is squat, and slow moving, its huge body covered in dense, shaggy. Its head is broad and powerful, crowned with an impressive crest of bone forming an antler shield. It lumbers along on short, pillar-like legs ending in broad, flat feet meant to distribute it's enormous weight. A long, plume-like tail sways gently behind it, providing a counterbalance to its movement.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>The Yarnac is highly esteemed by the Bejak people, who cultivated relationships with them from the earliest days, hunting and herding them in equal measure to survive. Over time, the Bejak have perfected the art of domestication, turning Yarnacs into indispensable companions and work partners.</p><p>The introduction of Yarnacs to the Arctus Plateau was seen as a boon for agricultural development and survival in the region as they become vital parts of the silt and mud extraction process for lakeside dredging operations. At this point, Yarnac are a largely domesticated beast and wild Yarnac are incredibly rare outside of their original northern homeland.</p>
</section>