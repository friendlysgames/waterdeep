# Leafia

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Leafia are a massive plant-based ancestry found only on the distant primal continent of Jurin. They are an ancestry created long ago during the early Age of Beasts by the Shard God Janar to combat and stop Leviathans. For the most part, they have been highly successful, thus the name they call themselves is Leviathan Hunters.