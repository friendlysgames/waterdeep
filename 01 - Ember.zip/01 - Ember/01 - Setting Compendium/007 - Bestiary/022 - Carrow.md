# Carrow

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

The Carrow are one of the most mysterious ancestries to live upon the Surface of Ember, mainly found in the deepest parts of the vast oceans. During the Age of Beasts a recently ascended Shard god named Karlow was shunned by her husband and sons after revealing her transformation into godhood. She took her daughters and any willing Jarn women from her tribe into the oceans. The Carrow have chosen to dwell among the cold, dark and beautiful underwater regions of Ember ever since.