# Kraken

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Kraken are colossal, extremely powerful, Abyssal Monsters that are said to be abyss-corrupted Leviathans. They are said to dwell in some of the deepest areas of the World's oceans and are also common within the Pathways, having traveled along watery tunnels to lurk in dark places.