# Oozes

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Oozes originally come from the Blasted Moon of Cora, and while they are often not considered Elementals, they have some incredibly unique and mysterious magical biology.