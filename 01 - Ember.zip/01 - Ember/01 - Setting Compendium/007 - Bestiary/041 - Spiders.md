# Spiders

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Every spider in existence is a monster, and Spiders came into the Ember world during the Shattering. Curiously, they are neither good nor evil, though some are predatory with a terrifying amount of intelligence. This includes tiny house spiders that mortals tend to see in their daily lives to massive monstrous creatures that live in the most remote wilderness.