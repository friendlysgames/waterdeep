# Akonites

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Akonites are constructs that reside upon the dead moon of Akon. They once served the Wyrms of Akon but since their destruction, they have had little purpose. Some continue to protect and maintain the various Wyrm-made machinery, upon Akon itself and in remote locations across the Cosmos, others have broken down and decayed, becoming violent and insane.