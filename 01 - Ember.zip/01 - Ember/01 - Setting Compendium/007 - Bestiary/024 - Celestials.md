# Celestials

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Celestials are otherworldly beings from Luxarum that serve the Tyraphem. Much like their masters, they are aggressive and martial in nature, and are often zealous (if not fanatical) in their service to the Luxaran religion known as the "The Light".