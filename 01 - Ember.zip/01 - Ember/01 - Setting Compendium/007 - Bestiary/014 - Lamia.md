# Lamia

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

The upper torso of a Lamia is Human or Jarn-like while the lower body is four-limbed and appears cat-like. They are said to be a strange experiment by the ancient Casia and are mysterious and strange beings. They are said to hail from the distant lands of Kessia and among the Fae upon the Inner Realm of Primordis.