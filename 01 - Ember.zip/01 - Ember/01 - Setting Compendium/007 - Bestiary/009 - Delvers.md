# Delvers

<section class="content"><div><section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Delvers are small bipedal monsters with strong arms and thick claws. They are found beneath the surface of Ember, where they maintain surprisingly complex societies, creating machines, weapons, and armor.