# Wights

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Beta.</p></section>

## Overview

Wights are a powerful type of undead warrior. Physically strong and slow-moving, these vengeful entities are extremely hateful of Ember's mortals, driven by an undying rage and a thirst for destruction. Fortunately for the living, these vile creatures are repelled by sunlight and fire, providing some measure of hope amidst the darkest of nights.