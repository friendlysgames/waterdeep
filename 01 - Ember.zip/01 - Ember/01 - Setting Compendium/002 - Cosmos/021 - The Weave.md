# The Weave

- 
Keywords: Barrier, Shield

- 
Age: Millions of Years

- 
Other Names: Woven Barrier, Shield of the Cosmos

The Weave is a distant field of energy that encases the Cosmos of Ember in a protective bubble. Among the peoples of Ember, where magical, mystical, and more obvious cosmological forces affect them daily, it typically ranks lower on the list of importance. Despite this, most mortals are aware of its existence to some degree and have a variety of beliefs about its purpose as a barrier, a structure that holds the stars in place, or as simply the edge of the Cosmos. Its distant glimmering purple and blue mesh-like structure and light are often particularly clear on cloudless nights, and add to the breathtaking majesty of Ember skies. Some groups, however, do give the Weave much greater respect, such as the Star Mages of the Rhivan, who both venerate the Elder Goddess they call Ven'avé and study, record, and use the power of stars and the Weave for spells and a distinct type of magic.

The three Inner Realms of the Cosmos, Primordis, Signara and Luxarum all rest upon the surface of the Weave and drift slowly across its surface. These realms are vast and comparable in size to the surface World of Ember. As such, they are extremely visible despite the distance, and mortals on Ember are aware of the distinct difference between the Inner Realms and Moons. One of the most essential functions of the Inner Realms that mortals have discovered is that they are seemingly responsible for the seasons and, as such, are often venerated for their power. Strangely, most people are warier of the Inner Realms for historical reasons or some innate sense that they are particularly strange and distant forces that are perhaps best left alone.

## Overview

The Weave is a breathtaking wonder of power, purpose, and protection created during the expansion of the Ember Cosmos itself. It surrounds the entire Ember Cosmos with a mystical barrier that appears to be a perfectly rounded bubble. The Weave can be easily seen at night from the World of Ember, softly glimmering with purple and blue lattice lines like a colossal woven cloth. Many of the world's cultures revere and venerate its power, believing fate and prophecy are entwined into its very nature.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Approaching the Weave by traveling through the Sea of Stars reveals a glowing lattice of purple and blue lines of mystical energy emerging from a background of a purest black void. At intervals of several hundred or even thousands of miles, static Stars are embedded into the lattice, shining brilliantly with red, white, yellow, or blue energy. These stars are the static kind and have not moved since the First Dawn. Though in extremely rare circumstances, stars will burn out and disappear, no one is sure why this occurs. Stars are curious entities in the Cosmos as they exist in large quantities but have little if any obvious effects on the cosmos and have puzzled scholars for untold ages. However, these bright spots of strange matter and energy did lead to the development of Star Theurgy by the Star Mages of the Rhivan. They use the power of Stars to cast spells and study fate, though their practices are as convoluted and mysterious as the Weave itself.</p><div><p>The Weave was said to be explosively created during the process of the First Dawn, expanding outwards at speeds that defy belief. It formed the barrier around the Cosmos incredibly quickly in order to protect the Heart of Ember and what lay within from the powers of the Abyss. Without its protection, the alien energies of the Abyss would bleed through into the Sea of Stars and spread out to corrupt the Cosmos, causing untold destruction. The Weave was devastatingly breached during the events of Abyssal Shearbut reformed and healed quickly, continuing to provide a complete barrier against the Abyss that remains in place in the present. Since that time, the Star Mages of Rhivan now hold an even greater responsibility and have charged themselves with protecting the Weave to ensure a breach never happens again.</p></div>
</section>