# Ragen

*The Charred Moon*

- 
Keywords: Fire, Betrayal, Rebirth

- 
Ideal: Directness

- 
Age: Countless Ages

- 
Other Names: The Charred Moon, The Ember Crown, The Broken Flame

Ragen was once a breathtaking world of living fire, where molten forests and rivers of flame burned with life. The Pyrrhen, beings of fire given form, tended this incandescent realm, believing that through flame they could express the truth of the cosmos, the endless cycle of death, life, and rebirth. They forged cities of unburning wood and glass, their spires rising upwards to cover the surface of the moon.

When the cosmos fractured during the Shattering, Ragen’s brilliance blazed defiantly against the encroaching dark. Yet its life-giving flame was seen as a challenge, and so it was targeted by forces of terrifying power with hatred and malice. Its said that the moon erupted in storms of black alien ash as magic from beyond tore into its surface, its continents burning away during a war that ripped the moon apart. Amid the chaos, the Pyrrhen seemed to turn upon one another, some striving to preserve their radiant home, others surrendering to the corruption that flooded their world. When the flames at last subsided, Ragen was little more than a scar upon the cosmos, its once-living forests reduced to wastelands of ash and cinders.

From Ember’s surface, Ragen now burns faintly, a wounded flame that refuses to die. Its dim red glow reminds mortals of its former glimmering glory and its unfortunate fate. To the people of Ember, the Charred Moon is both a warning and a lesson: fire provides warmth, life, and clarity, but when it’s left unchecked, it consumes everything in its path.

## Overview

Legend tells that the surface of Ragen was once covered in flame-wreathed groves of living fire, where radiant beings and creatures of fire and smoke thrived amid burning forests. When the cosmos was torn apart during the Shattering, Ragen’s brilliance drew the malice of the dark, and its once-flourishing realm was engulfed in storms of ash. The Pyrrhen fought to preserve their world, but the fire turned upon itself, and their cities were lost beneath waves of deadly magic. Now, only a few flickering remnants of those eternal groves remain, surrounded by a wasteland of blackened glass haunted by echoes of flame and shadow.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Ragen is one of the most heavily corrupted elemental moons in the Cosmos. During the Abyssal Shear, its surface was overwhelmed by hordes of Abyssal monsters. Even now, the pockmarked and scorched terrain hosts numerous horrors hiding in the ash and deep caves. The air is filled with the stench of death and decay, and occasional roars break the eerie silence among the ash wastelands. A few small pockets of life remain, including the Garden of Ravela, which survived and resisted the hordes of the Abyss. These pockets of life are the sole remaining habitats for elemental creatures that still survive, and a few scattered settlements of the Pyrrhen that try to cling on amid attacks and assaults from the wastelands.</p><h2 class="divider">Flora & Fauna</h2><p>The vegetation on Ragen within its surviving native pockets consists of Cinderasc, trees with bark like cooling magma, and leaves that are literally dancing tongues of flame. Beneath their canopy, thick fields of Fiern Ferns blanket the ground, providing further shelter for small ground-dwelling birds called the Ciptec. Birds are among the most common elemental creatures on Ragen, with the legendary Phoenix being the most famous. The Phoenix lives in the wastelands, trying to restore the flames of its ancient forts before it dies and is reborn through a fiery, life-giving explosion.</p><h2 class="divider">Notable Locations</h2><p></p><ul><li><p><strong>Garden of Ravela.</strong> The refuge and sanctuary of the Elemental Sovereign Ravela, her garden remains one of the few remaining places on the moon that embody Ragen's pre-Shattering state—a vibrant, lush forest of immense scale.</p></li><li><p><strong>The Obsidian Ribs:</strong> A massive, fossilized ribcage of an ancient creature that defies imagination, that now serves as a jagged mountain range and a haven for the Pyrrhen.</p></li><li><p><strong>Fitaci Spire.</strong> Once the home of Fiyara, this blackened and hollow spire of melted rock and glass now houses her remaining fanatical followers, corrupted elementals, and monsters.</p></li><li><p><strong>The Fountain of White Flame:</strong> A shimmering pool of pure, radiant heat in the center of a grove that is said to heal those who are brave enough to touch its blinding waters.</p></li><li><p><strong>The Den of Evil.</strong> A massive tunnel that burrows deep into the surface of Ragen is said to extend into large caverns beneath the moon. These tunnels are believed to house some of the most vicious abyssal monsters in the cosmos.</p></li></ul><h2 class="divider">Known Entities</h2><ul><li><p>Ravela</p></li><li><p>Lorgi</p></li><li><p>Fiyara</p></li></ul>
</section>