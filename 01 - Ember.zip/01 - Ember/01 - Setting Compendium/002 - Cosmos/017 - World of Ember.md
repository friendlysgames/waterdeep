# World of Ember

- 
Keywords: World

- 
Age: Countless Ages

- 
Other Names: The World, Ember, The Surface

Most mortals today who live upon the surface World of Ember live in relative ignorance and have little regard nor concern for larger cosmological questions or problems. The fact that the World they live upon is considered the largest, most auspicious, and important realm in the Cosmos is of no consequence. It's a fair outlook; the scale of such things is beyond the farmer trying to make ends meet by selling their harvests in the nearby town each fall or even ambitious leaders looking to expand their influence and power. Every Mortal on Ember is affected in various ways by the world's strange nature, but more often than not, people tend to consider such things the work of gods, monsters, or, more simply, the way it has always been.

While the distant Inner Realms have a comparative surface size, the traversable and habitable landmass of Ember exceeds that of any other body within the Weave. Especially when considering the size and scale of the Pathways, not to mention the mythical "undersurface" a place just as large and diverse as the surface itself. No living Mortal has traveled to the undersurface, and it remains one of the most obscure and mysterious realms by being cut off from people's cosmological viewpoint in the skies. Mortals have more knowledge of the Moons and even the Inner Realms than the collosal twin realm that they share a celestial body with.

## The Broken Tower

The largest Structure on the surface of Ember is the Broken Tower. Once called the Sun Tower before the events of the Shattering, it is now a titanic gleaming reminder of the cataclysmic destruction wrought upon both the World of Ember and the Cosmos. The exact nature of the Shattering (precisely what caused the upper two-thirds of the tower to explode with such overwhelming intensity) remains unknown — a prevailing mystery that many say is best left alone. Nevertheless, countless theories, myths, and legends pervade places like Ember's libraries, academies, and taverns; but these tales are so widespread and fanciful, most scholars and sages consider the very pursuit of them to be a fool's errand.

The size of the Broken Tower is not simply impressive, it's utterly breathtaking (even with most of the structure missing and scattered across the planet). It is not only visible from every corner of the surface, the ruined structure is so vast that it often dominates the horizon, casting deep shadows across the entire continent of the Starshield during dusk and dawn. Due to the cataclysmic nature of the Shattering, the presence of such a structure on the horizon is an often painful reminder of the chaos and destruction of that time — a deep wound that many cultures and peoples still struggle with. The tower is not entirely static either; massive chunks of debris still orbit the tower's apex, hinting at the extreme magical forces that remain active and almost all mortals on Ember consider the Broken Tower to be cursed in some way or another.

## Geography

If you were able to view the World of Ember from a great distance, i.e., from one of the Elemental Moons, it would look strangely squat, like a stocky disc with a large flat surface with a few odd protruding spikes of land extending from the disc into the Sea of Stars. From such a viewpoint, the surface would be relatively smooth and flat, with a massive connecting ocean surrounding eight primary continents. At the center of the world's surface is the Starshield, a central continent upon which the Aedir built their empire and the Sun Tower during the Age of Sunlight.

- 
The Starshield is one of the smallest continents positioned at the exact center of Ember's surface with eight points that follow the same rough alignment of the world itself. The Starshield was once the center of everything, where the Aedir built their empire thousands of years ago and built their crowing achievement, the Sun Tower.

- 
Aterica is the largest continent on the surface, often called the Shardstone Continent; it is both the largest and the most storied in its history and peoples. Home to no less than five subcontinents, one of which is the Aran Penisula, which gave rise to the ancient Jarn, *the* precursor ancestry. Aterica also has a veritable wealth of Shard Gods that have found and communed with Heart Crystals, and there are so many separate cultures and realms that currently, no less than six different entire pantheons exist at once.

- 
Kessia is the only continent deeply connected to Aterica, with burdening trade routes, diplomatic ties, and a history of shared struggles. Kessia was once said to be home to the largest Aedir colonies, but they were completely annihilated during the Shattering. Within the heart of the continent, the great Obsidian Desert formed and spread to cover the vast majority of its landmass. . The Shadiel sub-continent, home to the Star Academy of the Rhivan, is considered a part of Kessia in some circles, though it remains an extremely distant and far away realm.

- 
Across the vast Reaver Ocean lies Mort'oliss, often called The Spiritlands; it is a continent realm presided over by the Elder God Sockets and where the Souls of Mortal peoples travel to when they die. The Spiritlands are not connected physically to any other continent, as they are separated by a barrier that supposedly prevents the living from crossing over, not to mention no one is particularly keen to visit the realm of the dead.

- 
Jurin is an ancient and untamed continent as far away from Atercia as is possible on the surface world. Very little is known about its nature, except many Thornlings tell a surprisingly consistent myth surrounding their origins and a towering ancestry of peoples that hunt and kill Leviathans upon the distant continent..

- 
Jekaros is spoken of in hushed tones as the "Cursed Continent," a place so reviled that most people of Ember don't speak of it at all. Much like the Spiritlands, Jekaros is a metaphysical place that you can physically travel to; but unlike the Spiritlands, the Cursed Continent is considered to be a realm of such fear and terror that no one dares disturb it.

- 
Atuo is one of the most mysterious places on the surface, surrounded by powerful esoteric energies, hidden from view by swirling blue mists; even powerful scrying magic fails to penetrate far. Some of the most powerful entities in the cosmos, including deities, have been repelled by its power.

## Forces Unknown

Mortals of Ember tend to live their relatively short lives completely absorbed by personal issues and matters of local import. To a large extent, most of the grander forces and concepts of the Cosmos remain unknown to them, and the realms that contain the people of Ember are far, far stranger than they actually know. Various cosmological forces, magical effects, and metaphysical energies affect mortals on a daily basis, and their lives are governed by a cosmic balance that's enforced and upheld by cornerstones of immeasurable power: six elemental moons drift across the sky in complex patterns and orbits, the Inner Realms create the world's seasons as they wander slowly across the glimmering weave of Stars, the Broken Tower serves as a constant reminder of the scale and majesty of what can be achieved, and even the gods themselves walk among mortal beings … Many of these forces may seem disjointed or chaotic when viewed separately, but when combined (and a broader view of the Cosmos as a whole is considered), there appears to be an overarching balance to all things.

Some believe this balance is a grand design or purpose enforced by the Heart of Ember, and many consider the world itself to be “alive.” The world contains a heart and a complex system of lava, water, and gaseous arteries that flow and breathe like a living being. There is even a limb-like geography and structure to the world that flows outwards from the center like spokes on a wheel. The world's edges are particularly fascinating, where the Gravitational Line emitted by the Heart of Ember starts to break down and dissipate unpredictably, suggesting the concept of Gravity itself is not a force but rather something maintained.

## Overview

Sitting immobile at the center of the Cosmos is the World of Ember, a colossal realm of rocky earth, oceans, and life that surrounds the Heart of Ember. It is mainly referred to as simply the world, the surface, or even simply as Ember itself. Throughout the ages of the Cosmos, the World of Ember has always hosted the largest number of diverse and divergent forms of life, from the smallest creatures to massive earth-shattering Leviathans that stalk across the lands and waters. Its environments and realms, from towering mountains, deep forests, and wind-swept barrens, are ancient, awe-inspiring, and formidable; it is a place of unparalleled beauty and wonder.

<section class="block gamemaster">
<h4>GM Notes</h4>
<h3 class="divider">History</h3><p>Much of the History of the World of Ember is covered in other pages, but given the extreme scale of the time periods involved, one of the most notable things about the World today is how truly ancient some things are. Mortals today believe that they are inventing, progressing, and experiencing the world in new ways, and while sometimes that may be true, they live upon the countless bones, kingdoms, and empires of cultures long turned to dust. A prime example of this unfathomable scale is the Oaken culture, a people who have maintained a relatively consistent cultural base for hundreds of thousands of years, a feat that defies comprehension.</p><p>Ancient in Ember is relative. The Aedir — who were destroyed by the Shattering two and a half thousand years ago — are considered by most to be ancient, despite the fact that the Aedir arose tens of thousands of years prior and endured seismic cultural changes with distinct periods of growth, collapse, and reorganization. In fact, the term Empire was only used to describe the culture around four thousand years ago. Before that, it was considered to be more of a Theocratic Dynasty.</p><p>Ultimately, the truth of things has been largely lost, remembered by a scant few via unreliable myths, tales, and legends told around Ember's campfires. Despite the lack of knowledge surrounding the history of the World, the evidence of ancient peoples remains omnipresent, in ancient structures and places of power. Upon the World of Ember, ancient cities or dungeons could be Aedir, in which case they are thousands of years old, or they could be far, far older and date back hundreds of thousands of years to primordial cultures that no longer have names. This is all to say that the scale of the world is geographically vast, but so is its history, and so much is lost, forgotten, and unknown in the present age of the world.</p><p></p>
</section>