# Aura

*The Hollow Moon*

- 
Keywords: Air, Knowledge, Paradox

- 
Ideal: Individualism

- 
Age: Countless Ages

- 
Other Names: The Hollow Moon, The Veiled Sphere, The Breath of the Cosmos

From the surface of Ember, Aura appears as a gentle, pale pink orb streaked with white lights and dark bands of swirling clouds. Yet this serene face conceals a mesmerizing world within a hollow sphere of shifting gases, luminous storms, and an endless sky. Its thin outer crust conceals vast layers of mists and vapor, where titanic creatures of the air drift and soar. Among them are the Xarcaledons, feathered leviathans said to be as old as the cosmos and the moons' true guardians, whose songs echo like thunder through the Hollow Moon’s unseen reaches.

At the heart of Aura floats the mythical city of Conundrum, a place of impossible geometry, floating structures, and ageless wisdom. Scholars believe it to be a convergence of lost knowledge, a citadel of the mind where creative thoughts and the winds themselves intertwine. The city is said to drift in the exact center of the moon and is the only place on Aura that remains constantly stable. To many, Aura embodies the pursuit of personal truth, freedom, and the pursuit of one's own destiny, but it is also a window into the dangers of pride, isolation, and the abandonment of responsibility; for just as air gives breath, it can just as easily suffocate.

To mortals on Ember, Aura symbolizes freedom of mind and self-determination. Philosophers see it as the domain of independent thinkers and those who dare to chart their own course. When its faint pink glow appears in the night sky, travelers report visions and inspirations carried by unseen winds.

## Overview

From the surface world of Ember the moon of air seems solid, but a thin surface of pale pink rock shrouds a mesmerizing hollow world within. Aura is a world of gasses, clouds, and floating dangers that few mortals can safely navigate. In addition to the environment, Aura contains a plethora of monstrous creatures such as the mythical and enormous feathered Xarcaledons. Legend tells that in the center of Aura hovers the floating city of Conundrum, a bastion of learning and knowledge of the Cosmos.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Aura is a world of endless skies, enclosed within a shell no thicker than half a mile and composed of a material similar to glass, making it slightly transparent. Within its hollow interior, gravity pulls slightly outward toward the shell and inward toward the center, creating a vast, dense, and complex atmosphere filled with luminous voids, thick storms, and vast stretches of empty shimmering sky. At the center, where atmospheric pressure becomes extraordinarily high, lies the legendary city of Conundrum. It is inhabited by Zeph, although legends suggest they may not have been its original inhabitants. Following the events of the Abyssal Shear, Conundrum is still plagued by corruption and darkness. Despite numerous efforts to destroy and push back the monsters emerging from its stones, they keep returning, causing endless battles to break out in the city's streets.</p><h2 class="divider">Flora & Fauna</h2><p>Life on Aura is dominated by floating plants and creatures, such as the Sky-Lilies, massive floating plants with translucent petals that serve as sails to catch the wind. These plants extend long, bioluminescent "roots" into clouds and storms, drawing minerals and water. Among the clouds, vast swarms of Mist-Rays move silently through the air, camouflaging themselves against the white and pink cloud layers. The legendary Xarcaledons are the moon's true rulers, and their shadows strike fear into even the most experienced Zeph, their maws glittering with long teeth and their iridescent feathers humming with energy.</p><h2 class="divider">Notable Locations</h2><p></p><ul><li><p><strong>Mesatrons Folly:</strong> A massive pocket of superheated steam created by a strange object at its center, that defies the clouds and gravity around, hanging motionless among the clouds.</p></li><li><p><strong>The Hurricane Gallery:</strong> A stable, circular storm front where the lightning has been magically frozen into jagged, permanent sculptures of light.</p></li><li><p><strong>The Forest of Jep:</strong> A massive collection of floating Sky-Lilies that drifts close to the inner surface of the shell.</p></li><li><p><strong>The Echoing Atrium:</strong> A massive hollowed-out asteroid trapped within the moon, home to odd creatures that slip between the shadows.</p></li><li><p><strong>The Well of Gravity:</strong> A terrifying "hole" in the clouds near the center where the winds fail entirely, causing anything caught within it to fall towards the mythical city of Conundrum, accelerated at insane speeds.</p></li></ul><h2 class="divider">Known Entities</h2><ul><li><p>Nymbohr</p></li></ul>
</section>