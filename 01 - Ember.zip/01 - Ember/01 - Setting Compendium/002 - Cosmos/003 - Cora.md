# Cora

*The Blasted Moon*

- 
Keywords: Earth, Endurance, Cataclysm

- 
Ideal: Pragmatism

- 
Age: Countless Ages

- 
Other Names: The Blasted Moon, The Stone Mother, The Crashing World

The fearsome earth moon is a lunar body of restless, yet predictable forces. Cora's gravitational pull is both erratic and fierce, capable of powerful surges that can tear the very mountains from the surface of the moon and cast them into the Sea of Stars — and drag them back down again to impact the lunar surface with terrifying force. These unending upheavals have formed a ring of debris that orbits the moon like a jagged crown, a monument to Cora's relentless, self-inflicted destruction. Yet, throughout this endless cycle of ruin, new formations arise and the moon endures.

In the earliest ages, as the cosmos of Ember took shape, Cora emerged from the Sea of Stars as a molten mass of ore and stone. It was said that from her body came the bones of the world of Ember itself, and some believe Cora may have once been part of the world itself before being torn free. Over time, the moon's surface became a crucible of violent transformation: mountains rising quickly and collapsing in moments, canyons yawning wide and then sealing shut again within hours. Few beings can endure such fury, and the moon’s main inhabitants are the Korvathi, elemental creatures of stone and crystal, who survive by sheer adaptability.

To mortals on Ember, Cora is both revered and seen with some caution. Many assign a feminine personality to the moon despite no evidence to support the idea. Farmers, miners, and builders alike whisper her name in quiet prayers before working the soil or striking the ground, acknowledging the moon's temper as much as her generosity. Scholars see Cora as the embodiment of harsh necessity, the understanding that survival requires acceptance of hardship. While other moons may inspire faith or wonder, Cora teaches endurance: that the world does not bend to one’s will, but one must meet its challenge regardless.

## Overview

The fearsome moon of earth has been wracked by wild and untamed change since Creation. Its powerful gravitational forces fluctuate erratically, causing dramatic fissures and changes to its topography, while flinging rock into the moon’s orbiting ring of debris. This debris is often trapped above for a short time before Cora’s gravitational surges cause these meteors to plummet and slam unrelentingly into the moon’s pockmarked surface.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Cora is a world of change, its surface is a chaotic mosaic of fresh scars and ancient ridges, where gravity behaves like a wild beast, surging and ebbing without warning. One moment, a traveler may feel as light as a feather; the next, they are pressed to the ground by forces capable of cracking bones. The environment hosts one of the most intense and relentless battlefields in the Cosmos, where native Korvathi and earth elementals fight against terrible spiders skittering from the moon's core. This ongoing battle is further complicated by both sides attacking and trying to destroy malignant oozes that emerge from every crack and tear in the moon, led by the corrupted Elemental Sovereign Slinerak.</p><h2 class="divider">Flora & Fauna</h2><p>The biology of Cora is defined by armor and density, as anything fragile is instantly shattered by the shifting moon or impacts. Obsidian Vines extend through fissures, their stone thorns able to anchor into solid rock to withstand gravitational surges. The only structures called Iron Palms are mineral deposits that grow upward during low-gravity cycles and harden into indestructible columns. The Korvathi, the moon's main inhabitants, are armored elementals with crystalline nervous systems that can sense gravitational shifts seconds before they happen. The moon is also filled with massive web-filled lairs, inhabited by spiders, some as large as buildings.</p><h2 class="divider">Notable Locations</h2><p></p><ul><li><p><strong>The Palace of Rust: </strong>The home of the corrupted Sovereign of Earth, the debaunced Slinerak.</p></li><li><p><strong data-path-to-node="7,1,0" data-index-in-node="0">The Iron Forge:</strong> A subterranean city built within a massive geode of Iron, where the pressure of the moon is harnessed to craft tools that can cut through any material.</p></li><li><p><strong>The Crystal Core: </strong>The shuddering centre of the moon, said to be home to the largest spider lair in existence, and the home of Sitheera.</p></li><li><p><strong data-path-to-node="7,3,0" data-index-in-node="0">The Resonating Monoliths:</strong> A circle of twelve obsidian towers that hum with a deep, subsonic frequency, serving as the only places on the moon where gravity remains perfectly stable.</p></li></ul><h2 class="divider">Known Entities</h2><ul><li><p>Slinerak</p></li></ul>
</section>