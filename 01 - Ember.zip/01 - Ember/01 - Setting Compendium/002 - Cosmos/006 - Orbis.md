# Orbis

*The Spirit Moon*

- 
Keywords: Chaos, Change, Emotion

- 
Ideal: Spontaneity

- 
Age: Countless Ages

- 
Other Names: The Spirit Moon, The Maelstrom, The Unbound Halo

Orbis is unlike any other moon in the cosmos. It is composed of vast, luminous bands that spiral and cross one another in an ever-shifting lattice of color and light. These colossal ribbons weave layer upon layer, encircling a roaring maelstrom at the moon’s heart. At first glance, each band appears smooth and white, but the longer one gazes upon them, the more they fracture into iridescent patterns, kaleidoscopic hues that twist and shimmer as though alive. No layer follows a constant orbit; they drift and bend around each other in a slow, almost hypnotic dance.

No life stirs within Orbis. There are no creatures, no elemental beings, and nothing stirs across its ever-twisting lands. Winds scream between the shifting layers, and faint echoes can be heard where the bands brush together, forming chords that have driven countless seers to madness. Many scholars claim that this music is thought itself, the raw expression of creation or chaos. Some believe the truly ancient tales that Orbis is a prison, a shell built to contain a terrifying ancient power that should never again awaken.

From Ember’s surface, Orbis gleams as a restless jewel, its colors waxing and fading without rhythm or reason. It embodies a person's raw spirit, emotion, and unpredictability. Orbis has no patterns, no single truth, but is always in constant motion.

## Overview

Mind-twisting arrays of white and multi-colored geometric bands surround the roiling maelstrom at the heart of the chaos moon of Orbis. It is said that at first glance, each band appears as solid white matter, but anomalous pearlescent patterns appear with increasing intensity the longer they are observed. An ancient myth told throughout the ages is that surrounding the maelstrom at the heart of Orbis is an eternal prison built to contain the most dangerous and calamitous force of the Cosmos.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Orbis is a place of breathtaking beauty and profound psychological peril, where the bizarre and alien nature of the environment can break even the strongest minds. The atmosphere is a shimmering haze of psychic static, where colors have weight and shadows hum with discarded thoughts. While extremely few people from the surface of Ember have ever traveled to Orbis or recorded anything about its history, it is said that the moon was the only place in the Cosmos ignored by the Abyss during the Abyssal Shear.</p><h2 class="divider">Flora & Fauna</h2><p>Biologically, Orbis is a wasteland, as no organic or elemental life can take root on its shifting plane like bands. In place of plants, the bands are encrusted with Refraction-Clusters—crystalline growths that grow by absorbing the stray emotions of those who gaze upon the moon from the surface of Ember. These clusters do not breathe; they pulse in sync with the central maelstrom, occasionally shattering into Prism-Dust that drifts between the layers. The only "inhabitants" are the Chromatic Echoes, visual after-images of historical events trapped within the light of the bands, playing out silent, looping tragedies for eternity.</p><h2 class="divider">Notable Locations</h2><p></p><ul><li><p><strong>The Maelstrom.</strong> The central core of Orbis, a roaring white hole of raw chaotic energy that is visible through the gaps in the lattice. Said to be enclosed by solid bars of an indestructible prison.</p></li><li><p><strong>The Knot:</strong> A rare junction where seven of the moons' bands have tangled into a stationary, multi-colored mountain of light that serves as the only "stable" landing point on the moon.</p></li><li><p><strong>The Well of Silent Screams:</strong> A localized vacuum between two fast-moving bands where sound is utterly erased.</p></li><li><p><strong>The Fortress of Pandemonium.</strong> A massive castle structure made of white crystal-like stone, said to be inhabited by creatures that defy reality itself and are older than the Ember Cosmos.</p></li></ul>
</section>