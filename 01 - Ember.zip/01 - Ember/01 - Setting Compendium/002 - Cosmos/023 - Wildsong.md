# Wildsong

## Deep Vibrations

The Wildsong is not an audible force but a profound, magical field that connects the various Wild Gods of Ember. It is experienced deep within the soul and through the body's physical connection to nature, often amplified in places bursting with natural energy, and the sensation becomes especially strong in the presence of a Wild God. Some mortals are drawn to this deep thrum and feel it as a slow, inexorable vibration rising from the natural world around them. By attuning to this sensation, mortals like Druids and Shamans learn to channel the Wild Gods’ Wildsong, manipulating nature itself. This can instantly promote rapid growth or summon localized weather patterns, control or animals and beasts, and even allow them to shapeshift into natural creatures.

## The Natural World

Some of the most ardent believers in the Wildsong as a force are the Striders of the Corebright Forest. Their culture is deeply religious, centered on Druidism, communing with the wilderness, and the sacred belief that everything around them is playing a part in the wider symphony of life. While some of the more astute and experienced Striders recognize Lifeforce as the powerful magical energy stemming from the Heart of Ember, they view the Heart only as a reservoir of power, which the Wild Gods around them then interpret. For them, true wisdom lies in listening, worshipping, and revering the different Wild Gods and the natural cycles of the world.

It is common for believers in nature and in the origin of life across the world of Ember to have widely different ideas about how the Wildsong can manifest or help them in their daily lives, which is a significant point of contention and conflict between cultures or groups. For example, while the Striders consider the Wildsong created by the combined existence of the Wild Gods to be paramount and the ultimate expression of life, the Cindaric Sages of Ordain focus almost solely on the Lifeforce that stems directly from the Heart of Ember. They see the Wild Gods and the Wildsong as mere distractions or a lesser, filtered version of the true power, choosing instead to focus on the raw, life-giving and radiant energy of the soul.

## Overview

While the Heart of Ember is the limitless source of all Lifeforce in the Cosmos and the spark that ignites every soul, the flow of the natural world is guided by The Wildsong. This force is driven by primordial entities called Wild Gods. Through them, Lifeforce is refined and shaped into the Wildsong, an invisible network of interconnected magic, which dictates the laws of growth, decay, and animal instinct. Those who practice nature magic learn to listen to and attune themselves to the Wildsong and develop a deep connection to plants and animals.