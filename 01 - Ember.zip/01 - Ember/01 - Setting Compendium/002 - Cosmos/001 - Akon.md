# Akon

*The Shattered Moon*

- 
Keywords: Order, Regret, Ruin

- 
Ideal: Discipline

- 
Age: Countless Ages

- 
Other Names: The Shattered Moon, The Broken Crown, The Silent Architect

Akon was once a bastion of symmetry and reason, its surface covered in vast geometric plains of metal and glass where the ancient Wyrms crafted monuments and machines that reflected the perfect harmony of creation. The Wyrms, beings of immense wisdom, sought to understand the architecture that shaped all existence, believing that through pure logic and discipline they might one day mirror the perfection of the cosmos itself.

Today, Akon is a graveyard. Its shattered remains drift through the sky above Ember like a frozen storm, with massive fragments orbiting the now-broken and lifeless moon. The endless debris fields, sharp with the edges of crystals and metal, whisper to those who watch them for too long, voices of regret, mourning the loss of a once pure and noble people.

The tragedy of Akon is discussed endlessly by scholars and historians; many claim that its destruction marked the first great fall of cosmic reason, and every year, Ember falls further into chaos. The Wyrms, for all their brilliance, were blinded by their faith in structures and logic, unable to grasp the dangers of unmanaged chaos. Yet even now, the broken fragments of Akon shimmer faintly in the night sky, a silent reminder that Order, though wounded, still binds the cosmos together, frail, but enduring. Among the people of Ember, Akon is regarded with fear and sorrow. When its splintered chunks reach thier apex in the night sky, many see it as an omen of misfortune. Some claim that the Shattering and the destruction of the moon was some kind of divine punishment, while others argue it was merely in the wrong place at the wrong time and was hit by shards of the Sun Tower completely at random.

## Overview

Once a glimmering orb of darkened bronze, the moon of order is now gray, broken, and lifeless. It is said that the wise and ancient Wyrms had tunneled beneath its surface since Creation, where they magically forged wondrous and delicate machines to safeguard the cosmos. The Shattering was catastrophic for Akon, breaking the moon into thousands of fragments and scouring life from its surface and passageways. Now, constructs, machines, and undead monsters prowl the crisscrossing tunnels and passageways of its intact sections.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Akon now exists as a hollowed, broken graveyard, surrounded by jagged fragments. The air is thin and metallic, with a taste of copper and dust. Silence is only broken by the grinding of drifting metal and machinery tectonic plates. Many of the Wyrms' machines and structures are broken, but some still seem operational, slowly ticking or turning in strange patterns without any visible source of energy or control. Interestingly, very few Abyssal monsters are present on the moon; they tend to avoid it, as if there's little left to corrupt, which is probably true.</p><h2 class="divider">Flora & Fauna</h2><p>It's said that nothing living still walks on the surface of Akon, but that's not entirely true. While there are no large plants, small patches of hardy moss cling to the walls of some of the deepest recesses and caves. Among these tiny Solder-Mites, small insect-like creatures also cling on. Although they may not be truly alive, the last remnants and legacy of the Wyrmns still wander the moon in the form of strange constructs called the Akonites. Elsewhere on the moon, only the dead and ghosts roam the ruins. It's said that terrifying creatures known as Echo-Worms can be found in the dark, incorporeal remnants of the Wyrms—gliding through the air between fragments.</p><h2 class="divider">Notable Locations</h2><p></p><ul><li><p><strong>The Great Orrery:</strong> A floating cluster of metallic spheres that once tracked the movement of souls in the cosmos, now spinning erratically and showing only visions of the Shattering.</p></li><li><p><strong>Plains of Dust:</strong> The vast stretches of lifeless surface, home to countless undead monsters that were once elemental creatures of the moon and servants of the Wyrms of Akon.</p></li><li><p><strong>The Engine of Dead Thought:</strong> A gargantuan, rusted gear-work heart embedded in the moon’s surface that still beats once every century, causing a localized surge of gravity that pulls nearby debris into its maw.</p></li><li><p><strong>Kestalon's Burial Mound:</strong> A colossal pile of broken metal, broken machinery, and rusted tools, said to be one of the last structures built by the Wyrms as they buried their last great ruler, who fell defending Akon against the forces of the Abyss during the Abyssal Shear. Countless desiccated corpses of massive Wyrms lie scattered across the surface of the mound.</p></li></ul>
</section>