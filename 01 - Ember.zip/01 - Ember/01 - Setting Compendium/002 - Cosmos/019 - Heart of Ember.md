# Heart of Ember

- 
Keywords: Life

- 
Ideal: Creation, Vitality, Hope

- 
Age: Unknown

- 
Other Names: World Heart, World Crystal, Heart of the Cosmos

The Heart of Ember is by far the greatest of the forces in the Cosmos, and some believe it to be some kind of creator entity that created everything with some grand design or purpose. The Heart is a limitless reservoir of energy called Lifeforce, the pure, undiluted energy of creation that is extremely potent and is responsible for many great wonders, including the Soul Cycle, the formation of Heart Crystals and the constant flow of lava, water, and energies throughout the Pathways beneath the surface of the world. Throughout the History of the cosmos, the Heart of Ember has often been at the center of cosmological events, and its importance cannot be understated, as without its presence, the cosmos itself would cease to be.

## Overview

The Heart of Ember is said to be a titanic shard of crimson crystalline material, infused with mystical energy that rests at the center of the Ember Cosmos within a colossal cavern called the Heart Chamber. Its true size is difficult to determine with any accuracy as it is impossible to approach without being utterly consumed in red and golden energy. The Heart Chamber itself is colossal in size, and the Heart floats unerringly within its center.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>The Heart's history and origin is one of the greatest mysteries imaginable, and very few beings are even aware that the Heart existed before Creation. The Oaken believe that the Heart wandered the endless and unknowable expanse of The Abyss for unknown eons before it collided with strange energies, causing an extraordinary reaction and the formation of The Weave. This expansion of space resulted in a safely enclosed cosmos which is often referred to as the Ember Cosmos. Everything within, all the forces, matter and beings exist in this space also called the Sea of Stars, set apart from the eldritch indescribable energies and beings of The Abyss.</p><section class="block gamemaster"><p>While this belief is based upon uncounted ages of understanding and spiritual connection to the world by the Oaken and it does seem to be credible, it does contain several inaccuracies that I have personally uncovered. Thus the exact formation of the Cosmos is not known by anyone except Alar.</p></section><h3 class="divider">Intentionality</h3><p>It is worth noting that few mortals are even aware of the Heart of Ember today. Few believe that the Heart of Ember is a thinking sapient being with intent or motivations; or perhaps it is instead some kind of creationary engine or object, or an echo of an even greater beings purpose. Most mortals dismiss its impact and ability to affect the world and that it may just be a name for some ancient Shard God.</p><p>A few groups and cultures, however, believe that the Heart of Ember is a being with a strange, unknowable personality, the most famous example of which are the Cindaric Sages of Ordain, who worship the Heart much like a deity. They believe that the creation of the Ember Cosmos by the Heart is a deliberate act by an entity or being with awareness and purpose. The Ember Cosmos is so grand, so complex, and vast that it must obviously have some directed intent or purpose.</p><p>When ruminating on the Heart of Ember, there always seem to be greater mysteries and unknowns when considering its purpose or history. Where did it come from? What kind of power does the Heart truly hold? What is the purpose of a soul? Why does its power not remain completely consistent across the ages? Answers to these questions and many others are maddeningly illusive and some may hold hidden secrets that extend far beyond the Ember Cosmos into the darkness beyond that will never be answered.</p>
</section>