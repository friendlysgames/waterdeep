# Niethun

<section class="block social"><h4>At a Glance</h4><ul><li><p>Language: </p></li><li><p>Great City: Unknown</p></li><li><p>Technology: Unknown</p></li><li><p>Major Religions/Beliefs: Abyssal Horrors</p></li><li><p>Names: Agnash, Dagonis, Ghal-Xath, Hyliss, Ithal-Qun, Kul-Vog, Lythos, Myrkul, Nhag, Nythos, Olthara, Phul, Rhogog, Shath, Thol, Thul-Kesh, Tulu, Ul-Qath, Vahl, Vash-Nir, Xoth, Zeghos</p></li><li><p>Ancestries: <span draggable="true" data-link data-uuid="JournalEntry.emberBestiary000.JournalEntryPage.n8XfdXtjFxvpAE7a" data-id="n8XfdXtjFxvpAE7a" data-type="JournalEntryPage" data-tooltip="Page" data-tooltip-text="Ember Lore Page">Giant</span> (75%)</p></li></ul></section>

## Horrifying Abyssalists

Virtually nothing is known about the Niethun, other than the name, and that the term appears in ancient texts of the Shent and the Aedir. It is believed that they may have been an ancient terrible people who lived deep within the Pathways, but no evidence to suggest their existence has ever been found.

<section class="block hazard"><p>Learning about or knowing about the Niethun is an Abyssal connection.</p></section>

## Overview

Very little is known about this culture, aside from the fact that they exist somewhere in the vast, deeper regions of the Pathways.