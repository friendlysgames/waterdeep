# Moiran

<section class="block social"><h4>At a Glance</h4><ul><li><p>Language: </p></li><li><p>Capital City: Miris</p></li><li><p>Technology: Late bronze, early iron/steel production</p></li><li><p>Major Religions/Beliefs: Thayloc + Other gods.</p></li><li><p>Names: Abelin, Adelance, Arcosse, Aurielle, Aurivon, Costelle, Darien, Dorance, Dragant, Evelien, Evelore, Flavien, Gabrielne, Hasdeul, Laurentine, Marinel, Mariun, Mihaelle, Ruxant, Sandure, Savien, Simuen, Tiberien, Tibere, Varian.</p></li><li><p>Ancestries:  (85%) (Other Ancestries exist in small numbers).</p></li></ul></section>

## Overview

The Moiran culture was once a peaceful and almost idyllic society that established itself in the rolling grassy hills and scarred forests of the Moiran Plains. However, as the events of the Evernight unfolded, the vast majority of the culture was enslaved by the blood barons or killed outright and transformed into the undead. Some ancestors of the few refugees still cling to old traditions from their now-lost culture, but these traditions have become increasingly rare over time.