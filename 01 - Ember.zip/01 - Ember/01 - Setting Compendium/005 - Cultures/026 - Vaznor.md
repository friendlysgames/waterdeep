# Vaznor

<section class="block social"><h4>At a Glance</h4><ul><li><p>Language: </p></li><li><p>Capital City: Unknown</p></li><li><p>Technology: Unknown</p></li><li><p>Major Religions/Beliefs: Unknown</p></li><li><p>Names: Akee, Chay-Oh, Enwy, Hallow, Iska, Kawel, Kiah, Koel, Miwak, Nahele, Nye, Ohari, Okwa, Pahu, Shiye, Tahke, Walo, Woyak, Wunne, Xawi, Yahli</p></li><li><p>Ancestries: Unknown.</p></li></ul></section>

## Overview

Among the legends and myths of the peoples and cultures of Ember, especially the Oaken, there are tales of flying cities and a winged people who soared between the clouds. Many believe these people, known as the Vaznor, lived in the far north of the continent of Aterica, and their fallen cities are sometimes uncovered in distant realms. Virtually nothing is known about the Vaznor themselves, and no one is sure what caused their destruction.