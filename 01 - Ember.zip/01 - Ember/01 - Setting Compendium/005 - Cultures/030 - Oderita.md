# Oderita

<section class="block social"><h4>At a Glance</h4><ul><li><p>Language: </p></li><li><p>Capital City:  Oderita</p></li><li><p>Technology: Late bronze, early iron/steel production</p></li><li><p>Major Religions/Beliefs: Unknown</p></li><li><p>Names: Azura, Beltran, Calero, Casira, Cordero, Elio, Estevan, Galan, Iago, Isora, Jora, Lanza, Lazaro, Lora, Maro, Mondo, Orota, Osado, Pazel, Reyo, Rioja, Roque, Rozan, Sola, Solero, Tora, Valero, Voro, Xandero.</p></li><li><p>Ancestries:  (95%) (Other Ancestries exist in small numbers).</p></li></ul></section>

## Overview

The Oderita Kingdom was a wealthy and prosperous culture of Keth miners and jewelers who built a large citadel in the Northern Shana Mountains. They had a flair for creating glittering and powerful artifacts and encouraged traders from across the world to visit their gleaming city. Unfortunately, this obsession with wealth and precious metals attracted the attention of Karaxsus the Flaming Dread, and in a single night of fiery destruction, the Oderita Kingdom was utterly destroyed and its riches consumed by the Dragon.