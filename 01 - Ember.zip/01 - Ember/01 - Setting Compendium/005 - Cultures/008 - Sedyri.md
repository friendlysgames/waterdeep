# Sedyri

<section class="block social"><h4>At a Glance</h4><ul><li><p>Language: </p></li><li><p>Capital City: None</p></li><li><p>Technology: Cinderspar production, enhanced with Fire &amp; Water magic.</p></li><li><p>Major Religions/Beliefs: Scoris</p></li><li><p>Names: Acor, Akari, Alon, Aras, Atan, Axil, Belan, Covan, Elan, Ignis, Inari, Isu, Joran, Kael, Kairo, Koven, Luran, Maris, Miri, Nilus, Oris, Pyra, Solan, Talan, Thal, Toran, Vash, Vira, Xalo, Zari, Zun.</p></li><li><p>Ancestries:  (99%) (Other Ancestries exist in small numbers).</p></li></ul></section>

## Overview

In the legends, after the Shard Goddess Scoris created the Ashka, she brought them to an idyllic island called Sedyra, or Paradise, where the Sedyri culture flourished. During the events of the Shattering, the island was decimated, and the legendary floating city of Rejarh sank beneath the waves. Only a few of their cultural practices survive in small Ashka enclaves but the culture as a whole no longer exists.