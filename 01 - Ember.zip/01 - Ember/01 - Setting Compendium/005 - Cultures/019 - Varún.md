# Varún

<section class="block social"><h4>At a Glance</h4><ul><li><p>Language: </p></li><li><p>Capital City: None</p></li><li><p>Technology: Bronze production, enhanced with Bone with Runic Magic.</p></li><li><p>Major Religions/Beliefs: Sacrifice</p></li><li><p>Names: Akroth, Balthor, Gorthax, Jiroth, Jonoc, Karoth, Kharn, Kiom, Kiroh, Korm, Lorth, Marm, Mortax, Morth, Raxoc, Skarn, Stor, Throm, Varkas, Vornak, Zorth</p></li><li><p>Ancestries: Giant (100%)</p></li></ul></section>

## Violent Ritualists

The Varún are a culture of Giants hidden in the jagged shadows of the Runa Highlands and the Ruinous Crags in southern Aterica. It is thought that they are the violent remnants of the ancient Shent, survivors who chose to trade peace and the gift of foresight for a desperate primal rage rather than face destruction during the Shattering. Based on the rare encounters with the Varún, it's clear that they have descended into a state of xenophobic brutality, and they seem to attack anyone whom they encounter. Travelers who have ventured too close to the clans tell of dark rituals conducted under the light of the elemental moons, where the Varún are said to bind twisted runes to massive weapons carved from bone and stone. 

<section class="block gamemaster"><h4>Related Cultures</h4><p>The Varún border the lands of the Cascilians to the west, the Arcturians to the south, and the Kithil to the east. In every case, the Varún have little interest in peaceful coexistence or trade and attack anyone who enters their territories. </p></section>

## Overview

The Varún are the violent descendants of the Shent, the last survivors who decided to resist and fight back against their destruction rather than meekly accept annihilation. They did so by abandoning peace and their power of foresight and instead they began worshipping the cosmos' primal nature. Over time, the Varún became xenophobic, aggressive, and brutal. Building their settlements in the Highlands and around the Ruinous Crags, they keep to themselves and conduct dark rituals worshipping the elemental moons and binding twisted runes to great weapons of bone.