# Vanguard

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Vanguard is a somewhat secretive organization that vehemently opposes the Tayan Empire. Many of its members are exiled Tayan citizens, including many Kirargy Knights, Drakon who fled the empire, and various powerful figures who have banded together to slow or stop the Tayan Empire's ceaseless advances. They also believe that the Tayan Empire is sinister or malicious in some way and that some darker purpose is fueling their power and ambition.