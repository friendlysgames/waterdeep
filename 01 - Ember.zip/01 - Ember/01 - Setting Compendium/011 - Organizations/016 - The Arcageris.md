# The Arcageris

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A centralized organization based in the Lowland Bastions, they seek to master the art of Arcing, a martial art designed to imbue physical strikes with cosmic forces. They seek out places of power in the world suffused with energy in order to bring them closer to their idea of the Cosmic Force.