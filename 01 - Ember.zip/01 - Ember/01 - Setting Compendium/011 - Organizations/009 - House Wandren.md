# House Wandren

As the go-to trader for hard-to-acquire luxury items in Ordain, House Wandren relies on contacts and relationships to track down and move the goods that it sells. These relationships also help Wandren collect and trade on information and secrets, which they use to help incentivize those they deal with to either give them good deals or look the other way when they inevitably bring a few items into the city that they shouldn't.

- 
**Gilded Masks:** House Wandren thrives on contradiction. To the public, they are charming hosts, draped in fine silks and perfumes, curating the rarest luxuries for Ordain’s elite. Yet behind that polished smile lies a ruthless engine of vice and profit, their every gesture calculated to conceal the smuggling, blackmail, and shadow deals that fund their true power. To deal with House Wandren is to never quite know whether you’re being courted—or ensnared.

- 
**Information is Everything: **Whether it is knowing who to go to to get an obscure artifact, how to sneak contraband into the city, or who can be relied on to look the other way, members of House Wandren keep close tabs on information. Many carry small books that keep track of the information that they know, written in code that is indecipherable to anyone but their heirs.

- 
**Rules Are For Breaking: **From its earliest days, House Wandren has been about breaking the rules, though some iterations of the organization are more aboveboard than others, depending on the current leader. In recent years, Wandren has appeared to abandon much of its legitimate business in favor of its more secretive operations and has been collecting more information than in previous iterations, for unknown reasons that may point to a shift in power.

## Operations

House Wandren's power structure is both concentrated and chaotic - whoever knows the most damaging information about the other members of the house rises to the top, able to use their knowledge to force their potential rivals to do their bidding. Often, this leads to a cycle of change as new leaders unseat the current head of the house simply by finding information that they can hold over the leaders' head.

It is considered mandatory for any member of House Wandren to know who is currently in charge, but the frequent changes can make this difficult. To combat this, Wandren holds regular auctions in their Tradeway, which are considered the only proper place to make a dramatic power play. The current head of Wandren, Hephiss Wandren, gained his position by auctioning off the bottle of poison used to kill former Wandren leader Orena Wandren instead of providing it to the Veiled Chain or Hallows, a sign that he knew who was to blame but would let them escape if they supported his bid to run House Wandren. Hephiss has been in charge of the Trading House ever since.

## Key Members

Hephiss Wandren (CE Ordani Fej, she/her)

Hephiss Wandren has been the head of House Wandren for several years, which is longer than most are able to hold onto the position. She gained it by successfully blackmailing the killers of the last two major leaders of the house, though her tight grip on House Wandren is helped by the fact that anyone who tries to learn information about her ends up dead.

Juro Wandren (CG Ordani Wirrun, he/him)

Juro Wandren prefers the smuggling side of House Wandren's trade to the secret keeping side, perhaps in part because he once revealed a secret about his good friend Lyla Cevher that led to a serious rift between them. Uneasy in the presence of Hephiss Wandren, he has decided to make his base of operations out on the Arctus Plateau instead of in Ordain proper.

## Overview

House Wandren presents itself as the purveyor of luxury goods in Ordain, boasting refined tastes and access to wealthy clients. But this polished image hides their true nature. Beneath the silk, perfumes, and wide smiles lies a sprawling network of informants and brokers, trading not just in finery but in secrets. Their webs of contacts run so deep that even the Veiled Chain occasionally turns to them for intelligence. Yet it is not information alone that fills their coffers—the true profit comes from their shadow trade in stolen and illicit goods. House Wandren moves what others cannot: stolen treasures, dangerous magical artifacts, and materials that bypass the city’s laws.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>House Wandren is the youngest of the trading houses, originally formed by the sailors of the Wandren, a ship that stumbled onto a cache of riches while sailing for House Bastilla. Instead of returning to Ordain and paying their dues to the house, the crew decided to use their newfound wealth and ship to bring in goods from afar that they could resell in the city.</p><p>The Wandren’s plan worked - they used the luxury goods that they brought back to build wealth and reputation in Ordain and established themselves as the final Trading House, taking Wandren as their name. But while House Wandren made a big splash in its earlier years, securing luxuries can be a difficult business, and the house soon ran into difficulties, kept afloat only by through the efforts of Dini Wandren, who forced the other Trading Houses to lend Wandren money in order to keep their secrets safe after her wife Myna broke into their strongholds to find information to bribe them with. Since that time, Wandren has continued to trade in luxuries, but has made as much money and impact trading in information and securing illegal merchandise – the only rule being that the house would only use its secrets on outsiders. Until now.</p><p>After the death of elderly leader Kore Wandren, a clandestine war began taking place, with factions led by his heirs. Two groups within the Trading House quickly emerged as the dominant players in the conflict. The Cryars, led by Orena Wandren, believed the house should get back to its roots and stamp out illegal activity and the Whispers, led by Tamis Wandren, believed the house should slip into the shadows and embrace more direct activities of the underworld, including thievery, assassination, and smuggling. The dispute ended with Tamis Wandren dead in an ambush and Orena Wandren dying suspiciously in her bath, fracturing the house. Hephiss Wandren has so far been the only one able to keep it together, in part because he routinely suggests that he knows who is behind both killings.</p><section class="secret" id="secret-K6q5e22iBnB4NrDE"><p>Many of the House Wandren Whisper faction members who were pushed out of the city at the end of the House Wandren War fled into the Arctus Plateau proper. They continued smuggling operations and thievery, many turning bandit and forming the foundations of the Otherhood of Fortune.</p></section>
</section>