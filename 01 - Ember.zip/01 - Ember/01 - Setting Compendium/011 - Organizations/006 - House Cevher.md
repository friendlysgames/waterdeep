# House Cevher

House Cevher is the trading house generally responsible for metals, stone, and any arcane materials that can be mined or quarried. The potential for something to go horribly wrong if these operations fail makes House Cevher very risk-averse; their nickname is “House Never” for how often they shoot things down in the Trading House Assembly.

- 
**Family Comes First: **House Cevher is all about family - most of its leaders are related to the original founders somehow, and quarries and mines tend to be passed down from one generation of a family to the next. Occasionally, someone marries into the family simply for the access to power, but the family generally allows it as it helps to bring in new blood.

- 
**If It Ain't Broke: **House Cevher is all about doing things slowly and methodically, using time-tested methods. They also like everything by-the-book and above board. This has led to some animosity between Cevher and houses that are a bit more sneaky in their dealings, like Wandren and Bastilla.

- 
**Avoiding Disaster: **There are a few large quarry and mining accidents in House Cevher's past, and while it has always changed its practices in response and taken care of survivors and the families of the dead (even creating a special memorial graveyard and garden for them just outside of Ordain), some still feel uneasy and worry that the house is either foolish or cursed.

## Operations

All leaders of House Cevher are related to the original two friends who started the trading house by blood or marriage, and the House is still managed by a pair - the Steward and the Advocate. The Steward focuses on internal matters (pricing, productivity, disturbances in the mines, etc) and tends to be more bookish, while the Advocate focuses on relationships with outsiders (the other Trading Houses, the Ordinate) and tends to be more personable.

Outside of the leadership of the House, its members include those who oversee mining and quarry operations, create trade deals for its materials, or are experts at a craft that involves transforming and using its materials, such as masons, and metalworkers. The House uses the traditional method of generally referring to these members as inked (those who make deals and oversee projects), silvered (those who trade), and guilded (those who specialize in a craft). Individual miners and haulers are thought of as associated with House Cevher, but aren't full members who are privy to the House's dealings, a point of some contention that was exacerbated after they suffered many of the losses in the Stonehollow Quake that was widely blamed on House Cevher.

## Key Members

Lyla Cevher (LN, Ordani Human she/her)

Lyla, who has spent the last few years learning new innovative business techniques in Casla-Brava, is returning to Ordain after the death of her father Ralton, the most recent House Cevher Advocate. She intends to support her brother Funar as he takes over some of Ralton's duties and responsibilities.

Funar Cevher (NG, Ordani Human, he/him)

Lyla's brother is much shyer and more withdrawn than his sister. He is passionate about House Cevher and is currently sitting in his father's seat in the Trading House Assembly. He is hoping to take his father's title of Advocate as well, but is worried that he doesn't have the charisma and might be passed over in favor of the returning Lyla.

Darius Cevher (LG, Ordani Human, he/him)

Lyla's uncle, and Ralton's brother, Darius has always more interested in books than trade and spent most of his time "learning the business" trying to find intriguing arcane objects buried in the mines that he could research. Ralton helped to set him up with a bookshop, in part to convince him to stay in Ordain instead of joining the Anachraenum, and he has successfully run it for several years. It is rumored that he offers a "family" discount to all House Cevher members.

## Overview

If there is a substance on the Arctus Plateau that can be mined or quarried, Ordain’s House Cevher is likely involved. One of the five Trading Houses that make up the mercantile leg of Ordain’s triangle of power, House Cevher focuses on stone and metals, though it also trades any arcane materials found in its mines and quarries. Risk-averse and family-oriented, House Cevher is the most traditionalist of all the Trading Houses, and always draws its leaders from the Cevher family line.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>House Cevher is the only Trading House founded by Arcturians—best friends Lottie and Cael left Arcturel in the early days of Ordain to offer expertise to the city’s builders and soon became the go-to trading house for stone and metal mining. In the generations since, House Cevher has become a family affair, with nearly every prominent member able to trace themselves back to one or both of the founders. This has sometimes led to poor leadership as unqualified family members take over key roles, and there have been a few isolated but tragic disasters over the years at Cevher sites, including the Stonehollow Quake disaster, which killed over a thousand Ordain residents. The House does not believe it is to blame for the quake, but cannot prove its innocence.</p>
</section>