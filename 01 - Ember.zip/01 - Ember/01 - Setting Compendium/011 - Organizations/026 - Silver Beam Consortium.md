# Silver Beam Consortium

In Ancalen the Silver Beam C0nsortium are a formidable enterprise, and in many ways on-par with theOrdani Trade Houses fromOrdain in terms of influence and financial might. Their offices are vast, and they oversee a broad set of activities ranging from transport, farming, construction, and mining. They employ large numbers of people, and over the last century have begun opening subsidiary branches across the known world.

### Scope of Operations

Beyond the numerous industries that the Silver Beam Consortium carries out in Railen, it has the following notable endeavors underway beyond its home country:

- 
Mining and transport operations in the Kelmezian borders.

- 
Extensive logging operations in the Last Grove near Nasjar.

- 
Logging, trapping, and surveying in the Southern Corebright Forest, specially around the Zancol expanse.

- 
Fishing operations in the Restless Bay, as well as in the numerous lakes in and around the Border Heathlands.

- 
Farming and ranching operations in the Cascaal Golds, partially subsidized by the Cascilian government as a part of an agricultural revitalization program.

- 
Fishing in the Golden Bay and along the shores of the Cascaal Peninsula.

- 
Rare plant harvesting in the Duskflare Jungles with the tenuous blessing of the Waerd.

### The Arcturel Branch

The Arcturel office is headed by Larissa Toth, an Ancalen noblewoman who ascended to prominence in both the city and the Silver Beam ranks after her husband met his untimely demise. Rumors abound that his death was orchestrated to her benefit, but Larissa has been careful to make sure no proof exists to make such claims stick.

## Overview

Established in the far-flung lands of Aran Peninsula, the Silver Beam Consortium is a major name in the luminous city of Ancalen and a major part of the Railen culture. They began as a small mining company, but quickly and aggressively expanded into other fields, consuming merchants and mining stakes and trade caravans as they went.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Barely a year old, this operation is the newest of the Silver Beam branches, and is one that is not expected to succeed. Its creation was ordered by Pyix, and it was established with the express intend to destabilize the Arctus Plateau, gain access to Inkaro Pearls, and develop trust with the dragonZerranyss.</p>
</section>