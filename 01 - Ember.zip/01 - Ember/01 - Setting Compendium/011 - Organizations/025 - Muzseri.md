# Muzseri

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Muzseri, are a mythical order of warriors who hail from a remote mountain temple said to hang over the edge of the world. They are powerful guardians of order and justice who, with rigorous training and intensive self-discipline, mold their strength of will and spirit into physical weapons. These manifest as long blades of white-hot fire and they are capable of impressive feats of stamina and agility. They avoid violence except as a last resort, often trying to find alternative solutions before fighting. They are exceptionally rare outside of Mazira and are largely unknown across the world.