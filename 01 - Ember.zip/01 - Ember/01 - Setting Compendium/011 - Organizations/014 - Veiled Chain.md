# Veiled Chain

At its core, the Veiled Chain aims to protect Ordain from threats by investigating problems before they become crises. Its agents are expert fact-finders and investigators hand-picked from the best and brightest the city has to offer. Each member of the chain is expected to be independently effective and resourceful, but also capable of interlinking with the rest of the organization to support any and all operations they have ongoing.

- 
**Clandestine Operations**. The Veiled Chain maintains a roster of highly trained, driven and dedicated agents who go above and beyond to investigate issues, take preemptive action, and ensure the safety of the city. While they are technically still beholden to the Ordinate, not everything the Veiled Chain does reaches their ears, and not everything done would please the Hallows.

- 
**Proactive Engagement**. The Veiled Chain thrives on prediction and preempting problems. While it does spend a large portion of time responding to ongoing issues, it spends just as much time looking into brewing problems that might turn bad. Rather than waiting for disasters to happen, the Chain attempts to stay ahead of issues, catching them before they can threaten the city and its populace.

- 
**Unbroken Links**. Above all else, the Chain's agents are loyal to each other, and their cause of protecting the city from all dangers. This cohesion is vital to not only maintaining the level of secrecy they need to work in the shadows, but ensuring that the agency is capable of working together effectively.

## Operations

The Veiled Chain values discretion, resourcefulness, and unwavering loyalty, demanding nothing less than excellence from its agents. Members are expected to act independently, make difficult calls, and do whatever is necessary to shield the city from its gravest threats. Recruitment often begins with adventurers, tested on a trial basis before being offered full membership—though only a select few ever rise to the rank. The true roster of the Chain is known only to its own leadership and a handful of trusted officials, ensuring their work remains shrouded in secrecy.

At its head stands the Chief Investigator, who reports directly to the Hallows and manages the city’s most sensitive cases. Beneath them, senior investigators coordinate networks of field agents and informants, assigning missions and overseeing daily operations. From the shadows, the Chain strikes at corruption, conspiracy, and danger wherever it hides.

## Key Members

Shaar (Neutral, Ordani Fej, they/them)

The enigmatic head of the Veiled Chain, Shaar has developed a near legendary reputation within the organization as a peerless investigator who never misses a detail. Their careful leadership and dedication to the Chain has earned them the respect and loyalty of every agent that serves under them.

Ankarist (Neutral Good, Tayan Drakon, he/him)

An expatriate from the Tayan empire, Ankarist has become a respected member of the Chain after years of dedicated service. Known for their physical prowess as much as mental, they often handle cases with heightened levels of danger that less sturdy agents avoid. Ankarist is especially good at working independently, and rarely requests active support in the field.

Del Kalais (Neutral, Ordani Signborn, he/him)

A veteran investigator that has seen more than their share of troubles in Ordain, Del Kalais is admired for their calm demeanor and track record of solving complex cases swiftly. Easygoing yet highly skilled, Del is often assigned to mentor less experienced inspectors and resolve particularly sensitive investigations.

## Overview

The Veiled Chain is the clandestine investigative arm of the Hallows, charged with uncovering threats that endanger the city of Ordain from within and without. Its agents are handpicked for loyalty, cunning, and discretion, empowered to pursue crimes and conspiracies that lesser officials dare not touch. They operate in silence, gathering intelligence, infiltrating dangerous circles, and unmasking enemies of the city. With the authority to issue charges and present cases directly to the Hallows, the Veiled Chain is as feared as it is respected.

<section class="block gamemaster">
<h4>GM Notes</h4>
<dl><p>The Veiled Chain was born in the hidden conflict later known as the Veiled War, a struggle that nearly tore Ordain apart. What began as simmering resentment against House Komric and its noble allies from Yarino erupted into a shadowy war, fought not with armies but through espionage and assassination. For nearly a year, the city bled quietly in alleys and backrooms while ordinary citizens remained unaware of the scale of the struggle. At the heart of the resistance against the overwhelming power of House Komric was a coalition of ordinary citizens who called themselves the Hallows. To combat the entrenched power of the Komric nobles, they turned to a band of adventurers, skilled in investigation, infiltration, and subterfuge, who became known as the Veiled Chain. Through cunning and relentless strikes, the Chain dismantled Komric's power from within. By the war’s end, House Komric and the old noble families of Yarino were destroyed, their legacies erased.</p><p data-start="1093" data-end="1366">In the aftermath, both the Hallows and the Veiled Chain solidified into permanent institutions: the Hallows taking on the mantle of Ordain’s moral and judicial authority, and the Chain as their invisible arm of enforcement.</p></dl>
</section>