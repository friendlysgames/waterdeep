# Agrimage Circle

Agrimages can be found throughout the Arctus Plateau, within private schools and halls known as Enclaves. Within these halls, knowledge is passed not only through books or scrolls, but also through ritual, craft, and lived experience. Students may spend as much time tending rootbeds or listening to riverstones as they do studying ancient books. The magic taught here is quiet and powerful, woven into tools, into food, into the rhythms of nature itself. Enclaves also serve as sanctuaries during times of strife, offering shelter and guidance to those in need, whether they be wandering travelers, troubled farmers, or young folk called to the old ways.

- 
**Natural Stewardship:** The Circle exists to watch over the Arctus Plateau, treating the land not as something to be used up but as a partner to be respected. Through their practical magic, they help crops grow stronger, keep water clean, and mend the damage left by storms, monsters, or other troubles.

- 
**Quiet Council:** Though not rulers, the Circle shapes the Arcturian people through counsel and quiet influence. They guide festivals, mediate disputes, and serve as anchors of identity, reminding people of who they are and their connection to one another.

- 
**Regional Unity:** Though each Arcturian settlement across the Arctus Plateau is its own distinct community, shaped by local customs, concerns, and needs, it is the Agrimages who serve as the quiet thread weaving them all into a greater whole. While they hold no formal authority, Agrimages are deeply respected in every village, hamlet, and town, often acting as trusted advisors and cultural anchors. Through their guidance, settlements are encouraged to look beyond their borders, recognizing the shared rhythms of the land and the mutual challenges they face. In times of drought, migration, or seasonal shift, it is often the Agrimages who bring local leaders together.

## Operations

Across the Arctus Plateau, much of the Agrimages’ work is quietly practical and often unglamorous. They spend their days repairing weather wards that protect settlements from storms, blessing the harvests to ensure bounty, mediating disputes between neighbors, and helping to repair buildings or teaching traditional methods of crafting durable structures and tools. In their quiet Enclaves, elder Agrimages pass on their knowledge to younger students, guiding them in crafts like seed-binding, an art of nurturing tough, dependable crops; storekeeping magic to preserve food and knowledge, and practical enchantment magic, the practice of imbuing everyday tools with a touch of magic to make life easier.

## Key Members

Eamon Mariflor (Lawful Good, Arcturian Keth, he/they)

Eamon is a gentle presence with a sharp mind and a deep love for the land. Known for his intelligence and approachability, Eamon is admired not only in Redrak but across the surrounding Arctus Plateau for his unwavering compassion and his gift for bridging differences between people. He has a calming presence in tense situations, often resolving conflicts with wisdom rather than authority, and is especially beloved by students for his patient, story-rich teaching style and his passion for understanding magic.

## Overview

The Agrimage Circle is an ancient organization of wise folk and practical mages devoted to caring for the Arcturian people and their homeland. Spread across the Arctus Plateau, they live and teach in carefully tended Enclaves — sturdy halls where the old ways of Agrimagic are preserved and passed down. This magic is rooted in common sense, skill, and a deep understanding of the land’s cycles, focusing on crafts such as growing food, preserving resources, and creating practical tools. Though they hold no official power, Agrimages are respected in every settlement, offering guidance through their knowledge and traditions

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>In the earliest days on the Arctus Plateau, the people later known as the Arcturians found the region peaceful and full of potential. They settled widely in isolated communities, living carefree. They knew that to preserve their peaceful way of life, they had to connect with the land and safeguard their growing knowledge. The first Agrimages started recording and sharing what various communities learned, traveling between them to exchange ideas. Over generations, the Agrimages established Enclaves, not temples or towers, but solid wooden halls built into hillsides or nestled into local communities, where knowledge was slowly accumulated into vast libraries. From these centers, they trained and taught new students, leaving to advise leaders and help the people through changing seasons and tough times.</p>
</section>