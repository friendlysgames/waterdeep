# Primalists

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Primalists are an ancient druidic organization that resides within the Corebright Forest. They are deeply tied to the Strider culture, but unlike the Striders, the Primalists become one with the natural world around them by transforming into animals, creatures, or beasts, and spend most of their lives safeguarding the wilds and nature itself. They rarely come together to achieve a common purpose other than their overarching goal of defending the forest, but they sometimes venture beyond their borders to seek out natural knowledge.