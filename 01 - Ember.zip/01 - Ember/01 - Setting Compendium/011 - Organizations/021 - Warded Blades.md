# Warded Blades

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Warded Blades are a powerful warrior class of the Wardcall, strictly defined by moral codes and firm resolve. They defend towering fortress holdouts in the cold northern realms and refuse to fight one another; instead, they are principled guardians who protect against the Vartic shapeshifters. Their members are extremely rare outside of the Wardcall kingdoms, but occasionally, they may be seen hunting shapeshifters and upholding their own personal honor through combat.