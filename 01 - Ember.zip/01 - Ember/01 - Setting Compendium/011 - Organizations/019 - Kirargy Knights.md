# Kirargy Knights

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The fabled Kirargy Knights are the protectors of the law and defenders of the people of old Caran’ac and, by extension, many now serve the newly established Tayan Empire. They ride various creatures, from ground-based beasts to winged creatures and in extremely rare cases Dragons. These honorable warriors follow a strict code to maintain order even if that means carrying out questionable acts of morality.