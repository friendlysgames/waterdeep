# Malicae

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

The Malicae is one of the most furtive and clandestine organizations on Ember, yet it holds incredible power and maintains countless troves of hidden knowledge throughout Ember, the Sea of Stars above, and even the distant Inner Realms. Since the fall of the Aedir Empire and the annihilation of their pantheon, the Malicae has been secretly working to restore what was lost.

Ages ago, when the Aedir Empire was at its zenith, the Malicae served many purposes. Over time, however, its goals have shifted most dramatically. Now, the only path ahead for this abstruse organization is a bloody one, paved in ruin. Fraught with bitterness, anger, and dread, the surviving members of the Malicae were devastated by the near-annihilation of their world-spanning populace and the collapse of their once-mighty civilization. As a result, the Malicae of the modern age has no interest in saving anyone. It only cares for one thing: the rebirth of a malicious Aedir Empire, with the Malicae as its ultimate rulers. Dominion over all, at any cost.

## Overview

The Malicae was formed from the remnants of the once-dominant Aedir Empire. Devastated by the loss of their domain and the death of the Aedir pantheon, the members of this clandestine order have dedicated themselves to restoring the Empire by destroying all that came after it — all while reinstating themselves as the dominant leaders of the land.

As the Maelicae works towards this ultimate end, it accumulates knowledge gained through extensive research and a vast spy network. This disconnected hoard of information is only accessible by those the Malicae deems worthy, and members of the Malicae guard this covert intelligence with their very lives.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>The Sunfire Empire of the Aedir once stretched across the world, discovering and settling upon the sun-bathed continent of Kessia long before the Shattering. Great cities arose, and the population exploded over thousands of years. The Aedir colonies paid only lip service to the imperial family on the Starshield. Like the Aedir Empire itself, however, the Shattering devasted the Kessian colonies and they were almost completely destroyed by the formation of the Obsidian Desert. Today the remnants of those colonies call themselves the Nalvani, or the inheritors of the empire, and extremely secretive and reclusive culture that remains hidden from the rest of the world.</p>
</section>