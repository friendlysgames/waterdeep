# Moiran Warders

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Moiran Warders were once a group of skilled and knowledgeable defenders of the Moiran Kingdom, but after the events of the Evernight, they now live in exile in various places across the world, specifically the Lumek and Cascilian cultures. They practice a unique method of archery that weaves innate magic into bows and arrows, enhancing their skills and power to deal devastating long-range attacks. They are a small, rare group of stalwart fighters that pass their techniques down from generation to generation and have a burning hatred for undeath and the Blood Barons that took over their homeland. They are also the direct followers of the Shard God Thayloc and have a fanatical, unwavering belief in his cause.