# Sanguinaries

The Sanguinaries are far smaller in number than the Cindaric Sages, with little influence beyond a handful of scattered pockets across the known world. They lack organized defenders or formal security, relying instead on improvised measures and the vigilance of individual members. Their hierarchy is loose, centered on a symbolic leader whose role is more to guide than to command. What strengthens them, however, is their deep connection to magic. Many of their number are skilled sorcerers and druids, and the order as a whole maintains a profound tie to the ancient and powerful Casia, and the realm of Primordis, drawing on that bond to further their studies and fuel their cause.

- 
**Heart of the World:** Like the Cindaric Sages, the Sanguinaries believe all life in the cosmos exists as part of the unconscious will of the Heart of Ember—the creationary force at the center of the world.

- 
**The Burden of Truth:** The Sanguinaries differ from the Sages in one crucial way: they believe the Heart of Ember is dying. This conviction is the cornerstone of their faith, shaping their worldview and driving their actions. Each member must grapple with this shared burden and the responsibility to act against such an end. How best to achieve this varies widely, but all pursue it with relentless determination.

- 
**Defiant Independence:** Born from suppression by the Cindaric Sages, the Sanguinaries place great value on freedom of belief and expression. Their order is highly dispersed, with members scattered across the known world—even as far as the distant Tayan Empire. Leadership provides little formal doctrine, leaving individuals and groups to interpret their cause as they see fit.

- 
**Radical Elements:** A small faction within the Sanguinaries believes awareness of Ember’s decline must be spread at all costs. These zealots push for decisive, often disruptive action, and pursue it whenever they can. Among their own, they are tolerated as fanatics; to outsiders, they are little more than doomsayers and madmen.

## Operations

Though small and scattered, the Sanguinaries take an active role in defending Ember from threats they see as symptoms of its decline. Their efforts vary widely from cell to cell, but certain patterns are common. Many devote themselves to the destruction of the undead, whom they regard as abominations that gnaw at the strength of the living world. Others turn their focus to the encroaching corruption of monsters and threats from beyond the cosmos. Some Sanguinaries speak of combating the Great Darkness or one of its forms in many fragmented terms: the Hollow, the Famine, the Blight, but what they mean by this is unclear.

Most do not set out to become Sanguinaries. Members are usually drawn in after uncovering fragments of truth about the Heart of Ember or being approached by a wandering believer. Initiation is informal, like an invitation to a ritual, a trusted secret, or a test to destroy an undead or a monster. Each path is personal, with commitment born from conviction rather than oath, leaving the order diverse but united by a shared burden.

## Key Members

Avwynn Taol (Neutral Good, Maziran Human/Nir'ae, she/her)

Avwynn Taol is the iron heart of the Sanguinaries, a mystic-scholar whose power and presence command attention wherever she goes. Exceptionally well-read and insatiably curious, she has spent her life chasing the truths buried in Ember’s histories, cultures, and legacies, piecing together patterns others overlook.

## Overview

The Sanguinaries are a breakaway sect from the Cindaric Sages, formed when a horrified sage revealed the supposed truth that the order had long tried to hide: the Heart of Ember is not just weakened after long eons of keeping the cosmos intact, but is dying. Where the Sages deny and suppress, the Sanguinaries act. They are scattered, lacking central leadership, and place a high value on individual freedom, which gives them the flexibility to approach their cause in different ways. Some groups or individuals search for answers quietly, while others take desperate or extreme action, convinced that only direct action can save Ember.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>The origins of the Sanguinaries trace back nearly three centuries to Darik Melsbow, a scholarly member of the Cindaric Sages. During his expeditions into the Bloodwoods, Darik encountered Nimaelle, a powerful Casia whose insights shattered his understanding of the world. From her, he learned a dire truth: the Heart of Ember was not merely weakened, but slowly dying, and with it the very fabric of the cosmos would one day unravel.</p><p>Upon realizing the gravity of his discovery, he sought to inform his peers in the Cindaric Sages. However, his warnings fell on deaf ears as the Holy Speaker of that time, in an attempt to avert widespread panic, dismissed the claims to maintain unity. Bitterness and anger led Darik to leave Ordain in search of evidence to prove their discovery and gain a deeper understanding of the Heart's affliction. In their wake, the Cindaric leadership exiled both Darik and his close group of followers, calling him and any who would follow harbingers of disunity and alarmists trying to spread fear and drive people into pointless panic.</p><p>From that split grew the Sanguinaries, a small but unyielding order that has since embedded itself within many lands beyond Ordain. Over time, they have learned to temper their message, avoiding the image of doomsayers while pursuing both discovery and the defense of the cosmos itself.</p><h2>Timeline</h2><dl><dt><p></p></dt><dd><p>A poor harvest in the Kethil Villages across the sea and the unease following the recent quake led to a period of minor unrest and rationing for several months in Ordain. Though the situation is rare and resolved quickly by the Trading Houses with the purchase of food from several of the Southern Waerd Bastions, as a result, the Sanguinaries gain momentum among the angry populace in the city.</p></dd></dl>
</section>