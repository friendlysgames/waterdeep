# Hallows

Of all the great organizations within Ordain, none work harder, or care more deeply, than the Hallows. Composed of thousands of dedicated Ordani, the Hallows is the tireless, subtle heartbeat of the city, ensuring that life runs smoothly for all who call it home. From the humble clerk sorting petitions in an office, to the magistrate presiding over a bustling court, to the countless city inspectors and workers repairing shattered lampposts and crumbling infrastructure, the Hallows never stop working for Ordain.

- 
**Protectors & Investigators:** Whether settling a dispute before it gets out of hand, walking someone home after too much to drink, or fixing a section of loose cobblestone, the Hallows make sure that the city is a good place to live. In those rare times of trouble and disaster they also form and organize first responders and emergency teams to help keep order and preserve lives.

- 
**Of the People:** The Hallows draws its ranks directly from the city’s populace, from bakers and artisans to scholars, dockhands, and masons, reflecting the full spectrum of Ordain’s soul. The organization not only serves the people, it ensures their voices are heard. From managing civic petitions to overseeing Ordain’s public elections, the Hallows safeguards the right of every citizen to shape the city’s future. While some within Ordain see it as little more than a political body, others regard it as a true bastion of freedom, where every hand and every voice can help guide the city’s destiny.

- 
**Lively & Personal:** Since the Hallows recruits from the streets, it is rife with personality and character. It is not uncommon to find a Noticerie or Hallows office doubling as a candy shop or lunch spot, Lookout Posts play music, or offer local youths games or classes, and most every location is decorated with small pieces of the personality and culture of the people assigned there.

## Operations

The Hallows operates primarily from its namesake district, where a network of interconnected offices and sprawling chambers manages everything from civic regulation and public safety to law, infrastructure, and business records. It is one of the busiest institutions in Ordain, not only because of the vast number of officials and clerks it employs, but also due to the steady flow of citizens who arrive daily seeking resolutions, permits, or guidance.

Throughout the city, community waystations known as **Noticeries** or **Offices** serve as the Hallows’ public face. Staffed by ordinary citizens who proudly display their affiliation, these local volunteers keep residents informed about new laws, civic updates, and neighborhood events, and often provide a place to gather and socialize. Many are based within local establishments such as cafés, taverns, or workshops, while others stand on their own as proud symbols of community life.

While independent, the Veiled Chain operates under the oversight of the Hallows. The two maintain a carefully balanced relationship: the Chain conducts sensitive investigations and intelligence work, while the Hallows ensures those actions remain accountable to the city’s laws and values. Together, they form the quiet foundation of Ordain’s stability.

## Key Members

Calin Oren (Lawful Good, Ordani Altyra, he/him)

Once the brightest star in Ordain’s musical scene, Calin was once a member of House Salva. His performances were legendary, and his charm and ability to communicate with dazzling speeches and oratory make him one of the most recognizable figures in the city. Though he claims to have left the stage behind, every public appearance is still a performance; his words are perfectly timed, his smile as dangerous as it is mesmerizing. To the people of Ordain, he is a beloved and admired scion, yet those closest to him whisper that behind the glamour and the gilded charm lies a calculating mind that knows precisely how to strike the right note to keep the city dancing to his tune.

Okia Tyrwar (Lawful Neutral, Ordani Human, she/her)

Okia comes from a long line of clerics of the Radiant Eye, and her grandmother was also the high priestess during her time. She was raised in Sunhaven and has dedicated her life to worshipping Lantyr, becoming one of the temple's most outspoken figures in recent memory. Her leadership is marked by deep ties to the traditions of both Kessian and Ordani cultures, but she believes that the vast majority of the population is far too lax in their veneration of the gods and of Lantyr herself, seeing the recent troubles and increasingly turbulent times as a consequence of their inaction. She is ardently passionate about her followers taking measures to enact change and to help others, and her rousing speeches have reached beyond Sunhaven and into the city population as a whole, which recently led to her being elected by the Hallows to a seat on the Ordinate itself.

Mistress Caberi (Lawful Good, Ordani Human, she/her)

Mistress Caberi is a warm, friendly seamstress often surrounded by bolts of luxurious cloth, textiles in vibrant colors, and a small following of adoring fans. Her fame is so widespread that she has become a member of the Ordanite after being elected by the Hallows and through her connections with House Salva, and although she is not technically a member of the house, she is so closely connected that she might as well be. She welcomes all who enter her quaint shop in Gossamar with a radiant smile, where the aroma of fresh clean fabric mingles with soft laughter and cheerful conversations about the latest trends in Ordain. With her nimble fingers, she weaves magical threads of various hues, crafting exquisite and unique pieces of clothing for the city's most passionate fashionistas.

## Overview

The Hallows is one of three major arms of the Ordinate, who see themselves as the city’s unseen custodians, the hands that build, mend, and move all that keeps Ordain thriving. From the masons and engineers who raise its towers, to the city inspectors who enforce its edicts, to the unseen eyes of the Veiled Chain who they oversee, every layer of Ordani life is touched by the Hallows’ influence. Yet beneath this veneer of public service lies something older and more calculating. They manage chaos with a craftsman’s precision, subtly steering the city’s fortunes while others take the credit. Their leadership, composed of shrewd magistrates and silver-tongued orators, maintains a delicate balance between the piety of the Cindaric Sages and the greed of the Trading Houses.

<section class="block gamemaster">
<h4>GM Notes</h4>
<dl><p>The Hallows began over seven centuries ago as an armed resistance of ordinary Ordani citizens who rose against the tyranny of House Komric and the old nobility of Yarino. Tired of exploitation and manipulation, farmers, laborers, and scholars alike took up arms to remove the blatant corruption that was infecting their city. For two grueling years, they fought in the shadows to weaken, disrupt, and destroy House Komric interests. In the aftermath, the victors faced a profound question: what should become of the city they had bled to free?</p><p data-start="729" data-end="1056">Rejecting the greed and cruelty of those they had overthrown, the leaders of the Hallows chose to share power rather than hoard it. From that decision was born the <strong data-start="893" data-end="905">Ordinate</strong>, a tripartite government composed of the Hallows, the Trading Houses, and the Cindaric Sages, each balancing the other to preserve the city’s future. Though centuries have passed and the Hallows is a peaceful organization, it remains the voice of the people and the safeguard of Ordain’s freedom.</p></dl>
</section>