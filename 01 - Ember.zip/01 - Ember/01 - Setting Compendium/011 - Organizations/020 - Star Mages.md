# Star Mages

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Star Mages of Rhivan are an incredibly famous organization that is renowned across not only the known world but far beyond it as well. They have traveled and explored some of the most distant places in the cosmos but are often limited by their lack of full members who only number in the hundreds. A Star Mage is not a typical wizard, sorcerer, or arcanist but a learned academic studying a specialized magical philosophy. This strict focus and commitment grants Star Mages impressive abilities and far greater power over magic than other magic users.