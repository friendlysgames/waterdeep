# Artificer

Ember has more than its fair share of Artificers, whose marvelous creations can be found throughout the world — from the technocratic innovations of the Tayan Empire, to the arcane marvels of the mysterious Lorai, or the masterful folk constructs of the Arcturians. Some say the ubiquity of arcane artifice throughout Ember's cosmos owes much to the perpetual clockwork influence of Akon, the Shattered Moon — which has become a much larger part of daily life on the living planet since the advent of The Shattering. Others maintain that these arcane innovators have been around for ages untold, as far back as the time of the ancient Shent and beyond (and they would be quite correct to do so).

<section class="block gamemaster"><h4>Premium Content Required</h4><p>The Artificer class is available to use in Ember if you also have either <em>Eberron: Forge of the Artificer</em> (for 5.5e) or <em>Tasha's Cauldron of Everything</em> (for 5e) by Wizards of the Coast installed and activated.</p></section>

## Alchemist

Alchemist Artificers of Ember are a cut above the world's standard apothecaries or chemists. These specialists are practitioners of elevated alchemical arts that infuse their reagents with remarkable magic potential, and are capable of chemical masteries that can both harm and heal. The practice of alchemy is common to many of Ember's cultures, but the most famed Alchemists of the living planet tend to hail from cultures like the Tayan, Ordani, and Strider peoples, who each prize the study and innovation of chemical sciences in their own unique ways. Furthermore, Artificers of Ember are also known to inhabit and originate from places of extreme weather and preternatural strife — such as the lightless depths of the Pathways, the blistering deserts of Kessia, or the frigid expanse of Rimedrift.

## Armorer

Armorers are those Artificers who specialize in the creation and use of enchanted armor, and are welcome in nearly all cultures of Ember — particularly those that have a greater need to defend themselves. Indisputably, this area of study is most honored among Ember's warring nations and cultures, such as the Lumek, Waerd, Tayan, or Oaken peoples. And as one might expect, Armorer Artificers are extremely rare among the seafaring Cascilians, whose mistrust of arcane magic leads them to put more faith in actual physical technology rather than the metaphysical arcana of enchanted artifice.

## Artillerist

Artillerist Artificers specialize in the powerful magic of enchanted weaponry, and are capable of developing some of the world's most potent methods of ranged arcane attacks. Despite being notably sparse in the Tayan Empire (where the use of explosive chemical compounds reigns supreme), Artillerists can be found throughout Ember's most war-torn and dangerous lands — including the shadow-haunted reaches of the Duskflare Jungles, the Railen-controlled realms of the Aran Peninsula, and the Bloodworm-ridden expanses of northern Kessia. Furthermore, the Oaken people are known to cultivate Artillerists among their ranks in larger numbers than most, as are the Lorai and Nalvani descendants of the ancient Aedir.

## Battle Smith

Arcane healers and protectors, Battle Smiths are valued members of society throughout Ember, no matter where they dwell. Battle Smiths and their steel defenders are a rather common sight among the Maziran people of far-off Akazea. However, these Maziran steel defenders are typically "steel" in name only, having been created using an exquisite array of more esoteric materials like semi-precious gemstone stone and arcane glass. Naturally, their Tayan and Kelmezian neighbors beyond The Crossing Sea have grown quite accustomed to this area of study as well.

## Cartographer

In the Ember Cosmos, the Cartographer is more than a simple mapmaker; they are dedicated archivists and chroniclers of the world's changing, expanding reality. Within the Tayan Empire, Cartographers are highly regimented and organized under the direct authority of the Tayan Cartographers' Guild. They focus their efforts on validating and extending the Empire's territorial claims, and their magical practices center on the precise manipulation of arcana and Aethyra, enabling them to survey vast distances with unerring accuracy, create magically anchored boundary markers, and uncover hidden natural resources valuable to the Empire. They are less concerned with lore and more with concrete political power, with many also working within the ranks of the feared Vyrn.

## Reanimator

<section class="block gamemaster"><p>The term "Reanimator" does not exist in Ember. However, the concept of a reanimator persists via the alternative listed below.</p></section>

In distant lands of the continent of Kessia, close to the edge of the world, is a realm shrouded in myths and whispered tales of dread: the Jaedith Dominion. It's said that it is a realm ruled by exceptionally cruel Kiska who shun all other ancestries and practice the foulest of magic. Among their ranks are the horrifying Chimerists who reanimate the corpses of dead animals and beasts, stitching them together to create deadly servants, and have twisted undeath itself to suit their dark needs. Chimerists are seldom found elsewhere in the world, especially among cultures who abhor undeath in all its forms (which are the majority); however, some have learned the secrets of the Chimerists and fled the Jaedith Dominion or have been sent to spy upon distant lands in the name of the Shadow-Exarch. Many Chimerists carry a Chimerists Collar when traveling to help hide their true nature as practitioners of unholy magic and keep any servants they create concealed from curious eyes.

<section class="block hazard"><h4>Reviled Magic</h4><p>Caution: Undeath in its many forms is considered highly problematic among the people of Ember generally and goes far beyond merely being frowned upon. It is considered Reviled Magic and therefore kept hidden if at all possible.</p></section>

## Overview

Artificers are inventive creators who blend physical creation with arcane skill to create amazing magical devices. An experienced Artificer is capable of achieving many wonders, limited only by the quality of their tools and the limits of their innovation. Whether by infusing pre-existing materials with magical essence or creating enchanted items whole cloth, Artificers shape the world around them using their expert grasp of arcane technology.