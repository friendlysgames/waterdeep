# Sorcerer

Sorcerers have a welcome place in Ember, where the entire cosmos is suffused with the eternal magic of the living planet's preternatural Heart. These instinctual magic users are more common on Ember than one might think, and Sorcerers tend to occupy notable roles in all levels of society. Whether a Sorcerer's power stems from their unique heritage, a metaphysical connection to some part of the cosmos, or a supernatural boon from a powerful being, their innate font of magic and penchant for metamagic adaptability are prized traits the world over.

<section class="block gamemaster"><h4>Familiars of Ember</h4><p>The world of Ember has a number of novel creatures that occupy its various biomes. Among these, a handful of animals exist that are compatible with the Find Familiar spell. When choosing the spell's "animal forms," you may select one of the CR 0 animals from the following list (in addition to those listed in the spell's description):</p><ul><li><p>Crevvet</p></li><li><p>Gore Bird</p></li><li><p>Oozeling</p></li><li><p>Trickadee</p></li></ul></section>

## Aberrant

<section class="block hazard"><h4>Reviled Sorcery</h4><p>Aberrant Sorcerers gain their arcane power from the eldritch magic of The Abyss. First and foremost, familiarize yourself with the concept of Reviled Magic in Ember, and discuss your character concept and background with the Gamemaster. The Reviled Magic of an Aberrant Sorcerer will have dramatic effects on gameplay, which should be considered before creating such a character.</p></section>

While all Aberrant Sorcerers aren't inherently evil, the Abyssal magic that they wield is reviled among most people of Ember (much like the Wizard's arcane tradition of Necromancy). As a result, life in normal society is difficult for an Aberrant Sorcerer, no matter their origins or motivations. Ultimately, many Sorcerers who dabble in Aberrant magic throughout Ember are evil in nature, thanks to the malevolent and chaotic influence of the Abyss — but there are exceptions to this paradigm. Some Aberrant Sorcerers spend their entire lives attempting to outrun the otherworldly weight of their Abyssal origins (to varying degrees of success). An Aberrant Sorcerer's origin could stem from any number of sources, such as a fateful encounter with an Abyssal artifact, or ancestry marked with alien corruption.

## Clockwork

<section class="block gamemaster"><p>The terms "Mechanus" and "Modron" do not exist in Ember. However, certain concepts of Mechanus persist via the lunar body known as Akon, the Shattered Moon.</p><p>Naturally, a curious relationship persists between Ember's Clockwork Sorcerers and those whose origins are more Draconic in nature, since Akon is the true birthplace of Ember's Dragons as well as the preternatural Wyrms of old.</p></section>

Clockwork Sorcerers of Ember channel their arcane magic through the cosmological influence of Akon, the Shattered Moon — where countless constructs toil in unknown servitude to long-dead masters, and the concept of Order reigns supreme. Manifestations of Clockwork Sorcery on Ember appear as one of Akon's various constructs or mechanical creations, and can be as esoteric as the Shattered Planet itself. A Sorcerer's Clockwork origin could hail from any number of sources, such as the influence of a lunar monolith, exposure to a powerful mechanical artifact, or ancestral ties to Akon's long-forgotten Wyrms. And whatever that source might be, the cosmic force of order that was once maintained by Akon lives on via the arcane methods of these custodians of law and balance.

## Draconic

Sorcerers with Draconic origins possess strange arcane powers that emulate those of Ember's Dragons. A Draconic origin comes with its fair share of stigma, given the troubled history of these wyrm-like creatures in the cosmos — including their problematic beginnings and enduring legacy of malevolence. However, not all Dragons in the annals of the cosmos have been evil creatures, and even those who do bear the ancestral legacy of Ember's malignant Dragons can often shirk the mantle of their progenitors. Thus, Draconic Sorcerers of Ember tend to be as unique and peculiar as the legendary creatures of their namesake. The fateful path that leads to a Sorcerer's Draconic origin can be one of many potentialities: perhaps your ancestors were experimented upon by a Vile Dragon, or maybe you were born within the accursed aura of a Cruel Dragon's remote lair. The possibilities, like a Dragon's wrath, are endless. And of all societies on Ember, the Rhivan people of the Star Academy tend to find a home for these wayward Sorcerers, whose primeval Draconic magic is always welcome among the world's most elite arcanists.

**Associated Deities**: Alar

## Spellfire

<section class="block gamemaster"><p>The term "Spellfire" does not exist in Ember. However, the concept of Spellfire persists via the metaphysical arcane phenomenon known as "Heartfire," which is derived from the preternatural Heart of Ember.</p></section>

Those who wield the rare phenomenon known as "Heartfire" throughout Ember harness the raw magic potential of the Heart of Ember to cast their spells. Unlike most arcane spellcasters, Heartfire Sorcerers are able to heal others with their magic — and they can innately counter and absorb spells, feeding their own pool of Sorcery Points in the process. Heartfire Sorcerers tend to feel at home anywhere the strands of fate can carry them, since they're directly connected to the living planet itself via the central force of the cosmos. Many of Ember's militaristic societies (like the Kelmezian Nightwatch and the Lumek Flameguard of Hearth) prize Heartfire Sorcerers as potent battle mages who can bolster the front lines without the need for divine aid. Heartfire Sorcerers are also known to dwell among the benevolent Cindaric Sages of the Arctus Plateau, as well as the enigmatic Sanguinaries of the famed Bloodwoods, and the noble Striders of the Corebright Forest.

**Associated Deities**: Nite

## Wild Magic

Wild Magic Sorcerers cast their arcane spells by tapping into the cosmological influence of Orbis, the Spirit Moon — the most singular and influential force of Chaos in the cosmos. Wild Magic Sorcerers are viewed with suspicion and distrust by many of Ember's societies, if only for the unpredictable destruction and calamity they can cause in their wake. However, among the moon-worshipping peoples of the Kithil and the Varún, they are often welcomed as earthly avatars of The Spirit Moon's mercurial will. Wild Magic Sorcerers are also known to emerge from places where the veil of reality has been torn asunder by The Shattering — like the fragmented ruins of The Broken Tower scattered throughout the known world.

**Associated Deities**: Nite, Spectra

### Wild Magic Surge

Some results of a Wild Magic Sorcerer's Wild Magic Surge require slight adjustment to fit the Ember cosmos. Replace the appropriate text of the original Wild Magic Surge table with the following:

<table><tbody><tr><td data-colwidth="101"><p>05–08</p></td><td><p>Roll  to determine the creature: on a 1, a Sprite of Primordis appears; on a 2, a fiendish Flying Snake of Signara appears; on a 3, a fey Rask Juvenile appears; on a 4, a fey Unicorn appears.</p></td></tr><tr><td data-colwidth="101"><p>25–28</p></td><td><p>Instead of the Astral Plane, the Wild Magic Sorcerer is transported to a realm of Orbis until the end of their next turn.</p></td></tr></tbody></table>

## Shadow

Shadow Sorcerers are inherently linked to the Inner Realm of Primordis and the lineage of the Fae and the Casia. Shadow Sorcery is often seen as sinister and predatory, and those who are blessed (or cursed, depending on the viewpoint) with innate abilities to harness it can command illusions and the shadows themselves. Shadow Sorcerers are often drawn to hidden glades and darkened enclaves, and they often become embroiled in Fae schemes or plans. In fact, for many Shadow Sorcerers, thier lineage is so directly tied to Fae creatures that they are bound at birth to their families and serve them throughout their lives, either knowingly or unknowingly. To that end, many Shadow Sorcerers can be found among the Waerds of the Lowland Bastions or with the Striders deep within the Corebright Forest.

<section class="block hazard"><p>Shadow-summoned creatures are often catlike in physical form, copying the Casia and Fae. </p></section>

## Overview

Sorcerers are arcane spellcasters who can innately call forth the power of their magic from their very being. They need not study a grimoire like wizards, nor make a pact with an otherworldly being like warlocks; a Sorcerer's origin drives their arcane abilities. Whatever the source of that sorcerous potential might be, these magic users tend to be more versatile than other arcane casters, and serve as terrific candidates for multiclassing as a result.