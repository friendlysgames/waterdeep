# Warlock

Warlocks in Ember are those who have communed with powerful entities and have been granted incredible power but at a great cost. Warlocks can form pacts with any number of entities in Ember even the Gods themselves but there are several "others' who will gladly treat with mortals upon the surface world.

The following entries on Warlock Subclasses feature suggestions for which Deities might be the most suitable to engage with as patrons in the Ember setting.

<section class="block gamemaster"><h4>Familiars of Ember</h4><p>The world of Ember has a number of novel creatures that occupy its various biomes. Among these, a handful of animals exist that are compatible with the Find Familiar spell. When choosing the spell's "animal forms," you may select one of the CR 0 animals from the following list (in addition to those listed in the spell's description):</p><ul><li><p>Crevvet</p></li><li><p>Gore Bird</p></li><li><p>Oozeling</p></li><li><p>Trickadee</p></li></ul></section>

## Archfey Patron

Warlocks of Ember who choose an Archfey patron can harness the power of Primordis for their spells, drawing upon the obscure magic of the Realm of Capricious Sorcery. When choosing this subclass, pick one or more of the following Deities to serve as your character's Archfey patron.

### The Silent Pack

<section class="block readaloud"><p></p></section>

Warlocks who bargain with The Silent Pack are no strangers to cruelty or peril. The primordial members of the Silent Pack are known to toy with their mortal servants, and a bond with this enigmatic coterie of Archfey will undoubtedly lead one on dangerous hunting missions full of impossible cat-and-mouse games. Whatever a Warlock's original point of contact with The Silent Pack — be it a run-in with a roving member of the Pack or a timely encounter with a primordial artifact — The Silent Pack is sure to make their servant's patronage a challenging one.

### Vesper

<section class="block readaloud"><p></p></section>

Warlocks who enter a covenant with Vesper know this mysterious Casia to be a soft-spoken entity, full of puzzling subtlety. Vesper is said to visit her Warlocks in their dreams, where she leads them on wild and curious escapades through illusory corners of The First Forest. To seek arcane power through Vesper is to learn your spellcasting through her otherwordly riddles, her own curious proclivities, and her endless tests of wit.

### Raineka

<section class="block readaloud"><p></p></section>

Warlocks of Raineka are uncommon, but not altogether unheard of. Although Raineka is one of Ember's shard gods — with a host of divine adherents at her service — her influence reaches to arcane spellcasters as well. Warlocks of Raineka astutely recognize her primordial qualities, and strike their otherworldly pacts to beseech her for arcane abilities beyond mortal ken.

## Celestial Patron

Warlocks who make their pact with a Celestial patron harness the otherworldy power of Luxarum with their spells, drawing upon the radiant magic of the Realm of Endless War. When choosing this subclass, pick one or more of the following Deities to serve as your character's Celestial patron.

### Juriel

<section class="block readaloud"><p></p></section>

Warlocks of Juriel are often brought into the Tyraphem Lord's loosely-organized fold via a sequence of fateful events — such as the discovery of a Luxaran artifact, an encounter with a mysterious celestial creature, or as the anointed descendent of a powerful Railen dynasty. Much like Juriel themself, Warlocks who make a pact with this fair-minded celestial tend to be people of poise and integrity (even if their personal definitions of these concepts appear to differ from popular or local opinions). Juriel's requirement for his servants is simple: they must swear allegiance to his cause and take up arms against all other Tyraphem Lords.

### Taryakel

<section class="block readaloud"><p></p></section>

Warlocks of Taryakel have been known to walk the surface of Ember as long as the Inner Realms themselves have existed. Indeed, Taryakel claims to be one of the oldest celestials of the cosmos, and the subtle impact of this longevity can be seen throughout the known world. Warlocks who strike a pact with this ageless Tyraphem Lord are known for their patience, because they must surely contend with Taryakel's inscrutable wisdom when they least expect it — a challenge that can take most mortals a lifetime to master.

### Lantyr

<section class="block readaloud"><p></p></section>

Warlocks of Lantyr are rare, but not altogether unheard of. Although Lantyr is one of Ember's Elder Gods — with a host of divine adherents at her service — her influence reaches to arcane spellcasters as well. Warlocks of Lantyr astutely recognize the celestial qualities of The Sun, and strike their otherworldly pacts to beseech her for arcane abilities beyond mortal ken.

## Fathomless Patron

Warlocks of Ember who choose a Fathomless patron can harness the power of Ember's deep, preternatural waterways for their spells, drawing upon the aqueous magic of the living planet's circulatory system. When choosing this subclass, pick one or more of the following Deities to serve as your character's Fathomless patron.

### Godkiller Orinoth

<section class="block readaloud"><p></p></section>

Warlocks who make a pact with the beguiling leviathan known as Godkiller Orinoth are some of Ember's most insatiable arcane spellcasters, driven by their own allegiance to the unfathomable yearning of Orinoth's preternatural hunger. The first lesson a Warlock of Godkiller Orinoth usually learns is how casually cruel the leviathan can be, for the disembodied conversations with this legendary serpent are riddled with manipulation and abuse — qualities the Warlocks tend to further exhibit themselves as their otherworldly covenant with Orinoth grows stronger.

## Fiend Patron

Warlocks of Ember who choose an Fiend patron can harness the uncanny power of Signara for their spells, drawing upon the esoteric magic of the Realm of Ferocious Curiosity. When choosing this subclass, pick one or more of the following Deities to serve as your character's Fiend patron.

### Kerastes

<section class="block readaloud"><p></p></section>

Kerastes enjoys pitting his various servants against each other (fiend and mortal alike), a trait Warlocks of Kerastes must learn to embrace if they wish to know the powerful arcane secrets of the duplicitous Daemos mastermind. Kerastes possesses a keen and rather cruel intelligence, which colors every interaction with this wily Daemos with a certain amount of conflict. Warlocks who make a pact with Kerastes find themselves in his service via a number of ways — like a fateful Signborn bloodline, the otherworldly mysteries of an alien text, or the receipt of a cursed Signaran artifact.

### Nalgomith

<section class="block readaloud"><p></p></section>

Unlike many of Ember's otherworldly patrons, Nalgomith is commonly known to sometimes walk the surface of the living planet to commune with his followers. However, this gregariousness is no substitute for common courtesy — a quality the fiendish Daemos seems to lack, despite his relative patriarchal generosity. While Nalgomith is overtly fair to his Warlocks, he still views them as pawns on a chess board; and this air of utility becomes readily apparent to those who might benefit from Nalgomith's patronage.

### Alar

<section class="block readaloud"><p></p></section>

Warlocks of Alar are uncommon, but not altogether unheard of. Although Alar is one of Ember's Elder Gods — with a host of divine adherents at her service — her influence reaches to arcane spellcasters as well. Warlocks of Alar astutely recognize the eldritch and draconic qualities of The First, and strike their otherworldly pacts to beseech her for arcane abilities beyond mortal ken.

## Genie Patron

<section class="block gamemaster"><p>The term "Genie" is not used in Ember. However, the concept of Genie Patrons persists via the Elemental Sovereigns — a group of deities who preside over Ember's elemental moons.</p></section>

Warlocks of Ember who choose an Elemental Sovereign as their patron are able to summon the preternatural power of one the living planet's elemental moons. When choosing this subclass, pick one of the following Deities to serve as your character's Elemental Sovereign patron.

### Areyter

<section class="block readaloud"><p></p></section>

Warlocks of Areyter can harness the aqueous power of Mayis, thanks to the Elemental Sovereign's cosmic association with the Water Moon. Because of the ubiquity of Ember's moons and the common phenomenon of lunar attunement, Areyter will often make herself known to Mayis-attuend mortals who possess a measurable affinity for arcane spellcasting. Aryeter communicates with her followers and servants via mystical apparitions, such as a phantasmagorical image appearing in a cascade of sea spray or a reflective pool of water. She is regarded for her ceaseless calm.

### Lorgi

<section class="block readaloud"><p></p></section>

Warlocks of Lorgi can harness the incendiary power of Ragen, thanks to the Elemental Sovereign's cosmic association with the Fire Moon. Thanks to the ubiquity of Ember's moons and the common phenomenon of lunar attunement, Lorgi will often make himself known to Ragen-attuned mortals who possess a measurable affinity for arcane spellcasting. Lorgi will often appear to his followers and servants as mystical apparitions in the flickering flames of ritual fires or the torchlight of the chosen. He's known to be friendly, helpful, and involved.

### Nymbohr

<section class="block readaloud"><p></p></section>

Warlocks of Nymbohr can harness the formless power of Aura, thanks to the Elemental Sovereign's cosmic association with the Air Moon. Despite the ubiquity of Ember's moons and the common phenomenon of lunar attunement, Nymbohr remains a somewhat elusive entity, but will certainly make himself known to those he deems most worthy. Nymbohr manifests to his followers as a disembodied voice on the wind. He is known to be vague, aloof, and relatively indifferent.

### Slinerak

<section class="block readaloud"><p></p></section>

Warlocks of Slinerak can harness the primal power of Cora, thanks to the Elemental Sovereign's cosmic association with the Earth Moon. Because of the ubiquity of Ember's moons and the common phenomenon of lunar attunement, Slinerak will often make himself known to Cora-attuend mortals who possess a measurable affinity for arcane spellcasting. Slinerak is a vulgar entity, and has no qualms about appearing to his followers and servants (or their enemies) by momentarily reshaping the earthly terrain around them — which often appears as mutable and inconsistent as his values.

## Great Old One Patron

Warlocks of Ember who choose an Great Old One patron can harness the alien power of The Abyss for their spells, drawing upon the eldritch magic of the Far Outside. When choosing this subclass, pick one or more of the following Deities to serve as your character's Great Old One patron.

### Sitheera

<section class="block readaloud"><p></p></section>

No matter their alliances or personal agendas, Warlocks of Sitheera are all connected by the fateful web of the Spider Goddess' inscrutable otherworldly whims. To serve the Watcher is to become one with her furtive network of acolytes and adherents, even if a Warlock pursues this service in relative solitude. Sitheera is known to speak to her Warlocks via the mundane arachnids of Ember (among other, more mystical methods), and treats each arcane spellcaster in her service as one of her own children. Whether matronly support or manipulation in disguise, Sitheera's otherworldly encouragement is something each Warlock of her loose order must content with.

### Herald of the Whispering Choir

<section class="block readaloud"><p></p></section>

Warlocks who make a pact with the Herald of the Whispering Choir are often driven by an unparalleled curiosity, a trait held in high esteem by the Herald itself. Furthermore, these eldritch spellcasters tend to stand out as pariahs of normal society, even when they hold positions of relative influence or power. And whatever their occupation, many Warlocks of the Herald find themselves called to venture to the Obsidian Desert at least once in their lifetimes on a pilgrimage to commune with the Herald's undying corpse — which mysteriously lingers somewhere beneath the region's blistering sands.

## Undead Patron

Warlocks who choose Undead patrons are almost universally evil in nature and alignment. Drawing upon unholy necromantic energies and powers that twist and corrupt the life around them. In almost every case, Warlocks who dabble with necromancy and follow undead Patrons are not only shunned but actively hunted in the majority of Cultures on the surface of Ember. When choosing this subclass, pick one or more of the following Deities to serve as your character's Undead patron.

### Elwin Davos

<section class="block readaloud"><p></p></section>

Warlocks who make a pact withElwin Davos are his vanguard, his corrupters, and his schemers; they destabilize kingdoms, infiltrate noble courts, and seed the rot of undeath. If a kingdom is peaceful, a warlock of Elwin must bring war. If a city is pure, they must poison its wells with the curse of vampirism. You do not serve Elwin by hiding in the dark; you serve him by building an empire of the dead in his name.

### Menis Valegar

<section class="block readaloud"><p></p></section>

Warlocks who make a pact withMenis Valegar is to be the assistant to an insane, uncaring Zaskryn. Menis demands information on the nature of life and death, and his warlocks are granted power solely to fracture the psyches of the living. You are sent to shatter minds, drive holy men to madness, and harvest the raw, terrified spirits of those who die in absolute despair. Every soul his warlocks reap in his name is dragged back to his workshop to be peeled, broken, and ripped apart. If a warlock fails to bring him fresh souls to dissect, Menis's manic attention will inevitably turn to the warlock’s own mind, chipping away at their sanity piece by piece.

## Overview

Warlocks are arcane spellcasters who gain their magic power from a fateful pact made with a mysterious, often otherworldly entity. Whatever causes a Warlock to seek out the knowledge they so desire, they manage to procure it at a great cost — for the whims of a Warlock's patrons must be met if the spellcaster's own power is to grow. Thus, a Warlock and their otherworldly patron are bound by a cosmic thread that connects each of their destinies to one another (for better and worse).