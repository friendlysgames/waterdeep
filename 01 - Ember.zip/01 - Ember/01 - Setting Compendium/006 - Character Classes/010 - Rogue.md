# Rogue

Rogues of Ember are a resourceful lot, marked by disparate backgrounds but united by one great fascination: opportunity. Rogues rely on their wide array of skills to fulfill their often equally varied goals. Stealth and chicanery are often employed by any given Rogue in pursuit of their own personal agenda, but they also tend to offer their expertise to larger groups (where profit or favor can be found in steady measure). Anyone in Ember can become a Rogue, and nearly every town in Aterica has at least one of these adaptable scoundrels in their midsts.

## Arcane Trickster

Arcane Tricksters supplement their abilities of stealth and subterfuge with spells and other magical enhancements, and are known to exist among almost every civilization on Ember. Organizations like the Anachraenum of Ordain and the Kelmezian thieves' guilds of Old Carinth are known to employ Arcane Tricksters within their ranks, who serve these groups as frontline explorers and deft invaders of enchanted places. Throughout the Arctus Plateau, a great deal of these sorcerous Rogues are also followers of the shard god Aythorn, a wily deity of mischief and trickery.

## Assassin

The deadly Rogues known as Assassins are formidable killers, masters of surprise whose trade is murder. Rogues of this type are known to occupy most civilized places of Aterica, where they go relatively unseen and unheard by the masses. Assassins are most common, however, within the Kelmezian City States — where the most dangerous Rogues in the world can be found (if you know who to ask). Assassins are also skilled in the ways of poison, and utilize it with deadly effect; it's no wonder, then, that these murderous Rogues are sometimes hired by villains of Ember's high society who wish to keep a low profile themselves.

## Phantom

A Phantom Rogue's mystical connection with death gives them preternatural insight into Ember's Soul Cycle, a knowledge they use to stunning effect both offensively and defensively throughout the course of adventuring. Rogues of this type are exceedingly rare, and can learn the supernatural tools of their trade through a variety of ways. The most common touchpoint for these macabre Rogues is their introduction to one of countless secret organizations that serve Sockets, the Elder God of Death — helping to manifest his divine balance of life and death (whether they know it or not).

Phantoms of Ember can roll on the Arcturian Trinkets Table to determine their various Tokens of the Departed at Level 9.

## Scion of the Three

<section class="block gamemaster"><p>The trio of evil gods known as the "Dead Three" do not exist in Ember. However, the concept of the Scion of the Three subclass persists via a select triumvirate of Ember's god-like beings: Menis Valegar, the Lord of Torment; Sitheera, The Spider Goddess; and Xalarax, Omen of the Evernight.</p></section>

The occult gifts of this macabre Rogue subclass come from a trio of malevolent God-Like Beings. Many Scions don't know much at all about the specific deities who power their macabre boons, but these unholy Rogues pay their fealty in illicit deeds nevertheless, learning what they can as long as their luck holds out. Furthermore, the triumvirate of deities who comprise a Scion's eponymous "Three" have little in common other than their inscrutable otherworldly nature — the aims and methods of Ember's gods are each their own.

At Level 3, Scions of the Three in Ember choose one of the following for their Dread Allegiance: Menis Valegar, Sitheera, or Xalarax. The corresponding Damage Resistances and Cantrips gained by this feature are detailed below.

<table><tbody><tr><td data-colwidth="146"><h4>Deity</h4></td><td data-colwidth="182"><h4>Damage Resistance</h4></td><td><h4>Cantrip</h4></td></tr><tr><td data-colwidth="146"><p>Menis Valegar</p></td><td data-colwidth="182"><p>Psychic</p></td><td><p><em>Minor Illusion</em></p></td></tr><tr><td data-colwidth="146"><p>Sitheera</p></td><td data-colwidth="182"><p>Poison</p></td><td><p><em>Blade Ward</em></p></td></tr><tr><td data-colwidth="146"><p>Xalarax</p></td><td data-colwidth="182"><p>Necrotic</p></td><td><p><em>Chill Touch</em></p></td></tr></tbody></table>

## Soulknife

These rare and peculiar Rogues are capable of using psionic mind power to bolster their attacks and enhance their slyness. The origins of a Soulknife's psionic powers can be varied and mysterious; but whatever the source of this power, it is usually esoteric or uncanny in nature. Soulknife Rogues are extremely rare throughout Ember, and tend to be servants of one of the fiendish Daemos of Signara — who "bless" these mindful Rogues with supernatural alien psionics to serve their inscrutable ambitions. Soulknife Rogues have also surfaced from the Cascilian Republic, where their anti-magic philosophies have cultivated new ways of wielding the metaphysical energies of the cosmos.

## Thief

Thieves are the most ubiquitous type of Rogue to be found on Ember. Wherever there are valuables worth stealing, purses worth cutting, or traps worth springing, a Thief can be found nearby. These ambitious Rogues are relatively common in bustling settlements of industry like Ordain and Arcturel — and are actually quite prevalent areas such as the dangerous Tayan slums of Caren’ac, or the lawless reaches of the Kalmezian City States. As members of the Nightwatch are fond of saying, "all the thieves in Old Carinth couldn't make it happen" and nothing's "fleeter than a Kelmezian thief."

## Overview

Armed with deception, wit, and lethal precision, Rogues are adventurers who rely on their cunning and stealth to exploit an enemy's weaknesses. These scoundrels are extraordinarily skillful, and are capable of more nimble approaches to combat than other classes — succeeding most when they strike from places unseen, clad in light armor, and equipped with swift weaponry. Masters of subterfuge and versatility, Rogues form the backbone of any party who aims excel at the arts of trap-springing and trickery.