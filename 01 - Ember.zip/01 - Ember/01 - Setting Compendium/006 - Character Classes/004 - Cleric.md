# Cleric

Clerics in Ember emerge from the followers and priesthoods of the various Shard Gods or Elder Gods in Ember's pantheons. While most Clerics don't have a direct relationship with their deity of choice (such as persistent one-on-one communication), some Shard Gods in particular maintain a retinue of faithful Clerics with whom they hold close communion.

The following entries on Cleric Subclasses feature suggestions for which Deities would be most likely to favor a Cleric of a certain domain. Because faith is a personal belief unique to each character, we've featured a list of the various deities and their associated domains — leaving the character's "call to faith" entirely up to you.

## Knowledge Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Sigil

<section class="block readaloud"><p></p></section>

Knowledge Clerics of Sigil tend to be scholars and academics themselves, in addition to whatever other roles they occupy in life. Clerics of Sigil who adhere to this domain are not uncommon to the Arctus Plateau, home to Sigil's terrestrial residence known as Oldcraft Lodge. Students of the Rhivan Star Academy and the Obsidian Antiquaries of Kessia are also known to host several Clerics of Sigil amongst their ranks.

### Spectra

<section class="block readaloud"><p></p></section>

Knowledge Clerics who venerate or admire the world's most esoteric mysteries tend to be worshippers of Spectra, who rewards her most faithful servants with blessings of divine knowledge and a greater understanding of arcane lore. Knowledge Clerics of Spectra are often appointed as protectors of the world's most influential mages and arcanists, and will invariably seek out relationships that strengthen their own connection to the living planet's magical forces.

## Life Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Alar

<section class="block readaloud"><p></p></section>

Life Clerics of Alar honor the elder god's role in creation by helping to sustain the positive energies she has fostered for centuries untold. Because she walks the terrestrial corners of Ember so frequently, worshippers of Alar can be found anywhere from the Tayan Empire to the shores of Ordain.

### Lantyr

<section class="block readaloud"><p></p></section>

Life Clerics of Lantyr generally consider themselves to be the mortal vessels of her unearthly light, and live their lives in holy veneration of her role as one of the most profound life-sustaining forces in the cosmos. Clerics of Lantyr are common to all corners of Ember, but are perhaps most prevalent throughout the sun-marked reaches of Kessia, the Radiant Continent.

### Nite

<section class="block readaloud"><p></p></section>

Life Clerics of Nite revere the primal essence of creation, and view the emergence and persistence of life (however chaotic it may be) as the most sacred force of the cosmos. Clerics of Nite emerge from all walks of life, but can often be found in those places where strife meets resolve — like the primal wilderness of the Corebright Forest and the Duskflare Jungles, or the northern reaches of Fikost (where Nite's calamitous warmth is most welcome).

### Raineka

<section class="block readaloud"><p></p></section>

Life Clerics of Raineka are known to be some of Ember's most prestigious healers and diplomats, and revere the Rainbringer herself as one of the most calming and restorative forces in the cosmos. Because of Raineka's relative youth, her worshippers throughout Ember are fewer in number than other gods of The Nineteen; but while the adherents of Raineka may be harder to find, they are certainly easier to befriend, and always eager to broker peace and communion.

### Remira

<section class="block readaloud"><p></p></section>

Life Clerics of Remira are known for the intimacy of their succor, and their rites and rituals tend to be sensual, rapturous occasions welcoming to all. Remira is popular among Clerics who also have a penchant for artistic skill or appreciation, and her influence is on a steady rise throughout Aterica in places of storied art and industry — like Ordain, Old Carinth, or far-off Kalvard.

### Vekalla

<section class="block readaloud"><p></p></section>

Life Clerics of Vekalla are some of Ember's most intrepid healers, and tend to find themselves on the forefront of travel, exploration, and conflict — things in life where a swift resolve is usually the most beneficial one. As servants of The Whispering Wind, these Life Clerics are as widespread as the winds of Ember themselves; but it's no surprise to find the highest concentration of Vekalla worshippers among seafaring people like the Cascilian and the Rhivan, or mountainside folk such as the Kithil of the Kaustic Hinterlands.

## Light Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Lantyr

<section class="block readaloud"><p></p></section>

Light Clerics of Lantyr generally consider themselves to be the mortal vessels of her unearthly light, and revere The Sun's role in the cosmos as an unmatched force of revelation. Clerics of Lantyr are common to all corners of Ember, but are perhaps most prevalent throughout the sun-marked reaches of Kessia, the Radiant Continent.

### Lumé

<section class="block readaloud"><p></p></section>

Light Clerics of Lumé are generally regarded as the most generous and benevolent of her faithful, and stand as stalwart guards against the encroaching evil of the Moiran Evernight. Indeed, the Flame Warden's physical presence in the Lumek Homelands ensures her servants feel connected and safeguarded by her holy light. Clerics of Lumé can communicate with her from afar, but she also welcomes any adherent who would seek her personal counsel.

### Steelsong

<section class="block readaloud"><p></p></section>

Light Clerics of Steelsong recognize their goddess in every spark of creation and each ember of a blacksmith's forge. Arguably less militaristic than other Clerics of the domain, these joyous priests tend to be a more celebratory force in the world, and praise their goddess as a champion of integrity and revelation. Steelsong's worshippers are numerous, but most of them can be found among the Arcturian, Ordani and Waerd peoples.

### Volta

<section class="block readaloud"><p></p></section>

Light Clerics of Volta are often explorers of unseen places and revealers of the unknown. Volta is a well-recognized deity, and is popular among cultures who respect progress, change, and globalism — like the gregariously industrious Ordani, the sea-faring merchants of the Cascilian Republic, and the Rhivan peoples of the far-off Star Academy. And Volta's origins during the Age of Sunlight have contributed to a lasting legacy within Nalvani and Lorai societies as well.

## Order Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Lanespear

<section class="block readaloud"><p></p></section>

Order Clerics of Lanespear tend to strive for perfection in everything they do, and work to embody the shard god's immaculate sense of precision when it comes to matters of discipline and martial combat. Clerics of Lanespear are most popular among the Lowlands, where the chaotic southern reaches of the Duskflare Jungles are overrun with monstrous inhabitants in dire need of law and order.

### Obrisire

<section class="block readaloud"><p></p></section>

Order Clerics of Obrisire revere the Bone Serpent's penchant for measured survival, and their rites and rituals are said to be symbolic recreations of Obrisire's immaculate patterns of logic and reason. Communion with Obrisire is remarkably more esoteric than fellowship with other shard and elder gods of Ember, but the Ancient Beast manages to find ways of communicating with the faithful when they least expect it. Clerics of Obrisire are most common amongst the people of the Cascilian Republic and the ancient mystery-laden Sedyri.

### Sockets

<section class="block readaloud"><p></p></section>

Order Clerics of Sockets venerate the elder god's stewardship of the Soul Cycle above all else, and their faith is a reflection of the painstaking structure the Soul Cycle must maintain for Ember's cosmos to endure. Because of this rather dogmatic philosophy, Order Clerics of Sockets are often just as rigorous in their practices. These Clerics generally consider themselves to be terrestrial extensions of the elder god's divine will, live their lives accordingly — marked by rote, routine, and tireless dedication to the Soul Cycle itself.

### Vekalla

<section class="block readaloud"><p></p></section>

Order Clerics of Vekalla strive to embody the immaculate discipline of their goddess via their worship of the living planet's primal weather patterns. As servants of The Whispering Wind, these Life Clerics are as widespread as the winds of Ember themselves; but it's no surprise to find the highest concentration of Vekalla worshippers among seafaring people like the Cascilian and the Rhivan, or mountainside folk such as the Kithil of the Kaustic Hinterlands.

## Peace Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Raineka

<section class="block readaloud"><p></p></section>

Peace Clerics of Raineka are known to be some of Ember's most prestigious healers and diplomats, and revere the Rainbringer herself as one of the most calming and restorative forces in the cosmos. Because of Raineka's relative youth, her worshippers throughout Ember are fewer in number than other gods of The Nineteen; but while the adherents of Raineka may be harder to find, they are certainly easier to befriend, and always eager to broker peace and communion.

### Sigil

<section class="block readaloud"><p></p></section>

Peace Clerics of Sigil tend to be learned diplomats and masters of tranquility. Clerics of Sigil who adhere to this domain are not uncommon to the Arctus Plateau, home to Sigil's terrestrial residence known as Oldcraft Lodge. Students of the Rhivan Star Academy and the Obsidian Antiquaries of Kessia are also known to host several Clerics of Sigil amongst their ranks.

## Trickery Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Aythorn

<section class="block readaloud"><p></p></section>

Clerics of Aythorn tend to be Trickery Clerics first and foremost. And while "The Trickster Thorn" isn't the only entity in the cosmos associate with this domain, Aythorn is the only real public-facing deity for Clerics of this ilk in modern day Ember. Aythorn tends to reward those followers who show the most interest and initiative in their efforts, and is eager to foster grand achievements from humble beginnings — as long as a little chicanery is manifested along the way. These days, Aythorn is popular throughout Aterica, but their oldest churches reside in the Tayan Empire (where Aythorn ascended to power).

## Twilight Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Malae

<section class="block readaloud"><p></p></section>

Twilight Clerics of Malae are somewhat rare among mortal of Ember, as most of her latter-day faithful tend to be monstrous in nature or otherworldly in origin. Nevertheless, the Queen of Curses is known to bless those who worship her with a divine mastery of the dusk. Twilight Clerics of Malae most often dwell on the fringes of society, but enclaves of her worshippers are known to exist where darkness holds sway — like the dreadful expanses of the Moiran Bonelands and the lightless reaches of the Duskflare Jungles.

### Sionia

<section class="block readaloud"><p></p></section>

Twilight Clerics of Sionia are exceptionally rare throughout Ember, and dedication to her faith comes at the cost of becoming a social pariah amongst most of Aterican society. Nevertheless, the Deathbinder has earned a reputation in recent years for bestowing her faithful Clerics with magnificent powers over light and dark. Just as Sionia dwells between the profound radiance of life and the cloying darkness of death, so do her Clerics become custodians of a liminal reality — where the apparent is obscured and the furtive is made seen.

### Thayloc

<section class="block readaloud"><p></p></section>

Twilight Clerics of Thayloc are stewards of holy light, locked in a constant conflict with the countless forces of darkness that threaten to extinguish it. Following Thayloc's exodus from the Lumarin Homelands at the hands of the Moiran Blood Barons, The Silver Bowman has become increasingly popular throughout Aterica — with militant temples and churches to be found everywhere from Ordain to Old Carinth.

### Thoma

<section class="block readaloud"><p></p></section>

Twilight Clerics of Thoma are the veritable firesides that the lost and lonely of the world can gather next to when the darkness of the cosmos is too much to bear. These vigilant Clerics can be servants of calm when restlessness strikes, but they're also champions of obscurity when guile is needed most. And thanks to Thoma's own graciousness and personal curiosity, her Twilight Clerics actually end up meeting her in person for tea at one time or another. As the Kithil of the Kaustic Hinterlands are fond of saying, "There's always time for a visit from Grandmother Comfort."

### Volta

<section class="block readaloud"><p></p></section>

Twilight Clerics of Volta are often explorers of unseen places and revealers of the unknown. Volta is a well-recognized deity, and is popular among cultures who respect progress, change, and globalism — like the gregariously industrious Ordani, the sea-faring merchants of the Cascilian Republic, and the Rhivan peoples of the far-off Star Academy. And Volta's origins during the Age of Sunlight have contributed to a lasting legacy within Nalvani and Lorai societies as well.

## War Domain

When choosing this subclass, pick one or more of the following Deities to serve as the source of your character's divine power.

### Janar

<section class="block readaloud"><p></p></section>

War Clerics of Janar view the art of the hunt as a sacred phenomenon, and manage to apply a similar reverence to all life's tasks — viewing each challenge through a lens of "predator versus prey," with the faithful serving as a mortal extension of Janar's primal will. Due to his legendary history stretching back to the Age of Beasts, Janar is worshipped in some fashion among nearly all of Aterica's people; but Janar's War Clerics in particular have historically stood out as noteworthy practitioners of divine magic in times of conflict.

### Katu

<section class="block readaloud"><p></p></section>

War Clerics of Katu seek to embody the cold temperament of their shard god with their own icy, pragmatic approach to conflict. And Katu's chaotic personality is made manifest by the awesome might that his War Clerics wield in battle, each one of them another stone in the shard god's eternal hail storm. Katu is tremendously popular throughout all of Aterica's seafaring nations, from the peninsulas of the Cascilian Republic to the shores of Oakengarde.

### Lanespear

<section class="block readaloud"><p></p></section>

War Clerics of Lanespear tend to strive for perfection in everything they do, and work to embody the shard god's immaculate sense of precision when it comes to matters of discipline and martial combat. Clerics of Lanespear are most popular among the Lowlands, where the chaotic southern reaches of the Duskflare Jungles are overrun with monstrous inhabitants in dire need of law and order.

### Lumé

<section class="block readaloud"><p></p></section>

War Clerics of Lumé are regarded as some of her most dedicated and tireless followers, and are heralded for their crucial frontline role in the ongoing war against the Moiran Blood Barons. The Flame Warden's physical presence in the Lumek Homelands ensures her servants feel connected and safeguarded by her holy light. And while Clerics of Lumé can communicate with her from afar, she also welcomes any adherent who would seek her personal counsel.

### Thayloc

<section class="block readaloud"><p></p></section>

War Clerics of Thayloc dedicate their lives to the concept of safety through retribution, and are known to be some of the world's most effective slayers of undead creatures. Following Thayloc's exodus from the Lumarin Homelands at the hands of the Moiran Blood Barons, The Silver Bowman has become increasingly popular throughout Aterica — with militant temples and churches to be found everywhere from Ordain to Old Carinth.

## Grave Domain

<section class="block gamemaster"><p>It's recommended that you don't learn the true nature of the Howling One as part of your backstory. </p></section>

Among the Ossarchate are a number of living, twisted mortals called the Silent Acolytes. They are devoted followers of an entity known as the Howling One, the god of Undeath. Although they are technically servants of the Blood Barons like others in the Ossarchate, the Silent Acolytes tend to keep to themselves, and the Blood Barons prefer this separation. This is because the Silent Acolytes worship the Howling One directly and are seen as the entity's priesthood within the Ember Cosmos, and are often completely absorbed in their twisted rituals and prayers. They are also regarded as utterly insane and beyond the Blood Barons' control in most situations. Many believe that the Silent Acolytes are the group responsible for pulling the Pale Monoliths into the physical world and may have caused the Evernight itself. Silent Acolytes are utterly reviled throughout Ember and are killed on sight in most other nations outside the Ossarchate. However, they do travel to spread the word of their screaming god, keeping their allegiance secret and their abilities hidden using a White Stone Rosary.

<section class="block hazard"><h4>Reviled Magic</h4><p>Caution: Undeath in its many forms is considered highly problematic among the people of Ember generally and goes far beyond merely being frowned upon. It is considered Reviled Magic and therefore kept hidden if at all possible.</p></section>

## Overview

Clerics are divine spellcasters whose magic is powered by the Cleric's personal faith in their god, and the deific blessings that god provides in return. Different from normal priests and acolytes, Clerics are adventurers who carry their particular brand of spiritualism throughout the world, spreading the word of their god and proselytizing through their heroic (or villanous) actions.