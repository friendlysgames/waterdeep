# Foreword

Creating a living world as expansive and detailed as Ember is a lifelong dream for myself and others on our team. Each aspect of Ember’s lore; its geography, cosmology, cartography, history, ancestries, cultures, and more has been carefully developed so that every design choice is meaningful. While the Ember Setting is a wondrous and immersive piece of fiction in its own right, one of the fundamental goals behind its creation was to design a sprawling open-world game for Foundry Virtual Tabletop where its worldbuilding features and cosmology affect the day-to-day and even moment-to-moment mechanics of the game itself.

<section class="block gamemaster"><h4>Author of the Setting Compendium</h4><p>The Historian Laeora is responsible for writing the majority of the Settign Compendium in an in-universe voice, drawing on her own perspective, gathered notes, and experiences across the ages. Throughout the writing, there are also a few 1st-person notes from her that offer a new perspective on the lore, history, and events. </p></section>

### Mysteries of the Living Cosmos

As you delve into the lore and the intricacies of the setting, you'll notice the term 'Ember' frequently repeated. This is a deliberate design choice, “Ember” serves as the title, the name for the Cosmos, the world, and most intriguingly the enigmatic object at the very center of it all: the Heart of Ember. This serves as a solid foundation, a point of reference before the complexity of the setting begins to unfold.

Ember’s lore is a powerful foundation that supports and enhances gameplay with worldbuilding themes that appear consistently throughout the story from session one until the story’s ultimate conclusion. These worldbuilding concepts will be gradually unveiled to players as the game progresses without the need to master these topics beforehand. We hope you find the setting and incredible attention to detail as cool as we do, so if you are excited to learn about this lore and how Ember's cosmology interacts with gameplay, keep reading!

***Caeora***
*Creative Director and Lorekeeper*

## Overview

During the continuing development of the Ember Game and beyond, the Ember Setting will continue to evolve alongside it. It is regrettable and unfortunate that so many of my ideas and thoughts around the setting remain tied up in my head or in note form, which is too rough to share publicly. It has also become clear to me that the way ive written certain pieces of information or lore is sometimes not entirely the way I intended it to come across, and my writing ability itself is at fault.

If you come across information that is not clear or ideas and lore that references other pieces of content that seem critical to the understanding of that piece, it may be intentional, or it may be a mistake or simply unintended. Reach out and provide feedback if you can, and I will do my best to improve things so that what I have written really shines for everyone!