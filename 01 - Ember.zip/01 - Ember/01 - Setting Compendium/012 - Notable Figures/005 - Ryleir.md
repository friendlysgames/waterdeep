# Ryleir

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A young Carnal Dragon that lives in the shallow tunnels of the Pathways beneath the Arctus Plateau. Cunning and intelligent, they are a manipulator rather than a fighter and are shockingly happy to talk with mortals when they encounter them in return for information about the surface world. Strangely they have a keen desire to keep their word and although they do kill mortals they do so only when they have been betrayed or lied to in some way.