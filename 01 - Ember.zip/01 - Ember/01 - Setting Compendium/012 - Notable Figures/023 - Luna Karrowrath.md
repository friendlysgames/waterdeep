# Luna Karrowrath

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Luna Karrowrath is the Champion of Lumé, the highest-ranking warrior in service to the Shard Goddess and her most trusted confidant and friend. She is often tasked with investigating undead threats beyond the border of the Lumek Homelands.