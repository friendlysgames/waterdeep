# Caster Tusk

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Hunter extraordinaire, he previously prowled the depths of the Duskflare Jungles of the Lowlands but has been drawn to the Arctus Plateau to hunt the emerging megafauna for trophies. He is a boisterous, headstrong and powerful Kavir originally from the Bejak Tribelands, at 80 he is considered middle aged and wields a long spear like harpoon.