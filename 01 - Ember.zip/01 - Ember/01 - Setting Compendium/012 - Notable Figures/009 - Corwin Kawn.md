# Corwin Kawn

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Husband of Calyn Kariset, killed during the sacking of Yarino in 2,508 AS. Corwin was dashing, cunning, and extremely deadly with a single-bladed sword, one of the early supporters of Calyln's newly formed Tayan Empire. He was quick to secure power over the city of Kawn before pledging his services to the new Empress.