# Haldia

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Ancient Keth Druid who wanders the Corebright forest and technically leads the **Primalists**, though they have become lost among their animal form of a Greater Pratax for over a thousand years and only other druids can communicate with them.