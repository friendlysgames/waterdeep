# Calyn Kariset

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Calyn Kariset is the ruler of the Tayan Empire. She is known as the Dragon Empress or the Dragon Queen due to her fierce bond with the Dragon Velestrix.