# Ankarist Talken

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A stern Drakon with a determined expression and piercing golden eyes. Their martial training is immediately apparent, with thick leathers, padding, and armor covering almost their entire body. A huge two-handed sword, forged in a strange style, with a flared wide square tip is typically clipped to the back without a sheath.