# Karaxsus

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Karaxsus is a legendary Dragon known as the Flaming Dread that is said to live in the mountains north of the Corebright Forest. Various stories tell tales of a wingspan so large that they engulf entire towns and a maw large enough to swallow ships. Such stories are now told as legends, however, and it is not known if they are still alive, with the last sighting nearly two hundred years ago.