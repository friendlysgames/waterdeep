# Erisagosa

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Erisagosa is a sapient Leviathan who resides in the far north of the world. She is said to be the offspring of one of the ancient Wyrms of Akon and a Leviathan. She takes the form of a great ice wyrm that can fly through the air effortlessly. She is considered a minor deity by the Fikost.