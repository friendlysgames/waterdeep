# Norzi Ashigurin

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Norzi Ashigurin is the Shenin of the city of Lunari and the Lord of Storms, one of the most powerful rulers of the Maziran Kingdoms.