# Renara Talken

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Renara Talken is the leader of the Vanguard and daughter of Ankarist Talken.