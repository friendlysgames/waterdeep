# Avwynn Taol

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Avwynn Taol is mysterious figure that has a surprising and deep knowledge of the Heart of Ember and magic.