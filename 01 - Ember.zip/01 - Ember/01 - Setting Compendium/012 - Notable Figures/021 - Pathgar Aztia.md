# Pathgar Aztia

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Great Mender of the Bejak, Pathgar Aztia is an ancient Hulg'run that is over three thousand years old and fondly remembers the Shent. They are greatly revered by all Bejak but serve as more of a spiritual leader that helps kind the Tribes rather than directly give commands.