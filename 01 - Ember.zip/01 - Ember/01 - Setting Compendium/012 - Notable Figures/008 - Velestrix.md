# Velestrix

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Velestrix is a powerful Dragon of unknown age and lineage, she is bonded to the Empress of the Tayan Empire, Calyn Kariset. Velestrix is the largest Dragon even ridden by a Kirargy Knight and is often compared to the legendary Karaxsus in size.