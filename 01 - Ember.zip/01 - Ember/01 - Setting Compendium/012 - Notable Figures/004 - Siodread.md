# Siodread

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Siodread is a colossal Carnal Dragon that controls a massive region of bone-scattered lands and twisted spires between the Blood Barons and the Cascilian Republic. They are frequently appeased in secret by the Republic through sacrifices to abate their relentless hunger.