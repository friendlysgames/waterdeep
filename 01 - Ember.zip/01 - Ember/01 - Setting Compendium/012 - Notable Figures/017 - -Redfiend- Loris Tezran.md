# "Redfiend" Loris Tezran

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Tall, imposing, and with a powerful frame, "Redfiend" Loris Tezran somehow manages to appear sleek and refined despite the blatant strength and power he wields. As the official Ambassador to the Tayan Empire, Loris commands a small contingent of personal Tayan guards, and his ferocious mount Rakavi is never far from his side. He has a mane of dark hair, and dresses to impress, wearing only the finest clothing that the Tayan Empire produces.