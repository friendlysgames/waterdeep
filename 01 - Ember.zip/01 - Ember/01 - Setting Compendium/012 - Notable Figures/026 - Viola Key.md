# Viola Key

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Mistress of the Arcing, the leader of the Arcageris warrior monks. She currently resides in the Iron Bastion of Wick in the Lowlands. A renowned elderly warrior, she somehow managed to kill a Fire Dragon named Voradaess in her youth and now trains future monks in all manner of martial forms.