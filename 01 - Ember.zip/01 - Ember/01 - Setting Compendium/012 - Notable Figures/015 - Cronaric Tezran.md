# Cronaric Tezran

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Lord Cronaric Tezran is the head of House Tezran in the Tayan Empire and leader of the Drakon faction that follows Empress Calyn Kariset. He is a stern, unyielding Drakon who is unflinching in his loyalty to the Empress and leads the internal security of the Empire as the head of the mysterious and deadly Talon.