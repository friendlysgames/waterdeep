# Mournax

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Mournax is a horrifying monster of nightmares that is said to prey upon the ships and settlements of the Lowlands and has been said to roam across the entire world in pursuit of relics and power. They are a Vile Dragon of impressive age and power that resides upon the Starshield continent and have survived by effectively hiding in one of the few places the deities of Ember refuse to tread.