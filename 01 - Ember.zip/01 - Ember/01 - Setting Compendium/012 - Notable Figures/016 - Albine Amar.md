# Albine Amar

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Albine Amar is the current Director of the Rhivan Star Mages, one of the most esteemed, brilliant, and powerful Star Mages of his generation. Amar often teaches students personally at the Star Academy for most of the year. However, they are known to travel extensively, and it would not be unusual to find them in far-flung locations of the world.