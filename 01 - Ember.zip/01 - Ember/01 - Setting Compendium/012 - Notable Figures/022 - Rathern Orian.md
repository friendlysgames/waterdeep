# Rathern Orian

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Rathern Orian is the current High King of the Wardcall, a position he has held for the last 43 years since the ending of the vicious civil war that ravaged the Kingdoms of Wintec, Katic, and Pertta. Once a powerful and well-respected leader, his falling health has reignited tensions across the Wardcall.