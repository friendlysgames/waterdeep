# Briana Brewer

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The famous travelling Bard who hails from the distant Great City of Kasarain in Kessia. Currently residing in Ordain she is a fun-loving and carefree traveller and is guarded by her friend Kroma a Bjordan Vrjnhar.