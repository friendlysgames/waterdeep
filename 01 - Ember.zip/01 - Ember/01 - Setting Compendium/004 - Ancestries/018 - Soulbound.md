# Soulbound

Most souls on Ember leave their physical forms behind when they die, moving on to the City of Eternas and going through the Rite of Passage that transitions them into the Spiritlands. The Soulbound are the rare exception, remaining tethered to their bodies by a deeply important goal that must be completed before they can leave their former mortal life behind. The tether between a Soulbound's immortal soul and their unliving mortal form is represented by a physical soulmark, which restricts their existence while allowing it to continue long enough for them to set their Unfinished Business to rest and willingly move on.

The willingness to leave the mortal world behind distinguishes Soulbound from the undead of Ember, whose corrupted spirits and souls seek to stay on Ember forever. But being Soulbound is not without its dangers — Soulbound feel a constant pull towards Eternas. Resisting this pull, and the cosmic order that it represents, can corrupt a Soulbound over time, leading to them becoming one of the undead.

Becoming Soulbound is extremely rare, and forces the character to live with the Soulmark in addition to the attributes gained from their original ancestral origin. The effects can be difficult at the best of times, making becoming Soulbound a double-edged blessing - as arduous and draining as it is appealing, and only found in the rarest of circumstances.

## Overview

The Soulbound are mortals whose souls cannot or will not move on after death. Soulbound characters can hail from any ancestry, culture, or walk of life, but they are all united by a common element: every Soulbound has some Unfinished Business that tethers the living essence of their soul to their unliving mortal form. Unlike the undead, who are corrupted or twisted by evil forces, these souls simply defy the constant pull towards the city Eternas and its Rite of Passage until they have completed their final tasks.