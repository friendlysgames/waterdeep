# Shana Mountains

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Shana Mountains are a massive range of peaks that spans across Aterica, which are otherwise commonly referred to as the Giants Mountains or the Spine of Ember. These peaks were home to the ancient Shent culture, which built many wondrous structures across and beneath its peaks. The Shana Mountains are often categorized into three ranges: southern, middle, and northern.