# Jekaros

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Jekaros is spoken of in hushed tones as the "Cursed Continent," a place so reviled that few dare even speak of it. Much like the Spiritlands, it is a place you can technically travel to, but unlike the Spiritlands, Jekaros is considered a realm of such fear and terror that no one dares disturb it.