# Atou

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Atuo is one of the most mysterious places on the surface, surrounded by powerful esoteric energies, hidden from view by swirling blue mists; even powerful scrying magic fails to penetrate far. Some of the most powerful entities in the cosmos, including deities, have been repelled by its power.