# The Starshield

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Starshield is one of the smallest continents, located at the precise center of the world's surface, with eight points that roughly align with the cardinal and intermediate directions of Ember itself. The Starshield was once the center of everything. It is here that the ancient Aedir built their vainglorious empire thousands of years ago, along with their crowning achievement — the Sun Tower.