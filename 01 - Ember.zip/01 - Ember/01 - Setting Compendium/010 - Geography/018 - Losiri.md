# Losiri

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Losiri is known as the Swirling Edge, it is the ocean that falls away at the very southern edge of the World of Ember.