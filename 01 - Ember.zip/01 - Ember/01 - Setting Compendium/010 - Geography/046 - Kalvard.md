# Kalvard

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A towering city built upon a massive spire of ice that stands precariously in the middle of Hurricane Bay at the center of the Oakengarde continent. It has withstood the elements and dangers that surround it for countless generations of Oaken people of the Vrjnhar.