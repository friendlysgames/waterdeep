# Yawning Sea

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Yawning Sea lies between the Lumek Homelands and the Lowlands, with the Cascaal Peninsula to the north. Deep trenches and dark waters are home to terrible ancient monsters that often rise to the surface and attack passing ships.