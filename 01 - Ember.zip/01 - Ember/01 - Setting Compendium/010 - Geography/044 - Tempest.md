# Tempest

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A distant and mysterious fortress city of western Kessia, a war-torn settlement of storms and battle-hardened citizens.