# Wesk

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Wesk is the western ocean on the surface of Ember, often referred to as the Untamed Edge or the Untamed Ocean.