# Akazea

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Akazea is a sub-continent that lies far to the west, and it's separated from the continent of Aterica by the Crossing Sea. Akazea is one of the largest subcontinents on Ember's surface, and it is home to many different biomes and environments. The lands are extremely mountainous, with many towering peaks and plateaus, gorges, and ravines.