# Centia

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Centia is known as the Carrow Ocean, home to a mysterious ocean dwelling ancestry.