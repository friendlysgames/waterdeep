# Serpentas

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Serpentas is known as the Southern Ocean, a vast stretch of water said to be composed of a deadly poison.