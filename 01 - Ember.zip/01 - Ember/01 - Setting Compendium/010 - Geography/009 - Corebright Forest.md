# Corebright Forest

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Corebright Forest is made up of many towering Elderbark trees that cover a colossal expanse at the centre of the Aterican continent.