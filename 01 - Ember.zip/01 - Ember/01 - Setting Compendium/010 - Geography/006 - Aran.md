# Aran

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Aran Sub-Continent, also known as the Aran Peninsula, is a pivotal region in the history of Ember, as it is the birthplace of the ancient Jarn and then Humanity. It is an extremely ancient land filled with lost and forgotten ruins, incredible artifacts, and dangerous creatures. Although it was the birthplace of Humanity almost three and a half thousand years ago, its relevance has diminished greatly, and humans are no longer the dominant species in the region. Instead, the ancient city of Ancalen is ruled by the Railen people, who treat human relics and history with considerable disdain.