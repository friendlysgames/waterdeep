# Soarel

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Soarel is known as the great northern ocean, and also called the Hoarfrost Edge as the waters of Ember fall away into the Sea of Stars.