# Vaznor

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Vaznor is a massive region in the north of the continent of Aterica. it is a cold, desolate place, filled with ancient ruins, frigid tundras, and howling tribes of vicious Trolls.