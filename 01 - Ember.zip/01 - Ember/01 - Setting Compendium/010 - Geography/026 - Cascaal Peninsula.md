# Cascaal Peninsula

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Cascaal Peninsula is a golden land filled with soft grasses, gentle hills, and scattered groves of forests. It is surrounded by waters, bays, shallow seas, and lakes, with plenty of natural resources to support the burgeoning Cascilian Republic.