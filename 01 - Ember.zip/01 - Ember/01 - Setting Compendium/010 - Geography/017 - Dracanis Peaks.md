# Dracanis Peaks

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Dracanis Peaks are home to a large population of Cruel Dragons, with reports of over ten fully grown adults living among the towering mountains peaks.