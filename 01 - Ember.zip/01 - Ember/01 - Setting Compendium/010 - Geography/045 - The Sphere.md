# The Sphere

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Sphere is one of the largest and strangest cities upon the surface of Ember. It is a mysterious structure that defies all known magical or scientific understanding and may even be older than the cosmos of Ember itself.