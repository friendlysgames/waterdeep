# Star Academy

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Star Academy is a distant Great City far from the continent of Aterica that rests upon the very edge of the world. It is the home of the Rhivan people and the powerful Star Mages organization. The entire city is considered part of the academy in many ways, with scattered libraries, research centers, and magical experiments all interconnected into the everyday lives of its inhabitants. The towering Main Academy structure at the city center houses some of the most important, secretive, and dangerous knowledge in existence, and it is also where the Star Mages portal network resides.