# Kadísos

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The mistbound island of Kadisos is a mysterious, ancient island that lies between the Lowlands and the Arctus Plateau. It is a small tropical island, covered in jungle in the midst of tempestuous seas and surrounded by jagged rocks and reefs, with a hunger for the hulls of passing ships. It has little to offer the average soul, and little more to the brave and daring that seek to explore its heart.