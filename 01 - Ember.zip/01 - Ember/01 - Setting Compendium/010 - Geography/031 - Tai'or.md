# Tai'or

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Tai'or is known as the Far Southlands, a cold realm that few have ever visited.