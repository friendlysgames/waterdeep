# Jurin

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Jurin is an ancient and untamed continent as far away from Atercia as is possible on the surface world. Very little is known about its nature, except that many Thornlings tell a surprisingly consistent myth surrounding their origins and of a towering ancestry of peoples that hunt and kill Leviathans upon the distant continent.