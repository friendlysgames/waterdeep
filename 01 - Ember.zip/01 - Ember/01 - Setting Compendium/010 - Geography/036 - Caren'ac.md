# Caren'ac

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Caren’ac is a vast Great City of industry, military might, and technological innovation built around the edges of a long-dormant volcano. Its circular structures contain many concentric rings of aqueducts and bridges and countless waterfalls that spill over the edges and into a central deep lake, for this reason, the city is often called the Falling City. The origin of the initial structures and ruins discovered by humans thousands of years ago remains a mystery, but they are truly ancient and resistant to weathering and decay. It has comparatively recently become the capital of the Tayan Empire ever since the empire's foundation seventy-two years ago.