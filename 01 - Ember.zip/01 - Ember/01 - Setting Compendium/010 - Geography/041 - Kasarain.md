# Kasarain

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Deep within the lands of the Kessian Pyrelords lies the Great City of Kasarain, built around a titanic sinkhole that descends down into the Pathways of Ember.