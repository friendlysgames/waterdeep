# Mort'oliss

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Across the vast Reaver Ocean lies Mort'oliss, often called The Spiritlands; it is a continent realm presided over by the Elder God Sockets and where the Souls of Mortal peoples travel to when they die. The Spiritlands are not connected physically to any other continent, as they are separated by a barrier that supposedly prevents the living from crossing over, not to mention no one is particularly keen to visit the realm of the dead.