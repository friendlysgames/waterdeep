# Oakengarde

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Oakengarde is considered to be one of the most extreme, hostile, and dangerous places in the known world, with a terrifying ecosystem of deadly creatures and plants that prowl beneath the region’s colossal taigas and icy mountain slopes.