# Ruined Towir

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The ruins of the capital city of the Aedir inside the Broken Tower at the center of the Starshield. Since the Shattering, the massive structure of the Broken Tower and the city within has been a mostly empty shell of its former glory. While none of the previous inhabitants survived the massive apocalyptic destruction that spread across the continent, souls of the Aedir that died afterward have been drawn here in the thousands of years since.