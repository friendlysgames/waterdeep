# Ancalen

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

An ancient sun-bathed city perched upon the shores of the Aran Sub-Continent. With dense layers of older and older settlements, Ancalen is currently a Great City inhabited by the Railen people dominated by the Celestial-descended ancestry, the Altyra.