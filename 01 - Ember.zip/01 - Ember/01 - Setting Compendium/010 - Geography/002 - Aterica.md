# Aterica

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Aterica is the largest continent on the surface, often called the Shardstone Continent; it is both the largest and the most storied in its history and peoples. Home to no less than five subcontinents, one of which is the Aran Peninsula, which gave rise to the ancient Jarn, the precursor ancestry. Aterica also has a veritable wealth of Shard Gods that have found and communed with Heart Crystals, and there are so many separate cultures and realms that, currently, no less than six different entire pantheons exist at once.