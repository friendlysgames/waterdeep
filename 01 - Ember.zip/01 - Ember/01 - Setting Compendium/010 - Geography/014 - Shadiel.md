# Shadiel

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Shadiel sub-continent, home to the Star Academy of the Rhivan, is considered a part of Kessia in some circles, though it remains an extremely distant and far away realm.