# Sinkhole Depths

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Sinkhole Depths are an extremely deep section of the Pathways that drops down several miles into pitch-black darkness and an almost otherworldly environment. Layers of increasingly dangerous, dark, and bleak areas that become more and more challenging to survive. The full descent has never been accomplished and no one is entirely sure what lies at the very bottom of the depths, but the town of Arcturel and the people that make the strange town their home regularly descend into the upper areas to farm a material known as Inkaro Pearls.