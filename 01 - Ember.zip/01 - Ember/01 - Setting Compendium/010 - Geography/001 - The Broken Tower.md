# The Broken Tower

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The colossal Broken Tower is a gleaming reminder of the cataclysmic destruction of the Shattering. Massive chunks still orbit the apex of the tower, hinting at the extreme magical forces that remain active to this day. Visible from every corner of the surface, the ruined structure is so vast that it often dominates the horizon, casting deep shadows across the entire continent of the Starshield during dusk and dawn.