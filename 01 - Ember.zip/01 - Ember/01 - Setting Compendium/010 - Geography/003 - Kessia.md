# Kessia

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Kessia is the only continent deeply connected to Aterica, with burgeoning trade routes, diplomatic ties, and a history of shared struggles. Kessia was once said to be home to the largest Aedir colonies, but they were completely annihilated during the Shattering. Within the heart of the continent, the great Obsidian Desert formed and spread to cover the vast majority of its landmass.