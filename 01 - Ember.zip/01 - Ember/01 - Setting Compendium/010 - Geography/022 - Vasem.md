# Vasem

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Vasem is known as the Roaring Edge, where the waters of ember fall away into the Sea of Stars on the very eastern edge of the world.