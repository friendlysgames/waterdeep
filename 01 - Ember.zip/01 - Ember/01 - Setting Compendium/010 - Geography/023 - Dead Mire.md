# Dead Mire

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Dead Mire is a the small region of swamplands that lies to the south of the Arctus Plateau.