# Moiran Bonelands

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Moiran Bonelands are a region that was once home to temperate forests and a gentle climate of soft winds and light rains. Today, however, it is a place of death, fear, and terrible nightmares. The land itself is cursed and broken, where the light of Lantyr no longer penetrates an ever-present blanket of black clouds.