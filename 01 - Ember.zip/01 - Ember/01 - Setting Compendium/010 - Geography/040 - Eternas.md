# Eternas

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The city of death where the souls of all living beings are judged and given access to the Spiritlands. This is principally a city of spirits but there is a very small living population that directly serves the Elder God Sockets.