# Duskflare Jungles

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The murky jungles of the Lowlands are home to some of the most savage, and brutal monsters in the world, ancient crocodilian retpiles, ambushing Spiders and vicious predatory insects.