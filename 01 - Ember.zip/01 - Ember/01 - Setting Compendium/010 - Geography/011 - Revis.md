# Revis

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Revis is also known as the Reaver Ocean and is a vast stretch of deep water between Aterica and the Spiritlands. Crossing to the Spiritlands physically is almost impossible due to the massive waves, storms, and dangerous monsters lurking in the deep.