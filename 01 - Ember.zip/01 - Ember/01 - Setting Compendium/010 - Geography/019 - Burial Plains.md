# Burial Plains

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Dustlands and the Burial Plains lie to the south of the Arctus Plateau after the unhinged wizard Leatic attempted to commune with Akon and brings forth an infestation of machines.