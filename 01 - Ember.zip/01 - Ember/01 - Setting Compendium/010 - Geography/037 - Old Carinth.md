# Old Carinth

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Old Carinth is one of the oldest cities in the world, having been inhabited for nearly three thousand years. It was founded by some of the first migrating humans from the Aran Penisula as they moved north to explore the continent of Aterica. Today, it is ostensibly the most powerful of the Kelmezian city-states and a truly colossal edifice of architecture with thousands of residential, farming, and industrial layers of the city stacked on top of one another. It is an artificial mountain that is considered by many to be one of the most populated settlements on the surface of Ember, with millions calling the city home.