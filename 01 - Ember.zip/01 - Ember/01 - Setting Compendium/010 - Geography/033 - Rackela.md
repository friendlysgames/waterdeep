# Rackela

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Rackela is known as the Lands of the Lost, it is a broken continent that lies so far from the Aterica that few have even heard its name.