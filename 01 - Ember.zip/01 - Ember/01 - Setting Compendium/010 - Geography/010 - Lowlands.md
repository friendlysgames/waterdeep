# Lowlands

<section class="block wip"><h4>Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

The Lowlands are a small subcontinent of Aterica that lies to the south-east, separated by the thin Strait of Smoke that allows ships to pass from the west to the east. The Lowlands are a hot, humid, and dangerous land with thick jungles and deep, impassable swamps covering most of its landmass.