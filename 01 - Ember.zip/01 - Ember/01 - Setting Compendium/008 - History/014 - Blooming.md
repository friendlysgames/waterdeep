# Blooming

The Blooming is known as the Season of Optimism, or the Second Season of Spring, when the restlessness of the Seeding matures into a sense of boundless, abundant possibility. Under the full light of Primordis, mortals often find themselves swept up in a tide of ambition, making plans that sometimes ignore the harsh realities of logic. This is a season of boundless creativity, where builders may break ground on new projects, artists learn new techniques, and musicians learn new songs.

The World of Ember mirrors this surge with a frantic, often explosive vitality that can be nearly overwhelming to the senses. Plants not only grow but often erupt in a frenzied burst of untamed growth. Wilderness paths through forests and grasslands become clogged or swallowed by thickets or rapid-growing vines, making navigation a constant struggle. The air itself seems to hum with more motes, making magic feel effortless yet dangerously volatile.

## Overview

The Blooming is often called the Season of Optimism, when primroses are at their height in the sky and are associated with a period when people feel abundant possibilities, often concocting grandiose or impractical plans.