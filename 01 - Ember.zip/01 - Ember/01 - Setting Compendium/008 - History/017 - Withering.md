# Withering

The Withering is known as the Season of Understanding, or the First Season of Winter, during which people experience surges of regret, wistfulness, and nostalgia. As the golden light of Luxarum fades, the passions of the Gleaning are replaced by a somber, reflective mood. Mortals find themselves looking backward, mourning lost opportunities, or dwelling on the past. Despite this heavy sense of longing, the season brings a strange, restorative peace to the mind; people tend to sleep more soundly than at any other time of year, and they are visited by dreams that are exceptionally clear and often seen as prophetic.

Across the World of Ember, the vibrant colors of the earlier year begin to fade; leaves turn orange, brown, and red, eventually falling in piles. Persistent mists often cling to the hills or rise from shorelines, making the world feel more oppressive. In many cultures, the Withering is also the season of the harvest, where people gather what remains in farms and gardens and preserve it for the coming winter season. Settlements become quiet, and the air is filled with the scent of woodsmoke as the temperatures fall.

## Overview

The Withering is the period of the year when mortals feel regret, wistfulness, or nostalgia more keenly, as the additional light from Luxaurum fades and the darkness of Signara replaces it in the sky. During this season, folk tend to sleep soundly with clear, vivid dreams.