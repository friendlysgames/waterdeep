# Timekeeping

<section class="content"><p>Time in Ember is divided into the seasons of the year, and further subdivided into days, hours, minutes, and seconds. The seasons are dictated by the dominance of one or two of the Inner Realms in the sky and their movement around the Weave in a predictable pattern. Days are calculated by how long it takes Lantyr to make a single rotation around the World of Ember.</p><h2 class="divider">Years</h2><p>Each year in Ember has 360 days, which are divided into six seasons. The turn of each year occurs between the end of Stilling and the beginning of Seeding.</p><p>Years are numbered according to the historical age that particular year is a part of, and there have been several ages throughout the course of Ember's history — defined by the precise year they began. Ages of Ember's history are annotated as:</p><ul><li><p><strong>AC</strong> = After Creation</p></li><li><p><strong>AB</strong> = Age of Beasts</p></li><li><p><strong>AT</strong> = Age of the Tower</p></li><li><p><strong>AS</strong> = After Shattering (also known as the Age of Rediscovery)</p></li></ul><div><section class="block hazard"><h4>After Shattering (AS)</h4><p>Historical ages of Ember can actually be categorized differently based on the specific culture that is referencing a certain event. Generally speaking, though, most people of Ember use the AS calendar — which is used to label the years that have taken place after the cataclysmic event of the Shattering two-and-a-half-thousand years ago. AS is used with regularity throughout the continents of Aterica, Kessia, and Rhivan, though some distant cultures have a different time scale (such as the Oaken, who currently track time approximately and are in their 27th Era).</p></section>

Example Dates

- 
 = 200,451 years after the beginning of the Age of Beasts

- 
 = The start of the Age of the Tower

- 
 = 11,021 years after the beginning of the Age of the Tower

- 
 = The year of the Shattering

- 
 = 200 years before the Shattering

- 
 = Present day

## Seasons

As the Inner Realms of Luxarum, Primordis, and Signara drift across the sky, their influence can be felt upon the World of Ember in the form of seasons. These seasons affect more than just the weather, temperature, and plant life on Ember's surface. As the balance between the Inner Realms shifts and changes, so do the moods of Ember's people — anxious and fitful during Seeding, rational and thoughtful during Stilling, and everything in between.

You can read more about each season in the Setting Compendium:

- 

- 

- 

- 

- 

- 

## Days & Weeks

A day in Ember consists of 24 hours. Each hour consists of 60 minutes, and each minute is a standard 60 seconds in length. Every day belongs to a season (as covered above), and the concept of a week doesn't necessarily extend beyond the standard convention of ten days. For example, someone might say the "Harvest is during the first two weeks of the Gleaning," referring to a period of 20 days, or "I will see you in a week" as a shorthand for ten days.

There are no named days of the week in Ember, and instead, people keep track of which day it is by number within the season. For example, someone might say "I'll meet you on the 5th day of Blooming" or "I have every 5th day of the Blooming to relax" etc.

## Lunar Cycles

The cycles of Ember's Elemental Moons also play an important role for timekeeping. The orbital durations of these lunar bodies are well-known by nearly everyone on the planet, so most Cultures in Ember can understand and anticipate when forthcoming zeniths or conjunctions will occur. Ember's lunar cycles are as following:

- 
Aura: 28 days

- 
Akon: 33 days

- 
Cora: 32 days

- 
Mayis: 32 days

- 
Orbis: 29 days

- 
Ragen: 29 days

## Overview

The study of time is the domain of the wise. Keeping time and tracking it accurately is for the mad and the foolish. If anyone sits in towers with brass gears and ticking pendulums, trying to measure the world down to the nearest second, they might as well be measuring a waterfall with a thimble. By the time they’ve calibrated their machines to the pulse of Primordis, Signara, Luxarum, and, most importantly, Lantyr, the world has already shifted under their feet.