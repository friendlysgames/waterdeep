# Stilling

The Stilling is revered as the Season of the Quiet, or the Second Season of Winter, a period of profound calm and stillness where the heat and passions of the earlier year are extinguished. Shrouded in the darkness of Signara, mortals find themselves at their most rational and contemplative. Traditionally, this is the most productive period for academic research, complex innovation, and the birth of new ideas. Scholars, engineers, and philosophers retreat to their libraries and workshops, and common people like farmers and traders retreat indoors to find solace with their families and communities.

Across Ember, the Stilling is a time of calm, as the world falls into a heavy silence, and most of the landscape is locked beneath layers of frost and snow. Travel becomes almost impossible in many places; harsh cold and deep snow make travel treacherous, and the "Stilling Hush" makes even the sound of a footfall carry for miles in the frozen air. Communities bond over stories and rigorous debates, using the long, dark nights to recuperate and rest before the start of the next year.

## Overview

The Stilling is the season when mortals are said to be most rational and thoughtful, and when the darkness of Signara dominates the sky. Traditionally, Stilling is a productive period for academic work, research, innovation, and new ideas.