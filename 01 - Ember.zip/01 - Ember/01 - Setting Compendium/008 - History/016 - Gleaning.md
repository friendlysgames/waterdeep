# Gleaning

The Gleaning is known as the Season of Passion, or the Second Season of Summer, when the steady productivity of the previous months gives way to emotional fervor. As Luxarum dominates the sky, the Steading's grounded nature evaporates, replaced by flights of fancy and spontaneous, often rash decisions. It is a time of sudden romances, fiery political movements, and spiritual awakenings that flare up with little warning. Common wisdom holds that any contract signed or vow spoken during the Gleaning should be viewed with skepticism, and some cultures even disallow pacts or contracts altogether during this time.

The World of Ember is bathed in what seems to be extra light, and the season projects golden, shimmering luminance during the day and soft golden light at night. The air often feels electrically charged, and the sunsets stretch into long tapestries of crimson and gold. Farmers and laborers work with additional speed, not out of the quiet duty found in the Steading, but out of a sudden, zealous drive to secure the year’s bounty before the light fades. This creates an atmosphere of high-stakes energy in every settlement, where the pressure to succeed and the desire to indulge in life’s pleasures collide, leading to grand festivals and fabulous summer parties.

## Overview

The Gleaning is the period of the year when mortals are swept away in feelings of passion, zeal, or rashness when Luxarum is at its height in the sky. During Gleaning, folk may be prone to flights of fancy or spontaneous decisions that they might think twice about during other seasons.