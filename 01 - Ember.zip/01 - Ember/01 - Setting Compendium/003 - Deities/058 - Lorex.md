# Lorex

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Lorex** is a Shard God that has been active on the world stage for only a few hundred years. His godhood was at first disputed by many, but as his legend grew and he began responding to those worshipping him, it became irrefutable. Lorex is considered the greatest fighter in the world, nothing and no one can resists his thunderous fists and he spends most of his time making sure people know it. He is a laughing, singing, and exuberant** **deity that has just as much fun, drinking and singing as he does and fighting.