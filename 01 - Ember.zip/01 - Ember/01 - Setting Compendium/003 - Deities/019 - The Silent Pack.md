# The Silent Pack

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Deep within the heart of the Inner Realm of Primordis lies the Shadow Thicket. The primordial location from where the Casia first emerged during creation. It is one of the most dangerous places in the cosmos as not only is it a place of raw, untamed magical energy, but it is also home to a malicious group of Casia called the Silent Pack. Whether the pack is one entity with many different physical bodies is unknown. They appear in the minds of their followers as a collection of red burning eyes glimmering in the shadows, and if you see these eyes in the waking world, there is little point in running as you are likely already dead.