# Janar

*The Hunter*

**Areas of Concern: **Protection, Hunting

<section class="content"><p><strong>Typical Followers: </strong>Hunters</p><p><strong>Domains: </strong>War, Other</p><p><strong>Pantheons:</strong>  The Nineteen, The Tanir</p><p><strong>Symbol: </strong>A spear piercing a fanged mouth</p></section>

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Janar</span></strong></span></p><blockquote><p>Slay those who would harm your kin.</p></blockquote></section>

Janar is dead, or so it seems to almost everyone on Ember's surface. As an ancient Shard God from the early Jarn days, he was one of their principal deities and protectors. He hunted Leviathans and safeguarded many Jarn villagers and tribes from their fury. Despite Leviathans causing widespread damage to the Jarn, Janar reportedly did not harbor hatred towards them or other beasts, but he did hunt them relentlessly, believing a hunter's role is to provide for and defend his family. As an ascended Jarn himself, he saw it as his duty to protect the entire Jarn population. Battles were intense, often lasting hours or days, but Janar typically succeeded in either slaying these colossal creatures or driving them off. Such victories often meant abundant meat or materials for nearby tribes, and Janar became especially revered.

In one of the most legendary tales since the Shattering and his final hunt, Janar faced the intelligent Leviathan Orinoth. After an epic battle across the shorelines and open ocean, Janar ultimately met his end. The story is often told as a great epic, but the exact circumstances of Janar's death remain mysterious and largely unknown.

In the present, Janar is still greatly revered, and despite his followers knowing he died, his worship has not faded like that of other gods. In fact, his followers still draw divine power from somewhere, and it is a matter of great debate among scholars, Janar's followers, and mortals across the surface on how this is even possible. It is said that Malae somehow recovered his body, which, in itself, is unheard of for a dead Shard God (typically they explode or dissipate into energy on death), and she enshrined it in a hidden temple on the Aran Subcontinent.

## Appearance

According to legends and stories, Janar never changed his form from when he was a Jarn, except to grow larger when necessary to combat Leviathans. He appeared as a middle-aged Jarn male, with a body largely covered in hair and a short-trimmed beard. His leathery, weathered skin was covered in many horrific scars, which he wore proudly as signs of his successful hunts. He wore simple, practical hunting leathers and wielded a long spear tipped with a long shard of black obsidian. When depicted in imagery or statues among humans today, his ancestry is typically updated to show a Human, but all other aspects remain the same.

## Influence and Followers

Janar has a large number of active followers and priesthoods throughout the world of Ember, though they often call themselves Hunters rather than priests and follow Janar's teachings to confront beasts and monsters and protect their loved ones from threats. This became much more pressing after the events of the Abyssal Shear, when monstrosities, dragons, and many other horrors entered the Cosmos for the first time. In some cases, his followers band together to form organizations designed to confront specific threats, such as the Serpent Hunters in the northeast of the Arctus Plateau, who hunt Sea Serpents of the

<section class="block gamemaster"><h4>Using Janar as a Diety</h4><section class="content"><p>Using Janar as a deity for a Cleric, Paladin, or Warlock Patron is for those with a strong sense of duty and responsibility. Although Janar has been long dead, his followers uphold his legacy and philosophy, which include core tenets like strength, duty to family, and respect for the natural world despite its harsh and unrelenting aspects. Followers of Janar are often hunters of beasts and animals, as well as those dedicated to eliminating monsters to preserve the natural environment. Janar does not communicate directly with his followers; rather, his power manifests from an unknown source.</p></section>

<section class="block social"><h4>Relationships</h4><p>Janar had a long and storied relationship with the Shard Goddess Malae. After his death, she supposedly recovered his body and concealed it within a temple on the Aran Subcontinent. Malae still mourns Janar, and many of his followers believe they were lovers at one point.</p><p>Janar was also the teacher for the Shard Goddess Lanespear, although she doesnt speak much, her now dead mentor and the two were close friends and allies.</p><p>Although it's not exactly what the relationship was at the time, Janar was said to intensely dislike Ku'arta, and some believe Jnar even tried to kill Ku'arta at one point. To this day, Jnar's followers hunt down Ku'arta's followers with equal hatred and passion, believing that Ku'arta is a detestable being that twists the natural world.</p></section>

## Overview

**Janar** is a very old, human-centric Shard God, though his time came and went well before Humans even arose: his legacy and story is an ancestral thread from when Humans were Jarn. As a primal god of Hunting and nature, many still worship him today and strangely he has a surprising amount of active priests and followers, despite dying at the claws of a Leviathan during the Age of Beasts many thousands of years ago.