# Scoris

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Scoris** is a Shard God associated with knowledge, magic, and creation. She created the Ashka people and styled them in her image, helping them create a society on Kadisos. Tragically, an ill-informed feud with the force of entropy known as Bale led to her demise.