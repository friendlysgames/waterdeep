# Slinerak

<section class="content"><p><strong>Areas of Concern: </strong>Oppression, Ooozes</p><p><strong>Typical Followers: </strong>Cultists</p><p><strong>Domains: </strong>Earth</p><p><strong>Pantheons:</strong> None</p><p><strong>Symbol: </strong>An oozing mass of multicoloured slime with a large rusted spike thrust through it.</p></section>

Slinerak is both a tragic and terrifying figure among the Elemental Sovereigns, a primordial being whose descent into tyranny serves as a cautionary tale. Originally, he was a Lord of Earth, characterized by pragmatism and fairness, who ruled over the moon of Cora and its denizens with steadfast reliability. However, something twisted his mind beyond recognition, and his personality shifted into an obsessive need to control every aspect of his life. He began to overlook the individual lives of the beings beneath him and forced his need for control onto his followers, eventually transforming into an oppressive, insane overlord who seeks to subjugate everything within his reach.

Though his status as an Elemental Sovereign has never diminished, Slinerak has completely hidden himself away from the Cosmos since his fall. He resides deep within the Palace of Rust, a monumental fortress of rusting metals and corrupting liquids. While he remains the Sovereign of Earth, his corruption eventually gave rise to the creatures known as Oozes, which he is said to control utterly. Some Scholars suggest that Oozes represent earth that has lost its structure, a stagnant sludge that mirrors the Slinerak's own moral decay. Thankfully, the vast majority of elemental beings upon Cora resist the corruption of their once Lord, seemingly working to contain him within the Palace of Rust. They are somewhat successful but at great cost, and the effort has made Cora extremely unstable and chaotic.

<section class="block readaloud"><blockquote><div><p>Some people find Oozes to be friendly, cute little critters, but I find them revolting. Not only are they unnatural perversions of the earth, but knowing that Slinerak could be watching from behind their eyes is uniquely horrifying.</p></div></blockquote><p>~Laeora</p></section>

## Appearance

Although he likely had another form in ages past, Slinerak now appears as an enormous slime creature with a barely visible core of earth and rusted metal. His size and girth are legendary, and while his form has no eyes, he often extends a colossal jaw-like structure that swallows anyone who displeases him.

## Influence and Followers

Slinerak himself is a depraved individual; his only interest is spreading his form across the Cosmos and dissolving it in the process to make it his own. He is, however, aware that many other powerful entities in the Cosmos resist him and could even challenge his power, so he is content for the time being to play the long game. His influence and schemes ooze across the surface world, and he is a fundamentally malicious force that ultimately desires dominion and control over all things.

<section class="block gamemaster"><h4>Using Slinerak as a Diety.</h4><p>Using Slinerak as a deity for a Cleric, Paladin, or Warlock Patron is to bind oneself to a force of unyielding stagnation and control. Slinerak is a Wild God of immense age who cannot hear prayers or traditional worship offered by mortals upon the surface of Ember. Therefore, to forge a connection with the Lord of Slime, a mortal must travel to the moon of Cora and reach the Palace of Rust. There, they must endure the Sovereign's oppressive presence and forge a suffocating contract of total submission. Strangely, all Oozes in existence seem to share an innate connection with Slinerk, and although he doesnt control every Ooze, a mortal could make a connection with Slinerk through them instead.</p></section>

## Overview

Slinerak is an Elemental Sovereign and one of the most powerful Wild Gods in existence, having existed since Creation. He is also known as the Slime Lord and is considered the corrupted Elemental Lord of Earth. He is said to reside within the Palace of Rust upon the moon of Cora. Slinerak became a disgusting, shameful being long ago during the Age of Beasts and has been a malicious and rotten influence on the Cosmos ever since.