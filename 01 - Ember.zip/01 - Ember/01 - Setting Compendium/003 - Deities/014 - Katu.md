# Katu

*Heart of the Storm*

<section class="content"><p><strong>Areas of Concern: </strong>Storms, Wrath</p><section class="content"><p><strong>Typical Followers: </strong>Sailors, Fishers, Fighters</p><p><strong>Domains: </strong>War, Other</p></section>

**Pantheons: **The Nineteen

**Symbol: **A roiling cloud cut through by lightning

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Katu</span></strong></span></p><blockquote><p>Respect the fury of the storm.</p></blockquote></section>

Though the storms Katu is known for are impressive and often destructive, they (like his moods) often pass quickly. He has threatened, more than once, to destroy Ember and all who live upon it. However, he has neither the patience (nor truthfully, the power) to act on these threats. The temperamental god must instead satisfy himself with haphazard calamity — such as the wrecking of a boat, the flooding of a city, or the creation of an errant storm.

Oddly, Katu has respect for those who survive his onslaughts, and will often act protectively towards those who manage to pilot a ship through one of his storms or withstand the wind that lashes their city. This wind is often made more potent by Katu's wife Vekalla, the Whispering Wind, who enjoys taking the opportunity to show her power if she believes that Katu's anger is justified.

Though Katu can at times be ruled by his anger, he has taken steps over the years to blunt its effect on the world around him. Every few years he selects one mortal, called the Stormheart, to imbue with part of his anger and wrath as a way of helping to calm his temper - passing the title on to someone else when that person grows too weary or angry to continue in the role. While this arrangement can weigh heavily on the mortal who takes it, it is also considered a great honor, and whoever takes it on can generally count on fairer skies and gentler winds after stepping down from the position.

## Appearance

Katu appears as a statuesque and chiseled man whose blue body calls to mind the color of a darkening sky. Blue lightning bolts extend from his body, crackling unpredictably, and he often appears to be in the center of a windstorm, with clouds circling around him and his hair, beard, and clothes in motion. Though it is said that there are times that the winds and clouds and lightning that he is known for dissipate around him, replaced by a gentle breeze, his storms are intensified by his anger, and most mortals only encounter him when he is already enraged.

Katu's clothing is often simple, but framed with precious metals that bring to mind the flash of lightning in the sky. He changes these ornamental trappings frequently — switching out bracers, belts, and the like as suits his mood — and some believe that the nature of the storms he generates can somehow be predicted by the size and shine of the accessories he wears (although this knowledge likely comes far too late for whomever he uses them against).

## Influence and Followers

Sailors and fishers can be found loudly singing and toasting to Katu's health and mercy, or visiting shrines to make offerings when preparing for voyages in the hope that he will view them positively if he passes by. As a result, every port city has at least a small shrine to Katu attended by an Acolyte of Storms, with larger temples appearing in bigger cities.

The Acolytes of Storms are Katu's most devoted followers, and are known for creating the Litany of Storms, a series of books that hold a detailed list of Katu’s moods, storms, and grievances and are believed to help predict storms. Each Litany is closely guarded and shielded from the weather by physical and magical protections, and is guarded by the Stormblades, a group devoted to the physical protection of Katu's shrines and acolytes. They are also dedicated to keeping the Litanies from Katu, out of the fear that if he ever reads one, he will recall all of his old grudges and attempt to drown the world in his anger.

In recent years, the Acolytes have begun expanding their definition of storms, including geopolitical and personal conflicts into their records. A group of Acolytes that call themselves the Stormbreakers use this information to help mediate conflicts and broker peace agreements, asking only that those they help set up a large shrine to Katu once the conflict has been smoothed over.

<section class="content"><div><section class="block gamemaster"><h4>Using Katu as a Deity</h4><p>Using Katu as a deity for a Cleric, Paladin, or general devotion is common, especially for those who travel by sea. With altars to Katu at most ports, keeping up with devotion to the mercurial god is generally easily done — and considered to be a wise idea lest a follower get on the god's bad side and bring a storm down upon them. For those who wish a more formal devotion to Katu, becoming an Acolyte of the Storm, Stormblade, or Stormbreaker are all worthy options, though Katu tends not to interact with followers other than his chosen Stormheart unless they have angered him — his silence is often considered his deepest blessing.</p></section>

Katu is deeply close to his family, who are all shard gods in their own right — his wife Vekalla is associated with the wind, while daughters Raineka and Sokali favor rain and snow respectively. Outside of this tight family circle, Katu is passingly friendly with Nite, though he sometimes finds her desire to stop him from raging against a place that he believes deserves his fury trying.

## Overview

Proud, unpredictable, and unbelievably petty, the Shard God **Katu** has a deep connection to the storms and blizzards of Ember, bringing their chaos to the land whenever he is enraged. Unfortunately for those around him, Katu is easily driven to anger by the acts of mortals, taking offense at the smallest of slights and starting disputes over issues that another god would barely notice, much less rage against.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Katu was short-tempered even as a young man, but he was also the best sailor that anyone in his village had ever seen, with an uncanny intuition about the skies and the changing of the weather that earned him the nickname Stormheart. But despite his prowess at sailing, Katu had no particular interest in trade, exploration, and discovery. What he loved was movement, being driven across the seas by the wind while using his skills and mastery of sailing to stay afloat.</p><p>For years, Katu traveled the seas with little care for his destination, avoiding time on shore when possible, as his short temper still led to fights with many around him. This changed when he met Vekalla, a woman with a desire to wander and explore who was as fiery at heart as Katu. Together, they sailed Ember as friends, and later lovers, with Katu driving his ship in whichever direction Vekalla was interested in going, finding the spirit of adventure in seeing the world alongside her and debating with her endlessly about the nature of the world and those they met during their explorations.</p><p class="MsoNormal">Eventually, the pair stumbled upon Heart Crystals in a cave on a far-flung island, and through them ascended into gods — while Vekalla tied herself to the wind, Katu hearkened back to his nickname and sought the challenge of a storm.</p>
</section>