# Nethehepticas

<section class="content"><div><div><p></p><section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Nethehepticas</span></strong></span></p><blockquote><p>Deliverance through agony.</p></blockquote></section>

<section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

To those caught in the thrall of a nightmare, the name **Nethehepticas** may manifest like a subconscious whisper. The name fades with the nightmare upon waking, which is for the best as to recall it in the waking world would bring nothing but misfortune.