# Verador

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Verador is an ancient Shard God of chaotic charm and is well known for being unpredictable and spontaneous.

<section class="block gamemaster">
<h4>GM Notes</h4>
<ul><li><p>Verador, The Laughing Sky, is the Shard God of chaos, cunning, and freedom.</p></li></ul>
</section>