# Fenra Irdragon

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Fenra Irdragon is known as the One Heroic Spirit, they were once the High King of the proto Kelmezian culture and died thousands of years ago. However legends and stories are told of them appearing in times of need to defend mortal ancestries against the darkness.