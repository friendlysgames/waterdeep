# Nalgomith

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Nalgomith** is one of the Sixteen Daemos, the powerful beings that rule Signara, known for creating the fiends that would later become the Wirrun. He is a deeply curious and knowledgeable entity who has researched a vast amount of esoteric lore and arcane phenomena over his unimaginably long life, making his mannerisms seem alien and otherworldly. He is lost in schemes, machinations, and plans that are so mysterious, layered, and complex that he appears almost random in his actions.