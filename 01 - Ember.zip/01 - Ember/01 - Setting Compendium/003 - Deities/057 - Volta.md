# Volta

*Lightfeet*

<section class="content"><div><p><strong>Areas of Concern: </strong>Change, the Dawn, Secrets</p><section class="content"><p><strong>Typical Followers: </strong>Travelers, Anyone going through a change</p><p><strong>Domains: </strong>Twilight, Light</p><p><strong>Pantheons:</strong>  The Nineteen</p><p><strong>Symbol: </strong>The horizon line with the rays of dawn above and the dusk colors below.</p></section>

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Volta</span></strong></span></p><blockquote><p>Moving at the speed of change.</p></blockquote></section>

## Overview

**Volta** is an unpredictable Shard God that enjoys traveling the skies of Ember and viewing the mortal world from above. They are one of the fastest beings in existence, known to run through the air at lightning speeds. Volta is worshipped as the bringer of the dawn and dusk, and while they rarely spend time on the surface of Ember, they are a very well-known deity due to being frequently seen racing across the sky, particularly at dawn.