# Nimaelle

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Nimaelle is a well-meaning and passionate Casia from the Inner Realm of Primordis. They are typically found on the surface, helping mortals.