# Orvaath

*The Life Tyrant*

<section class="content"><div><section class="content"><div><section class="content"><div><p><strong>Areas of Concern: </strong>The Soul, Death, Deception</p><section class="content"><p><strong>Typical Followers: </strong>Alchemists, Scholars, Outcasts</p><p><strong>Domains: </strong>Twilight, Other</p><p><strong>Pantheons:</strong> Sunalins</p><p><strong>Symbol: </strong>A strange ancient machine or contraption, wreathed in fire.</p></section>

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Orvaath</span></strong></span></p><blockquote><section class="content"><div><section class="content"><div><p>Fear death not for yourself, but for the promises left undone.</p></div></section>

## Overview

Orvaath is a god born of grief and defiance, a being who could not accept the quiet ending of life. Once mortal, they are said to have reached beyond what any soul should touch, seeking to preserve life forever and end the tyranny of death. Now Orvaath is said to brood in a distant cavern somewhere on the continent of Kessia, plotting to resurrect old heroes and the long dead. To the Nalvani, he is both redeemer and curse, the Life Tyrant whose mercy consumes. Worship of him persists in secret, carried by those who reject the Soul Cycle and yearn for permanence in flesh. Elsewhere, his name is spoken only in fear.