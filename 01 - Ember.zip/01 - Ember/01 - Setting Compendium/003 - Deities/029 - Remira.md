# Remira

*Heart of the Heart*

<section class="content"><div><p><strong>Areas of Concern: </strong>Consent, Autonomy, Passion</p><section class="content"><p><strong>Typical Followers: </strong>Artists and Writers, Prisoners, Pleasure Workers</p><p><strong>Domains: </strong>Life, Other</p><p><strong>Pantheons:</strong>  The Nineteen</p><p><strong>Symbol: </strong>Two fingers hooked together.</p></section>

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Remira</span></strong></span></p><blockquote><p>Choose your pleasure.</p></blockquote></section>

## Overview

Appearing to her followers as an alluring Kiska with pink and white fur, Remira is a shard god whose spheres of influence revolve around the romantic world. Consent, autonomy, and passion are the concepts she is most concerned with, and she is Ember's most important advocate for the pursuit of ethical pleasure.