# Shattered One

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A mysterious entity with immense power that very few in the world even know exists. Very little is known about their intentions, personality or goals, and the only beings that seem to worship them are the fanatical Malicae.