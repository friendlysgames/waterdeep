# Adair

*The Two Faced Counselor*

<section class="content"><p><strong>Areas of Concern: </strong>Change &amp; Chaos; Logic &amp; Law</p><section class="content"><p><strong>Typical Followers: </strong>Bureaucrats, Lawyers, Councilors</p><p><strong>Domains: </strong>Twilight, Other</p><p><strong>Pantheons:</strong> None</p><p><strong>Symbol: </strong>A two-faced mask</p></section>

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Adair</span></strong></span></p><blockquote><p>Hold two truths close and let neither win.</p></blockquote></section>

## Overview

Known among mortals as a capricious and two-faced Shard God, who very recently seemed to ascend, Adair embodies the duality of thought and emotion, reason and logic in conflict with chaos, change, and the disruption of order itself. Many come to them seeking counsel, hoping to find clarity, yet few leave without confronting their own contradictions. Adair has few places of worship, but those that do follow them often gather around fires or quiet rooms, endlessly discussing the merits of one topic only to turn around and argue the opposite in later meetings.