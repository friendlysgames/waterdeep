# Areyter

**Areas of Concern: **Water, Patience

<section class="content"><p><strong>Typical Followers: </strong>Typhic, Water Elementals</p><p><strong>Domains: </strong>Water</p><p><strong>Pantheons:</strong> None</p><p><strong>Symbol: </strong>A see-through water droplet, with a blue core, and city built above</p></section>

Upon Lady Areyter's back lies the massive underwater city of Tohr, one of the oldest settlements in existence. Tohr is a masterwork of ancient architecture, characterized by hidden, winding paths, lush buildings of living coral, and the soft, haunting glow of bioluminescent lights. The original builders of the city, the Typhic, still walk its glowing streets, alongside water elementals and other watery denizens.

<section class="block readaloud"><blockquote><div><p>Tohr is the only city in the cosmos where the ground has a pulse. I spent a week in the Coral District, and I couldn't sleep. The vibration of her heartbeat through the stones feels like the drums of the raging tempest on the surface of the moon. It’s a stunningly beautiful city, though, and I found the entire experience both surreal and calming.</p></div></blockquote><p>~Laeora</p></section>

Despite her immense power, she is famously known for her laid-back, relaxed personality. She is a being of quiet contemplation, largely unconcerned with the finer details that rise and fall within her waters. Her presence has been felt at every major turning point in the history of Mayis, though she rarely takes an active role in the outcome. She presided over the creation and eventual dissolution of the first Court of Typhos, as well as the emergence of its second iteration. Yet, she always remained a silent witness to the political strife. The last time her voice was recorded was to bless the ancient union of Adrefton and Bathyios.

## Appearance

Lady Areyter is a being of staggering size, a gargantuan entity measuring roughly six miles from her blunted snout to her massive tail. In silhouette, she bears a striking resemblance to the colossal whales found in the oceans of Ember. However, up close, her anatomy reveals a much more ancient, fish-like physiology that predates modern aquatic life. Her vast back is covered in a mottled, rugged armor. This hard skin is both tough hide and part vitrified stone. In stark contrast to her armored back, Areyter’s underside is composed of a semi-transparent elemental membrane. Through this glass-skin, observers can see the rhythmic pulse of her internal Lifeforce, which glows with a soft, bioluminescent blue light. Her twelve eyes are vast, swirling orbs that mirror the storms of Mayis.

## Influence and Followers

Areyter is the absolute ruler of the moon of Mayis and, by extension, water elementals of all kinds. She is not particularly interested in getting involved with everyday concerns and is happy to lazily drift through the moon's vast ocean. However, the Typhic and water elementals generally adore her and treat her with the utmost respect. Her philosophy of laid-back acceptance and taking everything in before acting has a profound effect on her followers.

Very few mortals in the world of Ember are aware of the Elemental Sovereigns generally, and thus Areyter is not a commonly worshipped being. However, there are some exceptions. Notably, the mysterious Carrow dwelling deep within the oceans of Ember.

<section class="block gamemaster"><h4>Using Areyter as a Deity</h4><p>Using Areyter as a deity for a Cleric or Paladin, or as a Warlock Patron, is extremely difficult for mortals in the world of Ember. Areyter is technically a Wild God of immense age, and therefore, she cannot hear prayers or the pleas from her followers remotely. To harness her power, a mortal must forgo the safety of the temple and seek her out personally, crossing the vacuum of the Sea of Stars and stand before her. Once a bond is forged, the follower will find that Areyter is a deeply patient and undemanding patron. She does not command, but instead encourages "going with the flow" to wash over them and to wait with the stillness of the deep sea.</p></section>

## Overview

Lady Areyter is a primordial force of the Ember Cosmos, an Elemental Sovereign who arose during the mythical days of Creation. She is the undisputed mistress of Mayis, the Tempest Moon. Areyter is not merely a ruler of the elemental moon; she seems to be the physical embodiment of the Force of Water itself, a massive, behemoth-like creature that swims through the moon's cold waters on a never-ending journey.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Areyter has existed ever since the moon of Mayis formed during Creation. She has a deep, thoughtful memory of all that has happened on the moon, but less so of the cosmos as a whole. She played very little part in some of the significant events of history, but she was roused to anger during the Abyssal Shear. It's not known what exactly transpired on Mayis during those tumultuous days, but Mayis remains somewhat corrupted by Abyssal energies to this day. It's rumored that Areyter herself annihilated numerous Abyssal monsters that attempted to ravage the moon, and the city of Tohr became a glittering fortress of wrath for a short time.</p>
</section>