# Menis Valegar

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Menis Valegar**, also known as the Lord of Torment, is one of the powerful Blood Barons, a group of undead beings that are on par with Shard Gods.