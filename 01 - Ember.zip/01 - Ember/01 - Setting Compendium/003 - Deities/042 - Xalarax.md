# Xalarax

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Xalarax** is a name few know and that instills horror and dread in those that hear it. Those unfortunate enough to bear that burden associate it with the Evernight which saw the city of Moira destroyed, the Fractured Lands that were created in its wake, and the Blood Barons who rule there now.