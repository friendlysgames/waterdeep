# Sigil

*The Elder Scholar*

**Areas of Concern: **Research, Knowledge Preservation

**Typical Followers:** Librarians, Researchers

**Domains: **Knowledge, Peace

**Pantheons: **The Nineteen

**Symbol: **A quill tip in a circle of ink

<section class="block readaloud"><h4>Edict of Sigil</h4><blockquote><p>Preserve knowledge for future generations.</p></blockquote></section>

Sigil prizes knowledge and information above all other things, and has dedicated his life and his divinity to collecting and parsing the world's knowledge. Born during an era of great violence, he believes that knowledge, if well-maintained and protected, can create legacies of understanding and information that outlive and honor those who created them.

Even for a shard god, trying to capture the knowledge of the world is a monumental task, and Sigil has used much of the magic he gained during his ascension to help him find, absorb, and catalogue as much information as possible. His set of magical tools and helpers include his living beard, which helps to catalogue books and scrolls; his home of Oldcraft Lodge, which hides an ever-expanding library within its simple riverbank frame; and the ink he uses, which translates his passing thoughts and research ideas into notes that he always vows to go through later and never seems to get around to.

Though Sigil can at times appear small and frail, and has less pure power than many of the other shard gods, his shrewd understanding of the strengths and weaknesses of the people, items, and places around him is not to be underestimated. Sigil became a shard god in part because of his willingness to combine pure research with adventure, and while he is now more focused on collecting knowledge from books and scholars than unearthing it in distant lands, he retains a keen insight into others. He often uses this to find and mentor those rare mortals who he believes are true seekers and protectors of knowledge, encouraging them to continue to pursue their love of knowledge and share all that they find with him in deep and often meandering conversations about the nature of the world and life itself.

## Appearance

Sigil takes the guise of an elderly human man whose small body is nearly dwarfed by the enormous white beard that wraps around him, glowing from within as if it has a life of its own. Sigil often uses his beard as a second pair of hands, storing scrolls within it and using it to grab books from the shelf. This, along with the magical ink that often spills from his work, flying into the air to arrange itself into letters on one of his parchments, gives him the appearance of someone who is very still while the world is in motion around them. Some speculate that Sigil's choice of an elderly human speaks to the wisdom and knowledge that those who are advanced in age are assumed to have, but he has never confirmed or denied his reasons.

## Influence & Followers

Thanks in part to the reputation of the Oldcraft Lodge as a place for knowledge and study, Sigil is well known and well regarded across the Arctus Plateau. His Lodge is notable for being larger on the inside than it is on the outside, and holds a number of carefully catalogued books, tomes, scrolls, and treatises on any manner of subjects. Though Sigil is fond of the written word, he also captures stories, using magic to transcribe a tale as it was told and store it among his other files.

Despite his popularity on the Arctus Plateau, Sigil has relatively few direct followers. Even those he mentors or who spend time in Oldcraft Lodge learning from his library often do not count themselves as his followers, seeing him as more of a peer than a deity. This suits Sigil well, as he has no desire to give of his divine power to others, preferring to keep his relationships with mortals to a meeting of the minds than an imparting of divinity.

#### 

<section class="block gamemaster"><h4>Using Sigil as a Deity</h4><p>Using Sigil as a deity for a Cleric, Paladin, or general devotion is more common in the Arctus Plateau than elsewhere, but is still relatively rare. For those who do follow Sigil, he is more likely to provide the knowledge of what is needed to win a battle than to participate in it directly. Outside of his followers, Sigil is most well known on the Arctus Plateau, but his pursuit of knowledge puts him in touch with scholars elsewhere and ensures that his name is at least somewhat familiar, even in places where he is not commonly discussed.</p></section>

While Sigil's closest relationships have been with the mortals that he mentors, he welcomes any of the members of the Nineteen who wish to stop by Oldcraft Lodge and share their understanding of the world with him. He is particularly fond of Lumé, despite her association with fire and his with vellum, because of her ongoing fight for the homelands his parents fled from, and occasionally meets Malae in secret for midnight tea to discuss whether or not the legends of her vengeful ways are true knowledge or false gossip.

## Overview

**Sigil** prizes knowledge and information above all else. Small and bookish, the shard god often called the Elder Scholar is rarely wrong about anything and can be an excellent source of information for those who need it. He's also known on the Arctus Plateau for his home, the Oldcraft Lodge, which has an extensive library. Open to anyone who would visit in the pursuit of knowledge or because they need a safe haven, it is one of the most extensive collections of written knowledge on Ember. Though he is often too busy with research to delve deeply into mortal problems, and can be most often found bent over a large book, he has a few favorite mortals, mentoring those whose love for learning resonate with his own.

<section class="block gamemaster">
<h4>GM Notes</h4>
<p>Surprisingly for a god of information and knowledge, Sigil does not often speak much about his own path to becoming a Shard God, though rumor holds that there is a book in his library that notes every element of his past life, filed in such a way that only the most determined researcher would ever find it.</p><p>What is more commonly known about Sigil is that he was born in Moiran Lands to refugees who fled the nation as it was being consumed by undeath. Though he aspires to value all knowledge equally, Sigil has a slight resistance towards knowledge that could be use to create more undeath, and a soft spot for all those who are forced to flee their homelands. His creation of Oldcraft Lodge in the center of Arctus Plateau gave him a place to store the knowledge and books that he collects, but also to provide a place of refuge to those who might need it.</p><p>Driven to learn more about the homeland that his parents left behind , and seeking a place of security in an insecure time and place, Sigil turned to facts and knowledge as his bedrock. He became a researcher, fascinated by ancient and lost knowledge, and often accompanied adventuring groups in search of artifacts to help him build his collection of ancient scrolls and manuscripts. During one of these adventures, he followed a text tracking the location of a powerful artifact to the Heart Crystal that transformed him into a god.</p><p></p>
</section>