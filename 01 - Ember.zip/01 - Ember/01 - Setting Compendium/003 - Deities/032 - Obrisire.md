# Obrisire

*The Ancient Beast*

<section class="content"><div><p><strong>Areas of Concern: </strong>Beasts, Survival</p><section class="content"><p><strong>Typical Followers: </strong>Monster Hunters, Scouts</p><p><strong>Domains: </strong>Order, Other</p><p><strong>Pantheons:</strong>  The Nineteen, Auris Bor</p><p><strong>Symbol: </strong>A triangle of fangs.</p></section>

<section class="block readaloud"><p><span style="text-decoration:underline"><strong><span style="text-decoration:underline">Edict of Obrisire</span></strong></span></p><blockquote><p>All creatures must do what they can to survive.</p></blockquote></section>

## Overview

The colossal Shard God that swims between the oceans of Ember, **Obrisire** takes the form of a massive bony serpent with scales harder and thicker than mountains. He has very little interest in mortals or even other gods and swims slowly around the world in seemingly random patterns over thousands of years. He does have a vague interest in beings that venerate him in specific ways, most notably Obrisire is greatly entertained by anyone who tries to kill him.