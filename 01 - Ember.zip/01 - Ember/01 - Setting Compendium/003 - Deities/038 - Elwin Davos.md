# Elwin Davos

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Elwin Davos**, also known as Tyranous Vamperis, is one of the powerful Blood Barons, a group of undead beings that are on par with Shard Gods.