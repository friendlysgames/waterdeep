# Herald of the Whispering Choir

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

A cacophony of silence fills the empty spaces of your mind, an absence that reverberates through you like a precursor to something you just can't remember.