# Kerastes

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

**Kerastes** is one of the Sixteen Daemos, the powerful beings that rule Signara. His spheres of influence are Corruption and Secrecy, and he is a staunch rival of the Daemos known as Nalgomith.