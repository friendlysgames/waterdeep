# Juriel

<section class="content"><div><div><section class="block wip"><h4 data-anchor="under-construction">Under Construction</h4><p>This page is currently being developed and no further information is available for Early Access.</p></section>

## Overview

Juriel is a relatively new Tyraphem Lord from the Inner Realm of Luxarum. They claimed their position only a thousand years ago, and since then, they have faced pressure from other, more powerful Lords to defend and maintain their territory. Unlike other Lords, Juriel acts reasonably and possesses keen practical intelligence. He is also renowned for being calm, controlled, and fair, qualities that the vast majority of Tyraphem struggle to embody.