# Cobblestone's

<section class="block readaloud"><p>The sickly sweet smell of shoe polish nearly bowls you over as you step into the front room of this cluttered shoe repair shop, where an aged Kivahr cobbler works intently to mend a sole-less boot. He greets you with a nod and a smile, his crystal spectacles gleaming in the lantern light.</p></section>

Owned and operated by the talented leatherworker Brod Balehammer, this small shoe repair shop is crammed full of decades worth of tools, materials, and inventory — including more than a few single shoes that are missing a partner.

<section class="block social"><h4>Conversation with the Shopkeep</h4><dl><dt><p>Brod Balehammer (Lawful Good, Ordani Kivahr, he/him)</p></dt><dd><p>On top of his unrivaled skill as a cobbler, this aged shopkeep possesses an avuncular charm that his customers tend to find well worth the long-winded stories he tells.</p></dd></dl><p>Conversation topics include (but are not limited to) the following:</p><ul><li><p>Brod's six decades as a cobbler in Ordain, and the pride he has in his work.</p></li><li><p>His inventory (see "Exploring the Shop" below).</p></li><li><p>Observations on Falar.</p></li><li><p>Observations on Varinna.</p></li></ul><p>A few specific dialogue options for Brod are provided below.</p></section>

<section class="block qna"><p class="question">About Falar?</p><div class="answer"><blockquote><p>I've been here long enough to remember when Finnegan's tea house was on that end of the docks. Falar has been mixing his paints there now for quite some time. Come to think of it … in all these years, he's never come by my shop.</p></blockquote></div></section>

<section class="block qna"><p class="question">About Varinna?</p><div class="answer"><blockquote><p>She's the artist who lives down the lane, Stoneside. I run into her every once in a while down at The Parched Lark. As a matter of fact, they've got a few of her pieces on display. Sketches and studies, really. But interesting stuff.</p></blockquote></div></section>

In addition to speaking with Brod, the characters may explore the shop.

<section class="block exploration"><h4>Exploring the Shop</h4><p>Multiple sets of Cobbler's Tools can be found strewn about the shop, along with at least one set of Leatherworker's Tools.</p><p>A variety of mundane boots and shoes are for sale, plus one pair of each of the following (400 gp each):</p><ul><li><p>Primordian Boots</p></li><li><p>Boots of Striding and Springing</p></li><li><p>Boots of the Winterlands</p></li></ul></section>