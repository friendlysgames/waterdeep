# Varinna's Studio (Upper)

<section class="block readaloud"><p>This upstairs foyer is cluttered with an assortment of art supplies. Several brushes, pots of various paints, and an array of dog-eared reference texts are scattered across the tables here — all stained with various shades of an artist's fingerprints.</p></section>

Along with Varinna's Studio (Lower), this Promenade-level area serves as the home studio and private residence of the accomplished Ordani artist known as Varinna — who plays an important role in the  Event of the Local Color Side Quest.

During daytime hours, Varinna can be found working downstairs in the studio proper. She retires to the upstairs area for long rests and whenever she needs to retrieve something from the miscellaneous storage of the foyer.

<section class="block exploration"><h4>Exploring the Foyer</h4><p>The storage area here contains assorted tools and art materials, including 2 sets of Painter's Supplies, a Cart, 2 Ladders, and  nonfiction Books about art history and technique.</p></section>

The chamber to the south of the foyer is Varinna's bedroom, and is in a constant state of half-forgotten disarray — an apt reflection of the importance the artist places on tidiness (or distinct lack thereof).

<section class="block readaloud"><p>The bedroom here is inviting, yet bears the distinct air of desuetude, as if no one actually spends much time here. A stale loaf of bread lies half-forgotten on the side cabinet, and the unkempt bed looks like someone sleeps on top of the sheets rather than beneath them.</p></section>

<section class="block exploration"><h4>Exploring the Bedroom</h4><p>Any character who takes a moment to search the room will find  Books and  Tattered Books, spanning subjects from fictional romance to existential philosophy, along with a random Arcturian Trinket.</p><p>The locked chest on the southern wall can be opened with either a successful  or  check, and contains 245 gp, Perfume, Fine Clothes, an heirloom Handaxe, and an Entertainer's Pack.</p></section>