# Wicks & Wax

<section class="block readaloud"><p>Candles of every shape and size adorn each surface of this dimly-lit chandlery, which is warmed with the sweet and inviting smells of scented wax. The shopkeeper, a dignified Zeph with a mask crafted of rose-colored stone, turns to greet you with a gentle tilt of her head.</p><blockquote><p>You've come to the right place! Can I interest you in a new scent today?</p></blockquote></section>

This chandlery is owned and operated by the fledgling candlemaker Eliki Nort, and is known district-wide for the exquisite aromas associated with its wares.

<section class="block social"><h4>Conversation with the Shopkeep</h4><dl><dt><p>Eliki Nort (Lawful Good, Ordani Zeph, she/her)</p></dt><dd><p>This ceremonious Zeph is a chandler of moderate skill who just stepped into the candle-making business a couple of years ago, after jumping careers from her work as a lamplighter for the Hallows.</p></dd></dl><p>Given her somewhat recent career change, Eliki has relatively little to offer in terms of noteworthy details about locals like Varinna, Falar, and Seylu.</p></section>

In addition to speaking with Eliki, the characters may examine her shop. The candles here are all handmade by Eliki, and the rest of her inventory has been sourced with care and utmost consideration for ethical concerns. 

<section class="block exploration"><h4>Goods &amp; Services</h4><p>Eliki's wares include:</p><ul><li><p>Ample Candles of various shapes, styles, and purpose (including perfumed candles and those that burn with colored flame).</p></li><li><p> Bullseye Lanterns.</p></li><li><p> Hooded Lanterns.</p></li><li><p>Over 2 dozen flasks of Oil.</p></li><li><p>Blocks of wax, and other raw materials.</p></li><li><p> Chasm Candles.</p></li></ul></section>