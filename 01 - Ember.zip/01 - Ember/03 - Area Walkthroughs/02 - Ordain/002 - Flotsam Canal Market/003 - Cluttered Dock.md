# Cluttered Dock

<section class="block readaloud"><p>This cluttered vestibule is stacked full of crates, sacks, and boxes full of assorted materials — none of which seem particularly valuable or interesting at a glance, as if this lonely corner of the market is half-forgotten by those who live and work here.</p></section>

If the party visits this area prior to  and  from the Local Color Side Quest, this dock is cluttered as described above. This obstruction prevents the characters from accessing Falar's Studio to the north.

Alternately, if the party visits this area during the Local Color Side Quest, the dock is no longer cluttered, and allows the characters to access the door to Falar's Studio.

<section class="block exploration"><h4>Exploring the Dock</h4><p>Any character who makes a successful  check while searching the area is able to perform a suitably exhaustive search, revealing the presence of raw materials, ingredients, and foodstuffs, including:</p><ul><li><p>The main pile of clutter at the center section of the vestibule appears to be a conglomeration of scrap wood, splintered pallets, and empty storage containers.</p></li><li><p>The sacks to the east are stuffed with raw materials and ingredients like those used in the creation of paints, inks, and dyes.</p></li><li><p>The crates to the west contain a variety of art materials, including canvas textiles and wooden planks used for framing.</p></li><li><p>The barrels on the southern end of the dock have a capacity of 65 gallons each, and contain potable water.</p></li></ul></section>