# Main Plaza - East

<section class="block readaloud"><p>A curtain of thick jungle growth chokes the path ahead, uprooting the plaza's pale flagstones into rubble. Thorned, black vines lie coiled and writhing at the roots of the trees; one snaps at an insect with a whipcrack sound. A light mist obscures what lies beyond the tree line. The air is hot and wet in your throat.</p></section>

This area has been transformed by Falar's illusion magic into a thick, sweating jungle. Thorned, animated vines lurk among the roots and undergrowth, snapping at anything that draws too close.

<section class="block wip"><h4>Effect Under Development</h4><p>This hallucinatory terrain feature may lack a combination of walls, lighting, sounds, and similar effects. These enhancements will be added in a future update, and tied to the interactable object functionality.</p></section>

<section class="block hazard"><h4>Hallucinatory Terrain: Overgrown Jungle</h4><p>In addition to the general rules described on the Area Overview page, this hazard has the following characteristics:</p><ul><li><p>Treat the area as Difficult Terrain.</p></li><li><p>Treat the area as Lightly Obscured due to foliage and light mist.</p></li><li><p>A character who enters the hazard or who begins their turn in the hazard must make a successful  save to avoid the animated vines or suffer  damage and become Restrained. A character Restrained in this way can make a  check as a Bonus Action on their turn to free themselves; alternatively, an animated vine has AC 10 and 5 Hit Points.</p></li></ul><p>Once the area's Chiaroscuran Beast is slain, the hazard vanishes.</p></section>

<section class="block hazard"><h4>Magical Anchor</h4><p>These elemental predators are each anchored to a specific piece of illusory terrain and prefer to remain inside that area, though they can leave it if necessary.</p><h4>Chiaroscuran Beast Tactics</h4><p>At the start of combat, the Chiaroscuran Beast will enter a flat surface using  and quickly engage a character with their  ability.</p><p>Over the course of combat, the Chiaroscuran Beast will prioritize the following actions and abilities:</p><ul><li><p>In melee combat, they utilize their Scratch attack to harm enemies, and prefer to attack isolated, unaware, and vulnerable targets inside the illusory terrain they are tied to.</p></li><li><p>When hurt, they can enter a flat surface using  and recover lost Hit Points with their Redraw Form ability.</p></li><li><p>When a Chiaroscuran Beast is defeated, the terrain it is linked to dissipates, returning that section of the battlefield to normal.</p></li></ul></section>

### On a Normal Day

If the party visits this area outside the  Event, read or paraphrase the following:

<section class="block readaloud"><p>A broad sweep of pale stone lies before you, carefully ordered and paved flat. Narrow channels of water divide the plaza and draw the eye south, where a great curving promontory of stone frames the drop toward the lower grounds. Shopfronts, benches, and arches hem the space like the curtains of a stage.</p></section>

This area acts as a main thoroughfare for Redwalk Ramble. At the height of activity, artists, food vendors, and street performers gather here to display their work and ply their trade.