# Area Overview

<section class="block gamemaster"><h4>Area Map Context</h4><p>The Redwalk Ramble Area Map depicts a small slice of the larger Redwalk Ramble district. It is featured in the  Event of the  Side Quest.</p><ul><li><p>This map depicts a single Scene Level: the Redwalk Plaza.</p></li><li><p>The area typically serves as a communal space for the citizens of Ordain, especially artists, musicians, and performers.</p></li><li><p>The party arrives at the northeast corner of .</p></li></ul></section>

## Gameplay Details

The areas of Redwalk Ramble have the following features unless specified otherwise in the text.

### Levels & Elevation

The Redwalk Ramble Scene features a single Level, and its areas are organized into a single section: Redwalk Plaza.

- 
**Redwalk Plaza: **The Redwalk Plaza is set to an elevation range of 0 to 20, with 0 representing the lowest point (the ) and 20 representing the highest point (the ).

### Illumination

Redwalk Ramble is subject to exterior lighting and weather conditions.

Ample lanterns throughout the area provide Bright Light once the sun begins to go down.

### Terrain

Treat all areas as normal terrain unless otherwise noted.

- 
Rock walls in the Scene can be climbed as &reference[difficult terrain] with a successful  check, but are otherwise impassable, requiring premade pathways to move up or down the natural slope of the terrain.

- 
Water features present are shallow enough to walk across but do present &reference[difficult terrain] for characters that traverse them.

- 
While the shops are all locked and lack interiors for character to explore, they are still present on the Area Map and could be entered at the Gamemaster's discretion. Their doors are made of reinforced oak (AC 17, 25 Hit Points), requiring a successful  check to force open, or a successful  check to unlock.

<section class="block hazard"><h4>Falar's Hallucinatory Terrain</h4><p>During the  Event, Falar enchants several areas of Redwalk Ramble with Hallucinatory Terrain. The particulars of each piece of illusory terrain is explicated more fully where it appears in the text, but each illusion follows these general rules:</p><ul><li><p>Falar has made these spells permanent — and very dangerous — by empowering them with the Lifeforce of several Chiaroscuran Beasts; when a beast is slain, its associated illusory terrain vanishes.</p><ul><li><p>Because of their connection to the chiaroscuran beasts, the illusions include audible, visual, tactile, and olfactory elements, so it can turn clear ground into Difficult Terrain (or vice versa) or otherwise impede movement through the area. Any piece of the illusory terrain (such as a rock or stick) that is removed from the spell's area disappears immediately.</p></li><li><p>Creatures with Truesight — and creatures who make a successful  check to examine the illusory terrain — can see through the illusion to the terrain's true form; however, all other elements of the illusion remain, so while the creature is aware of the illusion's presence, the creature can still physically interact with the illusion.</p></li></ul></li><li><p>The chiaroscuran beasts are immune to the hazardous effects of any piece of illusory terrain in Redwalk Ramble, and can pass through any illusory obstacles or hazards with impunity.</p></li><li><p>Dispel Magic targeting the illusory terrain fails automatically, but inflicts  damage multiplied by its spell level to the hazard's associated chiaroscuran beast. For example, Dispel Magic cast using a 5th-level spell slot would inflict  damage to the hazard's associated chiaroscuran beast.</p></li></ul><p>There are five hazardous areas of illusory terrain:</p><ul><li><p>Overgrown Jungle</p></li><li><p>Tomb</p></li><li><p>Scorching Desert</p></li><li><p>Lava Floe</p></li><li><p>Pit Trap</p></li></ul></section>

### Enemies

During the  Event, the following enemies are encountered here:

- 
5 Chiaroscuran Beasts, each one connected to a section of illusory terrain that they are serving as the magical anchor for.

- 
5 Paint Globlins, hidden in jars of paint around the area. They emerge when a character moves within 15 feet of their jar, or if their jar is shattered.

- 
Falar, located near the Promontory.