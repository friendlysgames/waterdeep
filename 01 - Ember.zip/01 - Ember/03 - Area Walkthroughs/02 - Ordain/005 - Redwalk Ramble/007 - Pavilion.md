# Pavilion

<section class="block readaloud"><p>A platform of sun-bleached stone, perched atop a natural outcropping, looks over the grounds. It offers a clear view of the lower plaza circle, the gentle water, and the crimson skyline of Ordain beyond. The stones have been worn into irregular shapes by the feet of hundreds of dancers.</p></section>

This raised, open-air dais serves as a public gathering place for a variety of social functions, such as wine tastings, dances, parties, and ceremonies.