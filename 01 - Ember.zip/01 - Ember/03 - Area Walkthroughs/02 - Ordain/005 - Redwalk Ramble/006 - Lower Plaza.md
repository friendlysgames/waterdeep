# Lower Plaza

<section class="block readaloud"><p>The area ahead appears as an unbroken, level plain, its chalky flagstones fitted together as a perfect jigsaw. Its seams are so fine as to be nearly invisible.</p></section>

This area has been transformed by Falar's illusion magic to conceal a large pit trap beneath the appearance of solid ground.

<section class="block wip"><h4>Effect Under Development</h4><p>This hallucinatory terrain feature may lack a combination of walls, lighting, sounds, and similar effects. These enhancements will be added in a future update, and tied to the interactable object functionality.</p></section>

<section class="block hazard"><h4>Hallucinatory Terrain: Pit Trap</h4><p>In addition to the general rules described on the Area Overview page, this hazard has the following characteristics:</p><ul><li><p>The pit trap is 30-feet deep.</p></li><li><p>A character that moves into the hazard falls 30 feet, taking  damage and landing &amp;Reference[Prone].</p></li><li><p>A character inside the hazard can climb out using natural handholds with a successful  check.</p></li></ul><p>Once the area's Chiaroscuran Beast is slain, the hazard vanishes; creatures still inside the hazard when this occurs are ejected, landing safely with a soft thump on solid ground.</p></section>

<section class="block hazard"><h4>Magical Anchor</h4><p>These elemental predators are each anchored to a specific piece of illusory terrain and prefer to remain inside that area, though they can leave it if necessary.</p><h4>Chiaroscuran Beast Tactics</h4><p>At the start of combat, the Chiaroscuran Beast will enter a flat surface using  and quickly engage a character with their  ability.</p><p>Over the course of combat, the Chiaroscuran Beast will prioritize the following actions and abilities:</p><ul><li><p>In melee combat, they utilize their Scratch attack to harm enemies, and prefer to attack isolated, unaware, and vulnerable targets inside the illusory terrain they are tied to.</p></li><li><p>When hurt, they can enter a flat surface using  and recover lost Hit Points with their Redraw Form ability.</p></li><li><p>When a Chiaroscuran Beast is defeated, the terrain it is linked to dissipates, returning that section of the battlefield to normal.</p></li></ul></section>

### On a Normal Day

If the party visits this area outside the  Event, read or paraphrase the following:

<section class="block readaloud"><p>A circle of broad, chalk-white flagstones sits in the shadow of the promontory — the performer to the promontory's audience. A shallow stream of clear water babbles beneath it to pool on the other side.</p></section>

The lower plaza circle serves as a performance and exhibition space for artists, fashion models, actors, and singers; it is one of many such performance plazas dotting Redwalk Ramble.