# Coat Room

<section class="block readaloud"><p>This cramped space is lined from floor to ceiling with shelves and iron rails burdened by a confusion of cloaks, capes, coats, and traveling bags. A dozen different perfumes cling to the air in thin threads, mingled with the tang of leather, and dried sweat.</p></section>

<section class="block exploration"><h4>Hidden Treasure</h4><p>A character than spends 5 minutes searching the shelves and makes a successful  check will find the .</p></section>