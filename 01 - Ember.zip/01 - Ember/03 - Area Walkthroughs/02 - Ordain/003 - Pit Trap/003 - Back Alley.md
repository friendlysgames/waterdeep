# Back Alley

<section class="block readaloud"><p>The broad back alley behind the pit trap goes on some distance, the length of it filled with crates, discarded wood pallets, barrels, and packing material. Numerous doors and smaller alleys connect to this space, leading to other businesses, stores, workshops, and more. While some doors are marked with signs, many are not.</p></section>

<section class="block exploration"><h4>Tracking Zira</h4><p>By the time the party arrives in this space Zira will have made a clean escape. No rolls should be given to attempt to find her, as her escape is intended to be successful no matter what the party does.</p><p>If the party wants to spend time looking for her narrate the following:</p></section>

<section class="block readaloud"><p>After a quick search you find no evidence of Zira's passage through this area. The numerous old footprints and well worn paths weaving through crates and garbage in the alley yield no insights, and not even a single creature is present to be pressed for information. </p><p>It seems that Zira managed to a clean escape for now.</p></section>