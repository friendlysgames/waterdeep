# Side Office

<section class="block readaloud"><p>A threadbare couch hugs one wall here, opposite a scarred wooden table and two mismatched chairs crammed into a corner. On the wall, a broad board of dark wood bristles with notes and announcements pinned under iron tacks. A few bottles of alcohol and accompanying glasses sit on the table, each one half full in its own way, and forgotten for the moment.</p></section>

If a character decides to examine the board and the notes here, read the following:

<section class="block readaloud"><p>The board is covered in all manner of notes, plans, messages, and more. The week's shift rosters scribbled in uneven script sits beside a list of band names and the dates they are booked to perform, which sits overtop half a dozen notes about people who should or should not be let in to the club.</p></section>