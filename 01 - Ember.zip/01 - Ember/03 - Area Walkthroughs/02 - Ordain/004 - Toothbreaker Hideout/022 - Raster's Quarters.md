# Raster's Quarters

<section class="block readaloud"><p>This rectangular room is well cared for and furnished more intentionally than the rest of the hideout. Several prominent trophy skulls line the walls, and the decor — while not matching — produces the cozy feeling of a woodsman's cottage.</p></section>

The door to this chamber remains locked at all times. Raster Thorn possesses the only key.

<section class="block hazard"><h4>Raster's Bedtime</h4><p>Raster sleeps here from 1am to 9am each day.</p><p>If the party seeks to ambush Raster while he sleeps, it is possible for them to break through the adjoining well from Collapsed Quarters, following the rules described there. Raster employs tactics in combat described in .</p><h4>Risky Resting</h4><p>The party can risk resting here, if they do so outside of the sleeping hours described above.</p></section>

The party will doubtless be interested to inspect or plunder Raster's personal belongings.

<section class="block exploration"><h4>Raster's Belongings</h4><p>Upon cursory inspection, the room contains several minor treasures including:</p><ul><li><p> in loose coin</p></li><li><p>Two finely crafted Daggers</p></li><li><p>One Battleaxe</p></li><li><p>One six-foot long Varrol tusk in a display case that weighs 40 pounds and is worth  to an interested merchant.</p></li><li><p>One spare Toothbreaker Throneroom Key.</p></li></ul><p>With a thorough and successful<sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check the party can find the following additional items of interest scattered around the room:</p><ul><li><p>One Potion of Water Breathing</p></li><li><p></p></li><li><p></p></li><li><p></p></li><li><p></p></li></ul></section>