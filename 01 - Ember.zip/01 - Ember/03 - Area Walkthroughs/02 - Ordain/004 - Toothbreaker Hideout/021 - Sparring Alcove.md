# Sparring Alcove

<section class="block readaloud"><p>This circular alcove is lit by the flames of a single torch ensconced on the southern wall, and appears to be some sort of modest sparring or training room. A lone Toothbreaker warrior assaults a combat dummy in the center of the chamber with kicks and unarmed blows, shouting loudly with each new strike. Indeed, the clamor of this martial performance is so loud and intense, the thug seems oblivious to your initial approach.</p></section>

<section class="block exploration"><h4>Focused Training</h4><p>The training thug is focused on his martial exercises. Characters who approach and move into the room can avoid detection with a successful <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check.</p></section>

<section class="block hazard"><h4>Toothbreakers</h4><p>There is a solitary Toothbreaker Thug in this room practicing martial arts.</p><h4>Raising the Alarm</h4><p>This room contains an alarm bell, which the Toothbreaker Thug will ring if they become aware of any interlopers.</p></section>

<section class="block exploration"><h4>Locked Door</h4><p>The door to the Planning Room is locked.</p><p>Two corresponding Toothbreaker Planning Keys can be found elsewhere in the hideout: one is in the possession of Vaafo the Scaletamer in Scalemaw Training, while another is currently held by Raster Thorn himself.</p></section>