# Barracks

<section class="block readaloud"><p>This makeshift barracks is lined with several bunks and weapon racks. A pair of mess tables in the center of the chamber are covered with a cluttered assortment of food, personal effects, and games of strategy.</p></section>

Unless the party members are being escorted through this area as guests or prisoners, they'll be treated as trespassers and immediately attacked by the trio of Toothbreaker Thugs who dwell here.

<section class="block hazard"><h4>Toothbreakers</h4><p>The Toothbreaker Thugs here follow the tactics described in Enemy Tactics.</p><h4>Raising the Alarm</h4><p>An alarm bell is mounted just outside the barracks in the western hallway towards the Cistern Bloodring. If under attack, the Toothbreaker Thug nearest to the door will break away to ring the alarm. which will draw the attention of all their nearby allies in the Bloodring as well as in the Planning Room to the south.</p></section>

Once combat in this room has concluded, the party may wish to investigate it's contents.

<section class="block exploration"><h4>Toothbreaker Plunder</h4><p>Spending a minute to search the room reveals the following items of interest:</p><ul><li><p>An assortment of 12 mundane weapons.</p></li><li><p>Loose coin including </p></li><li><p>A pair of mundane Scalemaw Boots crafted from cured Scalemaw leather, sized for a Kivahr wearer. The boots are in good condition and worth .</p></li></ul><h4>Locked Door</h4><p>The southern door to the Planning Room is locked. It can be unlocked by the Toothbreakers inside the room or from the outside using a Toothbreaker Planning Key which is in possession of Vaafo the Scaletamer in Scalemaw Training or using Raster's keyring. The lock can be picked with a successful <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check.</p></section>