# Cistern Bloodring

<section class="block readaloud"><p>The grand central atrium of the Concourse Hideout is a huge vaulted chamber, the ceiling is nearly 100 feet overhead whic descends into darkness as water cascades from a concentric ring of waterfalls into the depths of the cistern below. In the center of the chamber, a platform stands upon a column of rock, connected by three bridges.</p><p>Upon the platform is built a ramshackle arena, tiered wooden bleachers surrounding an octagonal roped ring. Lights are strung overhead to illuminate the arena. An assortment of Toothbreakers or their guests lounge upon the bleachers, calling out encouragement to the combatants who battle in the ring.</p></section>

Unless the party has been invited into this area as guests or they are escorted as prisoners, they will be treated as trespassers and immediately attacked. There are a large number of Toothbreakers in this area and the arena is overseen by one of Raster's Scaletamer lieutenants named Ukkfal.

<section class="block exploration"><h4>Ukkfal's Key</h4><p>Taamsin is in possession of the Toothbreaker Prison Key which can be taken from his body or pickpicketed during the chaos of a Bloodring fight with a successful <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check. Failure on this check immediately turns Ukkfal hostile.</p><p>If a character is a combatant fighting in the Bloodring, they can attempt a <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check to theatrically distract Ukkfal. If this check is successful, the above pickpocket check can be made with .</p></section>

## Bloodthirsty Spectators

Parties that are invited guests of the Toothbreakers are free to mingle here, spectate on fights, and place bets on their outcomes. Gambling on the Bloodring fights is coordinate in the Bar.

<section class="block social"><h4>Bloodring Spectators</h4><p>The various Toothbreakers here are largely intent on watching the action, but they can be engaged in conversation. Characters succeeding on a <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check can glean one of the following pieces of information per attempt.</p><p></p><p>If the party fails this check three times, the Toothbreakers communicate their displeasure to Ukkfal who demands that the party "shut up, or leave".</p></section>

<section class="block hazard"><h4>Toothbreakers</h4><p>If provoked into combat, the Toothbreakers here will follow the tactics described in Enemy Tactics.</p><h4>Raising the Alarm</h4><p>The nearest alarm bells to the Bloodring to the east across the bridge towards the Barracks, in the Prison to the northwest, or in the Sparring Alcove to the southeast.</p></section>

## Forced to Fight

If the party has been taken captive and forced to fight in the Bloodring, the following rules apply.

- 
The party must fight in a sequence of blood-sport contests within the arena. For each of the following four fights the party may volunteer a fighter otherwise Ukkfal will select combatants at random.

- 
No character may participate in consecutive rounds unless there is no other option. Each challenge has certain special rules that are clearly explained by Ukkfal at the start of the round. Breaking the rules of the encounter is grounds for disqualification.

- 
Damage dealt during these fights is not non-lethal and may kill or render unconscious the combatants. The Toothbreakers do not care if fighters lose their lives.

- 
If disqualified, the combatant is subdued by Ukkfal and the spectating Toothbreakers. This either leads to a full combat encounter or if the combatant does not resist, they are returned to their prison cell with1 hit point0 Health.

- 
There is only sufficient time between fights for the party to perform a short restRecover.

<section class="block hazard"><h4>Fight 1 - Bareknuckle Scuffle</h4><p>In this challenge, a combatant must face off against a single Toothbreaker Thug. Rules for this fight are:</p><ul><li><p>You may wear no weapons, armor, or other equipment.</p></li><li><p>Use of spells or magical abilities is prohibited.</p></li></ul></section>

<section class="block gamemaster"><h4>Unarmed Strikes</h4><p>Ensure that the character has the Unarmed Strike feature added to their character sheet which is likely their only viable means of attacking.</p></section>

<section class="block hazard"><h4>Fight 2 - Tag Team</h4><p>In this challenge, a pair of combatants faces off against a pair of Toothbreaker Thug. Rules for this fight are:</p><ul><li><p>Each combatant is provided with a Club which is their only permitted weapon. No armor or other equipment is permitted.</p></li><li><p>One combatant on each team must remain outside the ropes while the other combatant remains inside the octagon. As a free action on their turn, a combatant may "tag out" enabling their ally to enter the arena at the beginning of their next turn.</p></li><li><p>Combatants outside the ropes may attack enemies they can reach.</p></li><li><p>Use of spells or magical abilities is prohibited.</p></li></ul></section>

<section class="block hazard"><h4>Fight 3 - Burnished Hand to Hand</h4><p>In this challenge, a single combatant must face off against a captured Burnished Hand Protector. Rules for this fight are:</p><ul><li><p>Both combatants may use their full set of equipment.</p></li><li><p>Spells or magical abilities are permitted.</p></li></ul></section>

<section class="block hazard"><h4>Fight 4 - Scalemaw Duo</h4><p>In this challenge, a pair of combatants must face off against Vaafo the Scaletamer and a trained Scalemaw. Rules for this fight are:</p><ul><li><p>All characters may use their full set of equipment.</p></li><li><p>Spells or magical abilities are permitted.</p></li></ul></section>

If the party was not victorious in all four challenges, Raster does not view them as worthy adversaries and pays them no attention. The party is left in the prison cages to be turned over as test subjects to Kaftor Brenk and the mutagists. They must devise their own means of escape.

## Challenging Raster

If the party is victorious in all four of these challenges, Raster Thorn himself challenges the strongest — defined as the character with the greatest Strength attribute — among the party to a direct battle. The challenge is scheduled to take place "tomorrow", and the party is afforded time to long restbenefit from a Full Rest.

<section class="block hazard"><h4>Raster Thorn</h4><p>Raster fights using the tactics described in .</p><ul><li><p>The assembled Toothbreakers recognize that this battle is a traditional Waerd contest of might and martial acumen and they do not interfere.</p></li><li><p>If the party interferes with this duel by taking any action, then the Toothbreakers also join the battle, resulting in an all-out skirmish between both sides.</p></li></ul><p>Defeating Raster within the Bloodring constitutes a shocking and legendary victory for the party. The assembled Toothbreakers watch in stunned silence and take no action to retaliate or stop the party from leaving afterwards.</p></section>