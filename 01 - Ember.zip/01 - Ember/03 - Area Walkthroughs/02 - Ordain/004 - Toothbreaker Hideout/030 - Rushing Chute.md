# Rushing Chute

<section class="block hazard"><h4>One-Way Water</h4><p>Any character who enters the water in the grid space west of this chute must make a successful  save to avoid being sucked into the chute's rushing water. Failure results in the character being deposited seconds later in the canals of the Tea Room to the southeast, as well as being subject to the following effects:</p><ul><li><p>Any flames the character is carrying are extinguished.</p></li><li><p>Any character with  suffers 1 level of Exhaustion.</p></li></ul></section>

If a character is pulled into the chute, read the following aloud:

<section class="block readaloud"><p>As you draw closer to a narrow chute on the wall, you feel a sudden and violent tug on your lower body as you become swept up in a rapid flow of water to the southeast. Before you know it, you emerge from this subterranean torrent and find yourself in a different section of the hideout's lazy canals.</p></section>