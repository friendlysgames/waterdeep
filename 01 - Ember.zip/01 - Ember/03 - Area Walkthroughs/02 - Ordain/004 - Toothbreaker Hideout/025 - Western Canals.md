# Western Canals

<section class="block readaloud"><p>Water flows freely here through a broad canal that is 10 feet wide and deep. The underground passageway ripples with a pale blue hue as the canal flows southward towards a circular interchange. To the west, a walkway borders the canal opening to several rooms, some of which appear to be fully collapsed while others have doors.</p></section>

<section class="block gamemaster"><h4>Cutting off the Flow</h4><p>The flow of water here can be disabled by turning the valves in Flow Control.</p></section>

If the canals have been drained, read:

<section class="block readaloud"><p>The broad canal here is emptied of water, its flow having been restricted by a pair of large sluices further upstream. The bed of the canal is grimy and full of silt, mud, and puddles of lingering water.</p></section>

<section class="block exploration"><h4>Mudflisk Source</h4><p>If the canals are drained, it's possible to harvest Mudflisk from the canal bed with a successful <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check.</p></section>

<section class="block hazard"><h4>Enraged Scalemaw</h4><p>One of the Toothbreaker's trained Scalemaws is loose and patrolling this section of canal. This Scalemaw has become enraged and volatile after being exposed to Gleaming Distillation. Scant details of that exposure are documented in Scalemaw Kennels.</p><p>As long as the canals are full of water, Vesk is hidden and able to attack from stealth unless detected by a character with <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup>.</p><p>The Scalemaw is named "Vesk" and will attack any character or creature without provocation that passes through this area. Raster Thorn and other Scaletamers are not able to pacify the creature, but they have the skills to avoid it's aggression.</p></section>