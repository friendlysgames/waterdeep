# Northern Canals

<section class="block readaloud"><p>After following a meandering network of canals through the Concourse waterworks, you reach a landmark that suggests you have found the Toothbreaker Hideout at last. The canal before you diverges — one side flows southwest into a gated culvert, while the other fork gains speed as it flows downhill towards a cavernous opening to the south of your current position.</p><p>Before the water reaches that southern opening, it flows beneath a rusted metal walkway that appears overgrown with canal weeds and creepmoss.</p></section>

<section class="block hazard"><h4>Flowing Water</h4><p>Some sections of the canals here contain rapidly-flowing water, and the characters cannot remain stationary within them. This is one such section. As the characters begin moving southward, they are carried onwards by the flowing current.</p><p>Outside of combat, this is simply a narrative flourish. Refer to the Terrain rules for additional details about movement during combat here.</p></section>

## Canal Walkway

Once the party reaches the metallic walkway that spans the canal — which affords them an opportunity to exit the water — they can overhear the following muffled conversation, coming from "somewhere" to the east (the Interrogation Room).

<section class="block readaloud"><p>As you mount the metallic catwalk, you notice the muffled sound of a masculine voice behind a door to the east.</p><blockquote><p>… you should have told us sooner, but now it's too late, dear Fen. Far too late.</p></blockquote><p>A second, high-pitched voice interrupts the first with a panic-stricken tone:</p><blockquote><p>No! Wait! I can still be …</p></blockquote><p>Panic turns to pain as the second voice screams out with unmistakable agony from some unknown source. This wailing continues unabated for several seconds until a wet gargling overtakes it, and all falls conspicuously silent.</p></section>

Aside from the obvious ramifications of the exchange, the party is unable to conclude anything further without opening the door in the Interrogation Room itself.