# Area Overview

<section class="block gamemaster"><h4>Area Map Context</h4><p>This area walkthrough provides a guide of the "Toothbreaker Hideout", a landmark located within The Concourse, which is encountered during the quest The Expedition Challenge.</p><p>In the below gazetteer entry for The Concourse district, this location is described as the "Concourse Hideout".</p></section>

## Gameplay Details

The following gameplay features apply to the Toothbreaker Hideout area unless specifically stated otherwise in a specific room description.

## Sound

The Waterworks feature a constant low roar of flowing water, cascading waterfalls, and echoing sounds that resonate through the tunnels. As a consequence, hearing in this environment is more challenging. The Toothbreakers talk loudly and boisterously to each other, and the hubbub of their conversations further drowns out other sounds.

- 
Sounds of combat can only be heard within 30 feet of their origin, and they are muffled completely beyond the stone walls of a room if its doors are closed.

- 
Characters in this area have  to any  skill check made to avoid being heard.

- 
The verbal components of Spells can be enunciated quietly enough such that they do not attract attention.

<section class="block hazard"><h4>Alarm Bells</h4><p>The Toothbreakers use a rudimentary system of alarm bells to alert each other to any trouble throughout the hideout. Scattered throughout the complex are wall-mounted bells that, if rung, emit an audible alarm that is heard by other Toothbreakers within a 60 foot radius who have a direct line of hearing towards the source of the alarm, and by Toothbreakers within a 30 foot radius otherwise.</p><ul><li><p>Ringing one of these alarm bells during Combat requires <sup class="system-swap-inline"><sub data-system="dnd5e">using an Action</sub><sub data-system="crucible">spending 3 Action</sub></sup>.</p></li><li><p>An alarm bell can be silently disabled outside of Combat to render it unusable.</p></li></ul></section>

<section class="block gamemaster"><h4>Interactive Element</h4><p>The alarm bells are interactive objects which are usable by the Gamemaster. They can be rung or disabled according to the party's actions!</p></section>

## Illumination

The exterior areas of the map are exposed to direct sun and moonlight and follow typical expectations for outdoor areas.

Most interior areas of the waterworks are illuminated by torches or lanterns which create bright or dim light. In some larger chambers, apertures in the ceiling high above permit external illumination to shine through, creating additional areas of dim light. Otherwise the waterworks are un-illuminated and entirely dark.

## Terrain

Areas of solid floor within the waterworks are treated as normal terrain. The water of the canals moves slowly and the canals are 10 feet deep, within the canals standard rules for swimming apply.

<section class="block hazard"><h4>Flowing Currents</h4><p>During combat, any creature that does not have a Swim speed and begins its turn in the water of the canals (either at the surface or submerged) is immediately moved 10 feet in the direction of the flowing current. This movement may <sup class="system-swap-inline"><sub data-system="dnd5e">provoke attacks of opportunity</sub><sub data-system="crucible">cause unsafe disengagement</sub></sup>.</p></section>

### Keys and Locked Doors

Several different denominations of keys that restrict access within the hideout:

- 
Toothbreaker Security Key

- 
Toothbreaker Prison Key

- 
Toothbreaker Planning Key

- 
Toothbreaker Throneroom Key

- 
Raster's Keyring

## Elevation

The interior of the waterworks is mostly flat ground (elevation 0), the staircases depicted are cosmetic and do not cause mechanically impactful changes in elevation. The surface of the canals is mechanically level with the stone floors and they are 10 feet deep.

Several canals flow towards an outlet into a deep central cistern. The water within that central cistern is 100 feet below.

<section class="block hazard"><h4>The Central Cistern</h4><p>A creature that is pushed or conveyed by the water towards the edge of the cistern may make a <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check to grasp a secure handhold and avoid being swept over the brink. Creatures falling from the waterworks into the cistern take only half the normal falling damage that would occur from a fall of 100 feet.</p><p>There is no direct method for a character who has fallen into the cistern to return to the Waterworks aside from following a labyrinthine network of lower tunnels out of the complex and returning to an accessible entrance. This process consumes 1 hour of time.</p></section>

Two of the canals outlet into great waterfalls that cascade down to the exterior city 200 feet below.

<section class="block hazard"><h4>Exterior Waterfalls</h4><p>A character that is pushed or conveyed by the water towards the precipice of an exterior waterfall may make a <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> check to grasp a secure handhold and avoid being swept over the brink.</p><p>Creatures who fall from this height suffer the full effects of falling damage from a height of 200 feet.</p></section>

## Enemies

This area is the base of operations for the Toothbreaker gang and is full of their members. At most times, the following enemies are encountered here in the provided approximate number:

- 
30 Toothbreaker Thug

- 
4 Toothbreaker Scaletamer

- 
8 Scalemaw

- 
Raster Thorn

<section class="block hazard"><h4>Significantly Outnumbered</h4><p>Because of the large number of adversaries in this area, an uncontrolled assault is likely to be deadly. The party would be well advised to use stealth or guile to avoid direct confrontation where possible.</p><h4>Resting</h4><p>It is not possible to take a Long Rest within this area without being detected. A Short Rest is only possible in a few specific rooms which mention this as part of their location details.</p><h4>Fleeing</h4><p>Should the party need to flee the area, they may do so by retreating to the main , the , or via theCanals to the north or southeast of the map, or in truly desperate fashion by jumping out of one of the waterfall outlets to the south of the area.</p><h4>Captured</h4><p>If the party is subdued in combat, they may awaken from an unconscious state as captives held within the cages of the . Raster and his gang will use captives for sport as fighters in the Cistern Bloodring. A party that finds themselves in such a dire circumstance may attempt a desperate escape or hope for allies to come to their rescue.</p></section>

See the Toothbreaker Tactics section of the Appendix for additional details about enemy behavior in combat.