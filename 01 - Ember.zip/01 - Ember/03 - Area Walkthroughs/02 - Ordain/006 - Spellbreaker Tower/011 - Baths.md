# Baths

<section class="block readaloud"><p>A large communal bath occupies the center of this room, its broad basin fed by a flow of hot water that keeps the air damp and warm. Along the sides sit two smaller individual baths, separated only by low stone partitions that offer little privacy. Steam hangs in the air here at all hours, while water trickles and laps against stone in a steady, echoing sound.</p></section>

On-duty guards come here to bathe before or after shift before going to the barracks. While not occupied at all hours, it is visited often.