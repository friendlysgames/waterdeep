# Central Elevator

<section class="block readaloud"><p>Four heavy braziers throw warm light across the intricately carved floor here and paint the walls in slow, wavering shadow. Intricately carved walls pick up dancing shadows as the walls lead around toward a gated checkpoint.</p></section>

This room features the Central Elevator which provides access to other levels.