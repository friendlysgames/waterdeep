# Central Security 5

<section class="block readaloud"><p>The light of four braziers creates an undulating mask of shadows here as light flickers across carved floors and heavy barred windows. The central elevator here features doors on the north and west faces, both stepping out to subtle flames engraved in the stone underfoot.</p><p>A bank of levers sits against the central elevator wall, with four levels for the four checkpoints and two more levers marked as controlling the south and east hall gates.</p><p>In the south-eastern corner of the room a long corner table sits against the wall and features the collective efforts of the central security team for this level. A collection of colorful buttons fixed to copper pipes running into the wall can also be found here.</p></section>

<section class="block hazard"><h4>Heavies on Standby</h4><p>While the stations here are manned by standard guards, like all other central security levels, three Spellbreaker Riot Guards are always on duty here, standing by in case there's a problem in the cell blocks.</p></section>

Access to this room is controlled by two heavy gates.

This room features the Central Elevator which provides access to other levels.