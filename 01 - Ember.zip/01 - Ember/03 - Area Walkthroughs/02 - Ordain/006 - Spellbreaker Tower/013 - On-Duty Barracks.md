# On-Duty Barracks

<section class="block readaloud"><p>These barracks are a cluster of connected common rooms featuring rows of wood-framed beds and accompanied by chests packed with personal belongings and clothes. The air carries the mixed smells of oiled leather, sweat, and lantern smoke.</p></section>

Guards on duty are housed here. This space is more occupied during the evening hours than during daytime, but always has a few guards in it, often sleeping.

<section class="block exploration"><h4>Personal Effects</h4><p>Searching through the chests here will yield several outfits of common clothes, and more crucially, clean guard uniforms including belts, boots, and padded coats. </p><p>There are enough uniforms for two people, though a successful  check will yield two more. Wearing these uniforms allows one to pass for an off-duty guard on this level without drawing attention as the wearer is not acting suspiciously.</p><ul><li><p><strong>Result of 20+</strong> You also find a set of guard keys that will open any wooden doors encountered on any level, and any cells on Level 2 or Level 3.</p></li></ul></section>