# Lavatories

<section class="block readaloud"><p>The guard’s washroom is lined with wooden toilet stalls, their partitions offering partial cover for occupants. The space here is clean, and the air smells of incense and perfumes meant to keep the more offensive odors at bay.</p></section>

This room is used often by off-duty guards on this level.