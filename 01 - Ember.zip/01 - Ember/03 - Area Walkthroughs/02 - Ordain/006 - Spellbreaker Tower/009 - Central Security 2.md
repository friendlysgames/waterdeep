# Central Security 2

<section class="block readaloud"><p>Warm light cast by four braziers dances between the geometric patterns carved into the floor and along the stony walls. Beyond them, through barred windows, the central hall of the prison can be seen.</p><p>Set against either side of the central elevator walls are banks of levers, four total, each labeled with the gate they control access to. Along the walls opposite them are bookshelves, crates, chests, and desks littered with papers where the guards file reports and keep logs of events.</p><p>On the eastern wall a set of color coded buttons are fixed to the wall.</p></section>

Access to this room is controlled by two heavy gates.

This room features the Central Elevator which provides access to other levels.