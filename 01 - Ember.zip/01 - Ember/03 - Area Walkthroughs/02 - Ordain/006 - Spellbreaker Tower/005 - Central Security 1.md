# Central Security 1

<section class="block readaloud"><p>Four heavy braziers throw warm light across the intricately carved floor here and paint the walls in slow, wavering shadow. Numerous windows provide extensive views of the outer halls, allowing the guards here to see everything going on outside.</p><p>Large pots occupy the corners of the room, each holding red, leafy plants with broad, waxy fronds. Their earthy scent mixes with smoke from the braziers, and bits of fallen leaf litter the floor around the planters.</p></section>

Access to this room is controlled by two heavy gates.

This room features the Central Elevator which provides access to other levels.