# Central Security 4

<section class="block readaloud"><p>Four large braziers burn at the corners, filling the air with heat and the bitter smell of smoke. Despite their presence, the haze is light, and following its movement you see it escaping into vents in the ceiling.</p><p>Flanking the central elevator walls are two banks of levers, with two levers apiece. Each lever is marked with the checkpoint it controls. Opposite these banks are two decks covered in paperwork and log books. The west desk is fitted with a bank of color-coded buttons on copper fittings.</p></section>

Access to this room is controlled by two heavy gates and features the Central Elevator which provides access to other levels.