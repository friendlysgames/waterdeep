# Alchemy

<section class="block readaloud"><p>This cramped alchemical workshop is crowded with blackened glassware and dried herbs strung from a timber rack. A clouded alembic rests on the workbench, surrounded by sparse but meticulously arranged supplies.</p></section>

This area is used as an alchemical workshop and storage space. The Cindarics prepare medicines, tinctures, and curative draughts here before distributing them throughout the infirmary.

<section class="block hazard"><h4>Locked &amp; Off Limits</h4><p>The doors to this chamber remain locked unless a surgical procedure is taking place. Each door can be unlocked with a Traveler's Rest Key or a successful ; alternatively, it can be bashed open with a  check.</p><p>Characters found in this area without a good reason will be asked to leave Traveler's Rest and be barred from returning.</p></section>

<section class="block exploration"><h4>Alchemical Lab</h4><p>This area contains an alchemical lab and enough alchemical components to craft 1 of each of the following:</p><ul><li><p>Antifungal Draught</p></li><li><p>Anticoagulation Tonic</p></li><li><p>Dissolution Tonic</p></li><li><p>Heartward Elixir</p></li><li><p>Cindaric Mint Tea</p></li><li><p>Potion of Healing</p></li></ul><p>Alchemical components are restocked on the first day of each month.</p></section>

### 

If the characters return during the  Side Quest, the alchemical supplies are completely exhausted.