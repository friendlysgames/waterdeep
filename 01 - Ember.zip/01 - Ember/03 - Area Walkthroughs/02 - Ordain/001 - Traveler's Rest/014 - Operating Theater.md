# Operating Theater

<section class="block readaloud"><p>Tiered timber benches surround a central operating table, its surface scrubbed pale over years of use. Brass instruments are arranged neatly beside a clay basin stained russet by antiseptic tinctures, and the air smells faintly of iron and ammonia.</p></section>

This spacious chamber serves as a teaching theater, where elder Cindarics and other specialists perform instructional operations for a congregation of students. Outsiders are permitted, but visitors are required to stay quiet during procedures (and will be asked to leave if they violate this rule more than once).

<section class="block exploration"><h4>Exploring the Operating Theater</h4><p>The Operating Theater contains nothing of interest outside of surgical demonstrations (see "Surgical Lesson" below).</p></section>

### Surgical Lesson

At your discretion, characters who enter this area during the day may find a precise and delicate surgery about to begin; they are welcome to take a seat amongst the students and watch. If they do, read the following:

<section class="block readaloud"><p>Students settle along the tiered benches as Cindaric Adherents prepare the operating table below. One draws brass medical instruments from a basin of steaming water, laying them side by side on a ceramic tray, while another stands at the ready with clean boiled cloths. When all is prepared, the lead surgeon raises a hand for quiet and begins to speak.</p></section>

<section class="block exploration"><h4>Operation</h4><p>Roll on (or choose from) the Surgery table to determine which particular procedure is currently in progress.</p><h4>No Interruptions</h4><p>Characters who attempt to speak during the presentation are promptly shushed by a nearby student; characters who persist in being disruptive are asked to leave the theater.</p><h4>Follow Along</h4><p>A character who observes the operation for at least 1 hour and makes a successful  check to follow along gains  on their next  check made to treat a creature.</p><ul class="complex-check"><li class="automatic-success"><p>: The character automatically succeeds on this check.</p></li><li class="advantage"><p>: The character gains  on this check.</p></li></ul></section>

### 

If the characters return during the  Side Quest, the operating theater stands empty; all Cindarics are busy fighting the mysterious wasting illness here and elsewhere in Ordain.