# Examination Room

<section class="block readaloud"><p>The air of this large room is marked by a melange of strange odors, from the coppery scent of fresh blood to the musky fragrance of stale incense. No doubt, these odors emanate from the countless jars, urns, and casks that decorate this clinical place. A central examination table dominates the room, surrounded by an array of tool carts and end tables with half-opened drawers.</p></section>

This chamber serves as the primary examination room whenever the Cindarics need to conduct an autopsy to determine the cause of someone's death (or other extreme ailment).

<section class="block exploration"><h4>Exploring the Examination Room</h4><p>The examination room is fully supplied with various tools of the trade, which can be readily spotted by the characters as they survey the area. These include:</p><ul><li><p>Surgical equipment used for posthumous examination and embalming processes.</p></li><li><p>Dozens of jars, urns, and casks that contain a variety of specimens preserved in aldehydes and alcohols.</p></li><li><p>An assortment of journals and notes from previous examinations and autopsies.</p></li></ul><p>Any character who makes a successful  check while searching the room is also able to locate:</p><ul><li><p>The components of 2 Healer's Kits.</p></li><li><p>2 flasks of Holy Water.</p></li><li><p>1 flask of Alchemist's Fire.</p></li></ul><ul class="complex-check"><li class="critical-success"><p>: A Spell Scroll of Detect Poison and Disease can be found among the various scrolls and documents here. Alternately, this scroll can be instantly located by a character using the Detect Magic spell.</p></li></ul></section>

### 

The examination room is the main area where the  Event of the Smoldering Cinders Side Quest occurs. Refer to the Event text for more details.