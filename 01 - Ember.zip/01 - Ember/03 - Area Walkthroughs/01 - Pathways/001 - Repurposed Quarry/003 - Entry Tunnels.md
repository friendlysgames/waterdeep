# Entry Tunnels

<section class="block readaloud"><p>In the gloom, you can see the roughly dug out walls of this tunnel, streaks of bioluminescent moss growing here and there, casting the narrow passage in an eerie light. A rusting metal bridge crosses over swiftly flowing water. A haze of swirling spores fill the tunnel, pouring from the caps of numerous large mushrooms growing on the walls.</p></section>

<section class="block exploration"><h4>Strange Growths</h4><p>Examining the mushrooms with a successful <sup class="system-swap-inline"><sub data-system="dnd5e"></sub> <sub data-system="crucible"></sub></sup> yields insight into the bright yellow ones: glowing, brightly colored, and likely highly poisonous as a result. Their production of spores is prodigious, and the sole cause of the tunnel being choked with the haze.</p><p>A successful <sup class="system-swap-inline"><sub data-system="dnd5e"></sub> <sub data-system="crucible"></sub></sup> knows that some sort of face cover will protect you from the spores, though it'll be impossible to avoid spores coating your equipment. The party will want to keep an eye out for growths in your pack after being here.</p></section>

<section class="block hazard"><h4>No Fun Fungi</h4><p><sup class="system-swap-inline"><sub data-system="dnd5e">Characters passing through the haze of spores need to succeed on a  constitution saving throw or suffer the &amp;reference[poisoned] condition for 10 minutes.</sub> <sub data-system="crucible">Characters passing through the haze of spores suffer {Airborne Contaminanats} for each turn they spend in the fog.</sub></sup></p><p>Any sort of face cover that prevents inhaling the spores allows characters to navigate the area without having the make a saving throw.</p></section>

### Exiting the Tunnel

<section class="block readaloud"><p>Emerging from the tunnel, the space opens up quickly to reveal a cavernous quarry with structures and catwalks running between them, all suspended over a pit flooded by running water. The cliff-side path continues on north, and the entrance to a wooden structure sits nearby to the east.</p><p>The gaps of the quarry are spanned by suspended catwalks made of rusting metal, the mechanisms to move them obscured by the darkness above. From here you see no obvious controls, but there must be a way to move them.</p></section>

### Lab Explosion

<section class="block readaloud"><p>As you take in the quarry lab you spot movement on the other end of the quarry. A figure stands before the entrance to a building, reaches into a pouch on their belt, and throws the object into the structure. A moment later there is a sudden flash of light and a resounding boom which rattles the entire cavern.</p><p>Flames and smoke begin erupting out of the windows, while a stream of some bright purple fluid spills down through the floor of the suspended structure, bubbling and smoking on the stone a level below.</p></section>

The figure is a Mutagist Bombardier and they appear in front of the Destroyed Lab after having just destroyed it.

<section class="block readaloud"><p>Now outlined by the blazing fire issuing from the destroyed lab, the figure turns and begins running across a catwalk, heading your way. As they go, you see them pull another vial off their bandolier and shake it, causing it to glow violently in their hands.</p></section>

The Bombardier begins moving for the Chemical Storage room to blow it up next. The party can attempt to intercept them, potentially saving the room.

However, if the party is too slow, the space will be destroyed as well.