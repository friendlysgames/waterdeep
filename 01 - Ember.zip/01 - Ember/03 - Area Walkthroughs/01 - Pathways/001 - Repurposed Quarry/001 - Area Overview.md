# Area Overview

<section class="block gamemaster"><h4>Area Map Context</h4><p>The area map for the  depicts the entirety of the quarry lab location when it is discovered during the Ancient Paths quest event.</p></section>

## Gazetteer Entry