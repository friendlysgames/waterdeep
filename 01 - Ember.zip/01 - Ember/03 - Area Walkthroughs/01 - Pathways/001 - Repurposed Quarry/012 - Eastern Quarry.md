# Eastern Quarry

<section class="block readaloud"><p>The east quarry is a chaotic mixture of abandoned work and untended equipment. Among layers of dust and rubble lie rock slabs and long neglected and rusting tools used to make them. The only object which looks remotely new is a wooden crane standing silently nearby.</p></section>

<section class="block exploration"><h4>Going Down</h4><p>The crane can be used to lower one or more creatures to the flooded pit below, or raise them up. Doing so requires at least one character to work the crane from this level, however.</p><h4>Old Tools</h4><p>Aside from being a good source of rust and splinters, the old tools are so corroded and worn that they wouldn't even be worth keeping to sell as scrap.</p></section>