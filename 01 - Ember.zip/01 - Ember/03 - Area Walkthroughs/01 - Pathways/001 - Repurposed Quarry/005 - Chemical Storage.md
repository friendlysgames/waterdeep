# Chemical Storage

### Storage Destroyed

If the party doesn't get to the lab in time, the mutagist bombardier will blow it up, destroying everything inside and turning the room into a hazardous space.

<section class="block readaloud"><p>Shattered lab glassware litters the floor, with spilled fluids staining the wood flooring in various hues and emitting noxious vapors. Destroyed shelves lean precariously, some barely standing, others dripping with chemicals left to freely mix amidst the shattered glass vessels.</p><p>The air is dense, filled with a murky, caustic gas that assaults the eyes and nose immediately, and sets lungs afire with even the faintest breath.</p></section>

### Navigating The Fumes

<section class="block hazard"><h4>Caustic Clouds</h4><div class="system-swap-block"><div data-system="dnd5e"><p>Characters passing through the damaged storage areas are &amp;reference[blinded] and if they breathe, will begin choking, inflicting the &amp;reference[suffocating] condition.</p><p>They must succeed on a  saving throw or suffer  damage. Failing the save by 5 or more causes the blinded and choking conditions to persist for one minute after leaving the space.</p></div><div data-system="crucible"><p>Characters passing through the damaged storage areas are  and if they breathe, will begin choking, suffering {Noxious Fumes} for each round they remain in the gas.</p></div></div><p>Characters with Protective Goggles avoid the blinded condition while in the fumes, while characters wearing a Protective Mask don't suffer the blinded or choking conditions caused by the gasses.</p></section>

### Storage Intact

If the party is able to intercept the bomber and stop them from destroying the chemical area, they will be able to explore it and find useful information.

<section class="block readaloud"><p>Lab glassware lines the walls, resting on wooden shelves covered in labels and tags. Tables bear flasks and jars of fluids and powders of all colors, and the air makes your eyes burn lightly from the barely contained fumes.</p></section>

### Investigating The Shelves

<section class="block hazard"><h4>Volatile Chemicals</h4><p>This storage area is highly reactive and can easily be destroyed if the party is not careful. Actions that break, scatter, or spill the chemicals causes the lab to explode. This includes use of bombs, grenades, fireballs, and similar concussive spells or weapons.</p><p>If the storage room is set off, all creatures inside take  damage and the room's description and start match the above <strong>Storage Destroyed</strong> section.</p></section>

<section class="block exploration"><h4>Rare Stock</h4><p>Character with the  knowledge or making a successful <sup class="system-swap-inline"><sub data-system="dnd5e"> </sub><sub data-system="crucible"> using  </sub></sup>notes that the alchemical compounds here are highly volatile, reactive, and rare. It would take considerable connections and wealth to acquire some of these items.</p><p>Upon hearing this, Ankarist makes a List of Chemicals to be turned in as evidence. The party can also claim some of the Rare Chemicals stored here for use or evidence later.</p></section>