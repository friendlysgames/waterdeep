# Western Quarry

<section class="block readaloud"><p>The west end of the quarry is home to a massive rock slab and never a pair of unfinished tunnels that terminate pointlessly in the dark. Old, abandoned tools rot in the darkness here, the metal pitted and ruined by the moisture in the air. A few old wheel barrows rot quietly, their wood bloated and warped after years of neglect.</p></section>