# Brazier Nook

<section class="block readaloud"><p>This large alcove leads to a locked stone door. This door is unadorned and unremarkable — there do not appear to be any crystals upon the surface, nor does the door connect to the channel on the floor. The door is flanked on either side by two unlit metal braziers that appear well-polished despite their age.</p></section>

<section class="block exploration"><h4>Ceremonial Fires</h4><p>Any character with a  or who makes a successful  notices runes engraved on each of the braziers.</p><p>Once noted, any character who makes a successful  identifies the runes as associated with fire magic in ancient texts.</p><p>Meanwhile, any character who inspects the braziers and makes a successful  determines that they are receptacles that absorb and channel fire magic, likely opening the doors.</p><ul class="complex-check"><li class="advantage"><p>: The character gains  on this check.</p></li></ul><p>The party must light the two braziers at same time using any combination of tools or magic they possess, including lit torches or spells like  or .</p></section>

Once both braziers are lit, read or paraphrase the following:

<section class="block readaloud"><p>The runes on the braziers glow brightly and seem to burn with an inner fire, causing the door to click and unlock. With a burst of energy, the fire magic blasts from the braziers, but it does not burn; instead, a warm feeling of healing energy washes over you.</p></section>

<section class="block exploration"><h4>Blessing of the Fire</h4><p>Immediately after lighting both braziers, each character within 10 feet of either fixture gains Temporary Hit Points equal to the character's Proficiency Bonus, as the warmth of the flames invigorates them.</p></section>