# East Hallways

<section class="block gamemaster"><h4>Gamemaster's Note</h4><p>This hallway has two states — dark, as it is when characters first enter, and illuminated, which occurs after characters have filled the Light Channels in this section of the bastion.</p></section>

### The Dark Hallway

When the party enters the unilluminated hallway, read or paraphrase the following:

<section class="block readaloud"><p>The looming hallway in front of you is completely dark, and an overwhelming sense of scale and foreboding envelops you as you try to peer into the gloom. The corridor stretches far beyond the reach of your light source, at least thirty feet wide and towering fifty feet high, with a ceiling that appears to merge with the shadows above. The walls, crafted from massive stone blocks, are mostly pristine, but throughout the hallway, pieces of the wall have crumbled onto the floor.</p></section>

<section class="block exploration"><h4>A First Glance</h4><p>Any character who makes a successful  can tell that some of the darkness of the hallways is unnatural, requiring more than a conventional or simple magical light to illuminate.</p><ul class="complex-check"><li class="critical-success"><p>: The character also notices grooves in the floor that extend the length of the hallway. Some lines within it are cut more deeply, like veins, as if something once ran through them.</p></li></ul><p>Once this darkness is identified as unnatural, any character who makes a successful  check recognizes it as a form of Abyssal darkness.</p><ul class="complex-check"><li class="automatic-success"><p>: The character automatically succeeds on this check.</p></li></ul></section>

<section class="block exploration"><h4>Investigating the Hallway</h4><p>Any character who takes a moment to examine the hallway and makes a successful  or  check determines that the crumbled pieces of wall were damaged by some act of violence — they did not crumble naturally.</p><ul class="complex-check"><li class="critical-success"><p><strong>Character succeeds and completed</strong> : The character also notices that the damage is similar to the damage on the Shent pillar present in that Event.</p></li></ul><p>Any character who succeeds on a  check knows that the pristine nature of the walls outside of the damage is a sign of some sort of primordial magic power that is holding the place together despite the bastion's age.</p><ul class="complex-check"><li class="critical-success"><p><strong>Character succeeds and completed</strong> : The character also determines that this magic is similar to what they encountered on the  during that Event.</p></li></ul></section>

### The Illuminated Hallway

If the party reenters the hallway after illuminating its Light Channels, read or paraphrase the following:

<section class="block readaloud"><p>The channels of light beneath your feet stretch through the hallway like a lifeline, warm and humming beneath your feet. While you cannot see all the way into the depths of the structure, the hallway glows with more warmth than it did before, seeming to beckon you deeper into the bastion.</p></section>