# Stone Altar

<section class="block readaloud"><p>A huge, seemingly empty stone altar sits to one side of the otherwise-empty antechamber; the chamber's far exit is blocked by a thick stone door. The edges of the altar are embossed with glimmering ancient gold and exquisite patterns and carvings, but its purpose is unclear at first glance.</p></section>

Before the party can study the altar further, they are attacked by a Vhismara's Claw which springs down from the ceiling and ambushes the party.

<section class="block hazard"><h4><strong>The Upper Hand</strong></h4><p>The claw in this room has been hiding in effective stasis for untold years, clinging to the ceiling using its  feature.</p><p>Any character with a  or who makes a successful  check is able to detect the Vhismara's Claw at the last moment. If no character spots it, the party is &amp;Reference[surprise]{Surprised} at the start of combat.</p><h4><strong>Vhismara's Claw Tactics</strong></h4><p>At the start of combat, the Vhismara's Claw attempts to grapple the weakest or lightest looking character with its.</p><p>During combat, it attempts to pin and kill &amp;Reference[grappled] characters using .</p><p>The Vhismara's Claw is a creature of pure evil, and does not hesitate to fight to the death — if killed, its corpse lingers as .</p></section>

Characters who examine the altar see the following:

<section class="block readaloud"><p>The stone altar is a beautifully carved centerpiece of the room, yet nothing rests upon its surface. On its sides, giant figures are depicted in intricate detail, moving throughout the Pathways and worshipping under light rays which emanate from a central orb.</p></section>

<section class="block exploration"><h4>Examining the Altar</h4><p>Any character who makes a successful  determines that, while at first glance the orb and rays emanating from it seem as if they depict the Primordial Bastion, further consideration of orb suggests the artwork may depict somewhere else in the Pathways — perhaps even the  itself.</p><ul class="complex-check"><li class="advantage"><p>: The character gains  on this check.</p></li></ul></section>