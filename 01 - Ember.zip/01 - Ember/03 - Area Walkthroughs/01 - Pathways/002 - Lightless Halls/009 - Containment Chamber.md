# Containment Chamber

<section class="block hazard"><h4>Void Stasis</h4><p>Any character who falls into the void beneath the Lightless Halls is transported into this room and gains the &amp;Reference[Paralyzed] condition for 24 hours. This paralysis can be negated via use of the  or  Spells.</p></section>

The first time that a character is teleported to this room, read or paraphrase the following:

<section class="block readaloud"><p>Darkness. Stars. Fading light. Flailing arms. A sheen of cold across your skin like sweat, but dry and cool as ice. Sensation after sensation passes over your body, and when they end, you are here, in this empty stone room, unable to move.</p></section>

If characters look around further, or enter from the outside, they see a basic empty room:

<section class="block readaloud"><p>This small room seems unremarkable at first glance, empty and devoid of any detail except for the floor, which holds a beautiful carved stone circle of intricate markings that seem to catch the light as you glance at them.</p></section>

The symbols of the circle have been carved deeply into the floor and look as if they have been there for eons.

<section class="block exploration"><h4>The Inscribed Circle</h4><p>Any character who makes a successful  check identifies the markings as runes, likely used in a magical ritual of some kind.</p><ul class="complex-check"><li class="automatic-success"><p>: The character automatically succeeds on this check.</p></li></ul><p>If the character studied the stone bowls or altars within the bastion, they can tell that the script here is similar without a check, but cannot decode the runes.</p><p>Meanwhile, any character who makes a successful  check recognizes this as the end point of a teleportation circle, and knows that as an endpoint, it cannot be used to send anyone to a location.</p></section>

<section class="block exploration"><h4>The Way Out</h4><p>There is a stone lever on the inside of the door, which is clearly visible but otherwise unremarkable. Any checks to determine more about it reveal that it is a simple stone lever.</p><p>Pulling the lever opens the door to the Containment Chamber and gives any character inside access to the .</p></section>