# South Hallways

<section class="block gamemaster"><h4>Gamemaster's Note</h4><p>This hallway has two states — dark and illuminated. It becomes illuminated once all four Light Pillars in the Bastion Antechamber have been lit, thereby illuminating the Light Channel in this room.</p></section>

### The Dark Hallway

<section class="block exploration"><h4>A Light in the Dark</h4><p>If the party is currently employing a light source capable of overcoming Abyssal Darkness, they will be able to see to the end of the hallway, though will still not benefit from the activation of the Light Bridge as described in The Illuminated Hallway below.</p></section>

If the party enters the hallway before illuminating its Light Channel, read or paraphrase the following:

<section class="block readaloud"><p>The dark corridor stretches beyond the reach of any mundane light source, winding between massive stone block walls that show signs of ancient damage.</p></section>

If characters have not activated the Light Bridges in the hallway, they will quickly discover a dead end as the corridor floor stops abruptly ahead of them.

<section class="block readaloud"><p>Ahead of you, the corridor comes to an abrupt halt, revealing only a large empty void ahead.</p></section>

<section class="block exploration"><h4>Bridging the Gap</h4><p>To bridge the gap in the corridor, characters must illuminate the South Hallway. Due to the ancient magic in this place, any attempt to go across the void by other methods — including flying — unavoidably fails, plunging the character into the void below. They emerge in the , and upon arrival, suffer the ill effects specified on that page.</p></section>

<section class="block hazard"><h4>Spotting the Eel</h4><p>If the party carries a light source capable of overcoming Abyssal Darkness, they may potentially spot and trigger The Abyssal Eel encounter below.</p></section>

### The Illuminated Hallway

If the party enters the hallway after illuminating its Light Channel, read or paraphrase the following before proceeding:

<section class="block readaloud"><p>With light filling the channel in the floor, a soft glow fills the hallway, illuminating the imposing stone and a bridge of light over an endless void.</p></section>

## The Abyssal Eel

Once the hallway is effectively lit — regardless of the means — any party member has the opportunity to spot the  that lies in wait in the corner of this dark passageway, still as stone and half-merged with the wall.

<section class="block exploration"><h4>A Dark Rock</h4><p>Any character with a  or who makes a successful  spots a strange, dark rock in the very corner of this hallway, tucked away and barely noticeable.</p><p>Any character who attempts to investigate the rock and makes a successful  or a  determines that it is an inert monster called an Abyssal Eel.</p><ul class="complex-check"><li class="advantage"><p>: The character gains  on this check.</p></li></ul></section>

<section class="block hazard"><h4><strong>Biting the Hand</strong></h4><p>If anyone in the party touches the inert Abyssal Eel, it immediately activates and bites down on the hand or finger of whoever touched it, dealing  damage, then attacks the party outright.</p></section>

Once activated, the solitary Abyssal Eel assaults the party as best it can.

<section class="block hazard"><h4><strong>Lone Guardian</strong></h4><p>Alone and extremely weak, the Abyssal Eel is unlikely to present a significant danger to the party, but serves as a reminder of the constant hostility of this corrupted place.</p><h4><strong>Abyssal Eel Tactics</strong></h4><p>During combat, the Abyssal Eel will attempt to  whoever is closest to it.</p><p>The Abyssal Eel fights to the death, and leaves behind  if killed.</p><h4>Void Space</h4><p>If any party member falls or is pushed off the sides of the platforms, they hurtle down into the glittering void of light beneath the Light Bridge, before reappearing in the . Upon arrival, they suffer the ill effects specified on that page.</p></section>