# Area Overview

<section class="block gamemaster"><h4>Area Map Context</h4><p>The Lightless Halls Area Map depicts a particular section of the , and is featured in  during .</p><ul><li><p>To reach the final boss encounter in the , the party must first activate and open the central door in the .</p></li><li><p>The Bastion Antechamber door can only be opened by filling all Light Bowls in the antechamber with light from theSun Star. The Sun Star itself must be retrieved by solving a puzzle in the  room.</p></li><li><p>The party may optionally explore further to access the .</p></li><li><p>The party arrives to the Lightless Halls at the , after having traveled through less notable ruins and chambers of the ancient bastion.</p></li></ul></section>

## Levels & Elevation

The Lightless Halls Scene features a single Level, and its areas are organized into an East Wing, Center, and West Wing, all of which exist at the same elevation.

Ceilings in the Lightless Halls are 50 feet high unless otherwise stated.

<section class="block hazard"><h4>Into the Void</h4><p>There are several areas where the floor opens into a void below. There is no specific depth of this void as the expanse below is magical and fathomless in nature. Characters who fall into this void are transported to the  and suffer the effects of Void Stasis described on that page.</p></section>

## Illumination

A powerful Abyssal Darkness has taken over this section of the Primordial Bastion, shrouding large portions of it in magical darkness. A Sun Star can be recovered from the Runekey Altar and carried by one of the characters to create a mobile light capable of countering the Abyssal Darkness. Areas which are affected by neither Abyssal Darkness nor a Sun Star are treated as mundane darkness.

<section class="block hazard"><h4>Abyssal Darkness</h4><p>Any character who remains in Abyssal Darkness for longer than 6 seconds, or begins their turn in Abyssal Darkness when in initiative order, must make a  saving throw or suffer  damage.</p><p>Within Abyssal Darkness, mundane light sources are nullified and visibility is entirely negated unless the darkness is counteracted by a Sun Star.</p><p>The Abyssal Darkness can be temporarily countered via use of the Daylight spell, but this spell is not powerful enough to dispel the effect darkness permanently.</p></section>

<section class="block wip"><h4>Work In Progress</h4><p>The current implementation of Abyssal Darkness is not entirely complete, but is partly functional. Non-magical light sources in this area do not function, and characters do not benefit from vision modes like Darkvision.</p><p>Only magical light sources which are configured with <strong>Priority</strong> of <strong>1 or higher</strong> will supersede the ambient darkness which is present throughout this area.</p></section>

The Sun Star can be used at certain fixed positions within the Lightless Halls to fill empty Light Bowls. Once active, Light Bowls, and anything they flow through, including Light Channels across the floor of the halls and light sconces on the walls, which create Bright light in a 5 foot radius and Dim Light in an additional 10 foot radius.

## Terrain

The hallways of the Lightless Halls are treated as normal terrain unless otherwise specified.

## Enemies

The following enemies are encountered here:

- 
3 Vhismara's Claws

- 
8 Abyssal Eyes

- 
1 Abyssal Eel

- 
1 Gohema's Head

- 
1 Gohema's Tail

- 
3 Gohema's Tendril

- 
3 Gohema's Eye