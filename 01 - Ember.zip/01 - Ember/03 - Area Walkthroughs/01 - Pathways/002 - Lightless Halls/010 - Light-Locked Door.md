# Light-Locked Door

<section class="block readaloud"><p>A formidable door stands at the end of the ancient hallway. Towering above you and wrought from two massive slabs of stone, nigh-impossible strength would be required to open it manually.</p></section>

<section class="block exploration"><h4>Examining the Door</h4><p>Anyone who makes a successful  check determines that the firmly locked and unbelievably heavy door cannot be opened by brute force alone.</p><p>Meanwhile, anyone who makes a successful  check senses a faint magical aura from an unknown magical school emanating from the crystals on the door. The magic from these crystals also seems to connect to the channels along the floor.</p><ul class="complex-check"><li class="advantage"><p>: The character gains  on this check.</p></li></ul></section>

<section class="block gamemaster"><h4>Light Lock</h4><p>The door here will unlock once the Light Bowls and connected Light Channels from Stone Bowl and Void Bridge are activated.</p></section>