# Stone Bowl

<section class="block readaloud"><p>An unlit stone bowl rests on a polished pedestal, its surface etched with intricate, faded patterns. A narrow channel, carved into the stone floor, snakes away into the shadows, and its path can be followed easily by following the lighter stone trim.</p></section>

<section class="block exploration"><h4>Empty Light Bowl</h4><p>Within this room is an , which can be investigated and lit by the party using the rules laid out on that page.</p></section>