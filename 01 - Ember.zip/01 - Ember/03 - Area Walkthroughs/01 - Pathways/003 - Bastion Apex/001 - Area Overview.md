# Area Overview

<section class="block gamemaster"><h4>Area Map Context</h4><p>The area map for the Bastion Apex depicts a section of the Primordial Bastion. The party would arrive in this ultimate area of the bastion after navigating its prior area, the Lightless Halls.</p></section>

## Gazetteer Entry