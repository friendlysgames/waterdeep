# Lower Platforms

<section class="block readaloud"><p>The immense stone stairs of the obelisk-like tower zigzag internally until, just before the apex, they ascend into the open air, revealing the dim, gloomy expanse of the Fogbound Caverns below.</p></section>

## Stairways of Stone

As the party enters the scene, they appear on the lower platforms, out of sight of the higher Apex area and its guardian , who stands watch under the Orb of Lantyr. If the party wishes, they may wait, observe, and study their surroundings for a time before moving forward.

<section class="block readaloud"><p>The shadows cast by the Orb of Lantyr above the Apex allow you to ascend the stairs ahead while remaining concealed from the immense figure that stands resolute beneath the orb.</p></section>

<section class="block exploration"><h4>Observing from the Shadows</h4><p>If the party wishes to remain hidden from Luxaroth, all characters must make a successful  check. </p><p>If all characters succeed and the party takes time to observe their surroundings, they notice:</p><ul><li><p>In any other environment, the Apex would be windswept and cold, but inside the Pathways, despite its height, the tower here is oddly still and silent without wind. Looking down over the short stone wall surrounding the stairs, the omnipresent fog is thick and motionless; the ground and the rest of the bastion are barely visible.</p></li><li><p>There does not appear to be anything living on top of the bastion — no plants or animals whatsoever.</p></li><li><p>The massive orb of light floating above the tower is radiant and nearly blinding. However, its light emissions are not as consistent as it appeared from a distance — tiny flickers in its output are clearly visible.</p></li></ul><p>Any character who makes a successful  intuitively understands that the magic used to create the Orb of Lantyr is fading. While it may have once been a mighty and much more powerful artifact, most of the warding, spellcraft, and magic surrounding it has been weathered by immense age.</p><ul class="complex-check"><li class="automatic-success"><p>: The character automatically succeeds on this check.</p></li></ul></section>

## Rushing Host

Once the party finishes investigating their surrounding (or if they declined to remain hidden) read or paraphrase the following:

<section class="block readaloud"><p>Behind you, the silence is broken by the rushing sound of cold wind. Although no air actually moves, a deep chill settles upon your body as if something is engulfing the area. Deep within the tower that you just climbed emanates the horrific sounds of claws rending deep into the stonework and dozens — if not hundreds — of monsters, as the chittering, snarling, and barking mix with the sounds of rushing movement. As the noise continues to grow, you realize that a host of creatures is moving upwards towards the apex of the tower upon which you now stand.</p></section>

<section class="block hazard"><h4>Fleeing &amp; Falling</h4><p>At this point, the party cannot descend the tower safely unless they wish to jump off the top of the Apex — a route that is possible, but inadvisable. Characters who jump and plummet through the thick fog in order to descend the full height of the 200 foot tower take  damage upon contact with the ground.<br><br>Characters using magical means of descent such as  or  must still make a  as they fall, in order to dodge obscured segments of the tower that protrude into the fog, then land safely on uneven ground. On a failure, they suffer   damage.</p></section>

<section class="block gamemaster"><h4>"To Fall and Fall Again" Quest Progression: Abandoning the Fight</h4><p>If the party leaves Luxaroth to face the oncoming monsters alone, both Luxaroth and the Orb of Lantyr itself succumb to the onslaught, leaving the orb broken atop the tower. Refer back to  in To Fall and Fall Again for further consequences of this outcome.</p></section>

At this point, the party will likely conclude that returning the way they came is no longer possible. However, before finishing their ascent, they may be able to glean additional information about what approaches from below, or even attempt to descend the stairs.

<section class="block exploration"><h4>Snarling in the Deep</h4><p>Any character with a  or who makes a successful  check notices a similarity between the sounds from within the tower and those of the monsters the party encountered in the Lightless Halls. These are the sounds of Vhismara's Claws scrabbling against stone,Abyssal Eyes pushing against one another in a great host, and further horrific noises still unrecognizable, all ascending the stairs quickly in an inevitable assault.</p><ul class="complex-check"><li class="automatic-success"><p>: The character automatically succeeds on this check.</p></li></ul></section>

If anyone from the party attempt to move down the stairs — whether to flee or confront the monsters — read the following:

<section class="block readaloud"><p>As you attempt to step foot upon the stairs, a wall of darkness slams into your body, preventing your descent and causing you to recoil in pain. </p></section>

<section class="block hazard"><h4>Wall of Darkness</h4><p>Any character that attempts to move down the stairs must make a successful  or else suffer  damage. Regardless of the outcome, they are unable to push through the wall, and cannot descend the stairs.</p></section>