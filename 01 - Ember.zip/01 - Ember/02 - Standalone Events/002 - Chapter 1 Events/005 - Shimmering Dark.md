# Shimmering Dark

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This <strong>Exploration</strong> event allows the party to encounter the mind-altering magical effects prevalent in the Kaleidoscope Caverns. In this event the party can:</p><ul><li><p>Discover a treacherous new biome, the Kaleidoscope Caverns.</p></li><li><p>Collect unique crystals that form here which could be interesting, useful, or dangerous.</p></li></ul></section>

### Cavern Exploration

The crystals of the kaleidoscope cavern are mesmerizing, but spending too long in their presence can have a mind-altering effect on those who travel nearby. As the cavern's magical effects take hold, read or paraphrase the following:

<section class="block readaloud"><p>Each time you blink or turn your head, the light from within the violet crystals seems to shift, creating a hypnotic effect that makes it difficult to concentrate on anything else. As your vision focuses in on the shimmering swirl of light you feel increasingly woozy as countless dots of light infiltrate your field of view and can't be shaken off.</p></section>

<section class="block hazard"><h4>Crystal Calamity</h4><p>Characters encountering this event will find the crystal caverns have begun to influence their perceptions. Characters with  immediately suspect that the crystals formed in this place are not entirely natural.</p><div class="system-swap-block"><div data-system="dnd5e"><p>Any character who can see the light emitted by a cluster of kaleidoscope crystals must succeed on a  saving throw. On success, the character suffers no ill effects aside from minor disorientation. On failure, a character benefits from scrambled senses, suffering disadvantage on perception checks until they finish a long rest. In addition, they also suffer one of the following effects which persist until the successful completion of a long rest.</p></div><div data-system="crucible"><p>Any character who can see the light emitted by a cluster of kaleidoscope crystals must face {Kaleidoscopic Disorientation}. If this hazard is not resisted, the character additionally suffers from one of the following effects which persist until the successful completion of a Rest.</p></div></div><p></p><p>After facing this test, the characters are immune to the effects of the kaleidoscope crystals for 24 hours.</p></section>

<section class="block exploration"><h4>Taking a Kaleidoscope Crystal</h4><p>If characters want to take a Kaleidoscope Crystal, they must break it off of the cavern wall or floor. Liberating a crystal from where it is embedded in the cavern wall requires <sup class="system-swap-inline"><sub data-system="dnd5e">either a successful  check while using a suitable tool (pickaxe, hammer, etc.) or a successful  check</sub><sub data-system="crucible">a successful  check</sub></sup> to extract it from the cave wall.</p><p>Attempting this check and failing causes the crystal to shatter, generating an immediate release of magical energy that immediately inflicts a Kaleidoscope Crystal Effect to anyone who is not already immune to the effects.</p></section>

## Overview

As characters enter the mysterious Kaleidoscope caverns, they find themselves drawn to the shifting prismatic light cast by its reflective crystals, which is strengthened by any light they bring into the caverns. The glittering light intrigues, but hides a danger - those who spend too long in the presence of the arcane crystals may fall prey to one of their mind-altering effects.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>As you step into the cave, the swirling pattern created by crystalline reflections changes and the air moves slightly as if somehow whispering a secret. Flickers and flashes of light dance through the cavern like ripples in water. Some of these flashes rush overhead, or circle you briefly before dying out, but each time they pass by you're left feeling slightly light-headed.</p>
</section>

## Summary

We encountered the mysterious and captivating reflective crystals of the Kaleidoscope Caverns.