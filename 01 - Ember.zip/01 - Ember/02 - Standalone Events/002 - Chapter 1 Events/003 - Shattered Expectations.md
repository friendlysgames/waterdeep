# Shattered Expectations

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This standalone event set in the Kaleidoscope Caverns can occur if the party is moving at a fast or reckless pace, and presents the characters with an immediate set of skill challenges that will determine whether or not they become hurt and/or lost. In this event, the party can:</p><ul><li><p>Attempt to avoid the piercing damage wrought by the shattered crash of a massive chunk of Kaleidoscope Crystal, previously suspended like a stalactite from the roof of the cave.</p></li><li><p>Try to stave off the psychic maladies associated with such close proximity to the volatile impact.</p></li><li><p>Determine if they've been thrown off-course by this untimely encounter, and precisely how much.</p></li></ul></section>

As soon as you finish the readaloud, the characters are in mortal danger from the torrent of crystal shards hurled outward by the stalactite's impact, and must react accordingly.

<section class="block hazard"><h4>The Crystal Stalactite</h4><p>The party must immediately react to avoid being hit by the shards of arcane mineral that are flung far and wide by the shattered crystal stalactite. Each character must <sup class="system-swap-inline"><sub data-system="dnd5e">succeed on a  saving throw or suffer  damage</sub> <sub data-system="crucible">avoid {Exploding Shards}</sub></sup> as the crystal shards rip their skin and gouge their flesh.</p><p>Characters who sustain damage from this hazard are affected by the chaotic resonance of the crystals and must also <sup class="system-swap-inline"><sub data-system="dnd5e">succeed on a  saving throw </sub><sub data-system="crucible">withstand the {Psychic Resonance} caused by the crystal shards</sub></sup> or roll once each on the Kaleidoscope Crystal Effects table.</p></section>

Following the stalactite's seismic impact, the party members can take a moment to observe their surroundings. However, the characters must also assess whether or not the event has thrown them off course.

<section class="block exploration"><h4>Surveying the Scene</h4><p>After the stalactite's impact, any character who succeeds on a <sup class="system-swap-inline"><sub data-system="dnd5e"></sub> <sub data-system="crucible"></sub></sup> check while searching the nearby area is able to locate  Kaleidoscope Crystals worth looting among the shattered detritus.</p></section>

Following the crystal stalactite's untimely impact, the characters must determine whether or not it has directly impeded the route of their journey.

<section class="block hazard"><h4>Bewildered Reorientation</h4><p>The party must nominate one member to be their decision-making guide, that character must succeed on a <sup class="system-swap-inline"><sub data-system="dnd5e"></sub> <sub data-system="crucible"></sub></sup> check to prevent the party from becoming disoriented in the aftermath of this event. Characters with  gain  on this check.</p><p>The degree of failure on this check determines precisely how far the party is thrown off-course by the incident:</p><ul><li><p><strong>Failure</strong>: The party loses 2 full hours recovering their bearings, during which the characters must carefully navigate a crevasse that has opened up where the crystal stalactite hit the ground. Advance the world clock by the appropriate number of hours.</p></li><li><p><sup class="system-swap-inline"><sub data-system="dnd5e"><strong>Result of 13 or below</strong></sub> <sub data-system="crucible"><strong>Critical Failure</strong></sub></sup>: The party loses 4 full hours recovering their bearings and the party is forcibly relocated to a hex adjacent to this one. Manually move the party token in the approximately opposite direction of their intended direction of travel.</p></li></ul></section>

## Overview

While traversing the Kaleidoscope Caverns, the characters hastily stumble upon a peculiar cave where the sound of their movements is prodigiously amplified by the acoustic shapes and preternatural essence of the arcane, crystal-laden hollow. Due to the party's negligence, they must react quickly to avoid the hazards wrought by this untimely encounter, which can both trouble their minds and set them off-course if they're not careful or skilled enough to avoid the dangers.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>Gathering your bearings, you realize you've stumbled into a cave with a rather peculiar shape - one that seems to prodigiously amplify sound, including the noise of your very footsteps. Before you know what's happening, a massive stalactite made from the kaleidoscopic crystal that makes these caverns famous comes crashing down from the ceiling right in front of you.</p><p>The enormous slab of jagged, lucent mineral hits the ground of the cave with a ferocious impact, sending sizable fragments of nacreous crystal flying this way and that. You'll have to act fast if you wish to avoid the immediate threat of evisceration from these errant kaleidoscopic shards.</p>
</section>

## Summary

We encountered a strange cave within the Kaleidoscope Caverns, where our hasty pace of travel subjected us to hazards we might otherwise have avoided altogether - including a fallen stalactite of kaleidoscopic crystal that shattered upon impact, hurling fragments here and there while unleashing a wave of mind-altering arcane energy.