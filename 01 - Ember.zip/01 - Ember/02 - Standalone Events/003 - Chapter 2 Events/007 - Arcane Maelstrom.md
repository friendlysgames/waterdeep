# Arcane Maelstrom

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This standalone event takes place while the party travels at a Reckless pace through the Golden Flats, where sudden supernatural upheaval is often a way of life. In this standalone event, the characters can:</p><ul><li><p>React to the sudden arrival of an arcane maelstrom, which threatens to rob the party's spellcasters of their spell slots and magic items of their charges.</p></li><li><p>Survive the chaos of the maelstrom's magical energy field.</p></li></ul><p>This event takes place on  Region Map, and its probability is dependent upon the party's regional travel speed.</p></section>

While traversing the Golden Flats with some rapidity, the party encounters a hazardous arcane maelstrom: a chaotic, weather-like phenomenon that channels one (if not several) of Ember's Magical Forces into a localized storm, infused with the raw magic of the Cosmos.

This supernatural vortex is not only physically dangerous, it acts as a mystical siphon, drawing magic energy from whatever sources lurk nearby (including the spell slots of spellcasting characters, and the charges inherent to magic items). If the party acts quickly enough, they can avoid the maelstrom and its tumultuous woes.

Roll on the Golden Flats Arcane Maelstrom table to determine precisely which type of arcane maelstrom the party must contend with.

In addition to the rolled result, each Arcane Maelstrom has the following properties

<section class="block hazard"><h4>Arcane Siphon</h4><ul><li><p>Any spellcasting character caught in the maelstrom loses  spell slots, starting with and descending from their highest level spell slot.</p></li><li><p>Any magic item caught in the maelstrom loses  charges if it is an item with charges. Otherwise, the magical effects of the item are dispelled for  hours.</p></li></ul></section>

Information on how characters can spot and avoid the maelstrom is detailed below.

### Navigating the Hazard

<section class="block hazard"><h4>Avoiding the Maelstrom</h4><p>Each character that has a , or who succeeds on a  check, is able to detect the arcane maelstrom early enough to make an active attempt to navigate it safely, granting them  on any ability checks or saving throws made to survive or avoid the hazard.</p><ul><li><p>Characters with  have .</p></li></ul></section>

<section class="block exploration"><h4>Observing the Maelstrom</h4><p>People of Ember, and the Arctus Plateau in particular, have come to understand arcane maelstroms as an intermittent way of life. While these supernatural hazards aren't omnipresent phenomena, it's rare for a native Arcturian or Ordani to be altogether unfamiliar with them.</p><p>Any character who succeeds on either a  or  check is aware of the potential dangers of arcane maelstroms, and understands that these unavoidable tempests are known to appear haphazardly throughout the region, with little rhyme or reason to their arrival.</p><ul><li><p>Characters with  automatically succeed on this check.</p></li><li><p>Characters with  have .</p></li><li><p><strong>Result of 17+</strong>: The character is aware of an arcane maelstrom's ability to strip spellcasters and magic items of their potential (including the respective loss of spell slots and charges).</p></li></ul><p>Any character who succeeds on a  check is able to identify some of the maelstrom's abstruse magical properties, and has a bonus round to brace against its uncanny impact.</p><ul><li><p>Characters with  or  have .</p></li><li><p><strong>Result of 20+</strong>: If the character is a spellcaster, they only lose half of their lost spell slots as detailed in "Properties of the Maelstrom" above.</p></li></ul><h4>Surviving the Maelstrom</h4><p>Each character that has a , or who succeeds on a  check, is able to detect the arcane maelstrom early enough to make an active attempt to navigate it safely, granting them  on any ability checks or saving throws made to survive or avoid the hazard.</p><ul><li><p>Characters with  have .</p></li></ul><p>While the arcane maelstrom cannot be avoided altogether (enveloping the party in mere moments) characters can mitigate its disastrous effects using skill checks, equipment, and other methods.</p><ul><li><p>Any character who casts either the Counterspell or Dispel Magic spell with the maelstrom as a target is able to help a number of characters equal to their Charisma modifier automatically succeed on any saving throws associated with the maelstrom's features (minimum of 1 character; including, but not limited to, the spellcaster).</p></li><li><p>Items such as a <span style="text-decoration:underline"><span style="text-decoration:underline">Dampening Stone</span></span> provide  on saving throws associated with arcane maelstroms, and reduce the damage done to the attuned character by a total of  per charge spent to do so.</p></li><li><p>Skill checks related to a particular type of maelstrom are listed in the rollable table with the maelstrom's description.</p></li></ul></section>

### Concluding the Event

Once the party has finished navigating the area where the arcane maelstrom appeared, the characters are free to continue on their journey.

## Overview

The party happens upon a hazardous arcane maelstrom while recklessly traversing the Golden Flats, and must contend with their dangerous proximity to this calamitous event, lest they succumb to its chaotic metaphysical wrath.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>As you make your way through the sweeping landscape of the Golden Flats, a commotion begins to stir around you. The ground beneath your feat starts to rumble with a heavy vibration not unlike the trembling of an earthquake, and the terrain begins to fragment like shattered glass — creating a lattice of cracked earth all about you.</p><p>Before you know it, the ground starts to swirl around a funnel at the midpoint of this emerging calamity, which appears to be some kind of arcane maelstrom. A small storm of supernatural energy encompasses this malevolent vortex, which threatens to swallow you into its spiraling center!</p>
</section>

## Summary

We encountered a hazardous arcane maelstrom while traveling the Golden Flats — a dangerous vortex of chaotic magic and wild supernatural effusion.