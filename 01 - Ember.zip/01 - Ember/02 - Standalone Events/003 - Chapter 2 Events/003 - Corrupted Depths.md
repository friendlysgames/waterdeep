# Corrupted Depths

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This combat event can occur while traversing the Lake of Whispers in the Fogbound Caverns section of the Pathways. In this event the party can either:</p><ul><li><p>Hunt some of the strange Corrupted Kezus Jelly's as the swarm the party</p></li><li><p>Move on quickly after recognizing that the jellies are not interested in the party.</p></li></ul><p>This event is repeatable, but on a cooldown so it cannot happen for several days after it has been encountered.</p></section>

The event begins with the party floating across the Lake of Whispers upon the water vehicle they possess as they move through the Fogbound Caverns.

The jellies are not immediately hostile, so the party can choose whether to take the first move or simply investigate.

<section class="block exploration"><h4>Light in the Depths</h4><p>The party can decide that the jellies pose no danger to them, and they can move on without engaging in combat. This can end the encounter quickly.<br><br>A  or successful  or  check will notice that the jellies are ignoring the party and floating through the water without any apparent purpose. They react to the passing of the water vehicle but are not aggressive or hostile.</p><ol><li><p><strong>Result of 16+.</strong> By studying the jellies closely, you realize that they are aware of the party but are not aggressive, leaving them alone will result may be the best course of action.</p></li><li><p><strong>Result of 17+.</strong> These jellies do not appear to be entirely natural creatures, or perhaps they may have been once, however, their colors and glowing markings seem to suggest some kind of Abyssal corruption.</p></li></ol><p>A successful  or check or  or  will notice that the jellies are rare creatures that if they were harvested for parts would produce Kezus Jelly which is highly valuable and even more so when refined intoKezus Ointment. The party can decide whether attacking the jellies here is worth the risk!</p></section>

<section class="block hazard"><h4>Kezus Jelly Tactics</h4><p>If the party attacks one of the jellies, combat begins. The jellies will turn red — indicating their aggression and anger — and attack as a group.</p><p>The encounter with the jellies is straightforward, as they all move toward the water vehicle that the party is floating on as a single entity. They target the party members or characters randomly but will switch their attacks to anyone in the water if they fall in.</p></section>

## Overview

While traversing the Lake of Whispers, a fog-shrouded section of the Pathways, the party encounters strange luminescent jellies rising from the fathomless depths.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>The lake is silent aside from the rhythmic creaking of your makeshift raft and the flutter of its canvas sailcloth. At the periphery of your vision, however, you notice tiny pinpricks of faint light in the water growing gradually brighter and larger in size.</p>
</section>

## Summary

We encountered strange glowing jelly-like creatures which dwell in the depths of an underground lake in the fog-shrouded Pathways.