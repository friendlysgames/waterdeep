# The Giants' Span

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This Exploration Event can occur while traveling recklessly through the Wedgelands. In this Event, the party can:</p><ul><li><p>Investigate a crumbling remnant of the Shent empire: an ancient shelf road, cut into the mountainside above a ravine.</p></li><li><p>Inspect the ruin for a safer path, attempt to cross it, or lose time by turning back and going around.</p></li></ul></section>

### Circumventing the Span

The characters may circumvent the giants' span by retreating into an adjacent hex in the opposite direction of their destination and moving around the hex in which this Event triggered. Make a note of where this Event triggered as the location of the giants' span; the characters face the same decision upon entering this hex in the future.

### Inspecting the Span

Before the party attempts to cross the giants' span, they may inspect its construction for a safer path.

<section class="block exploration"><h4>Inspecting the Span</h4><p>Any character who makes a successful  or  check while examining the giants' span identifies a prevailing architectural pattern evident in the stone: the wider outer shelf is badly degraded, but a staggered inner line of intact flagstones suggests a loadbearing path.</p><ul><li><p>Characters with , , or the Stonecunning feature have  on this roll.</p></li></ul><h4>Identify the Origin</h4><p>Characters with , , or Proficiency in  identify the shelf road as a deliberate feat of Shent engineering; they recognize the visage as a Shent giant, and can estimate its age and that of the shelf road as approximately 3,000 years old.</p><h4>Eye of Black Pearl</h4><p>Any character with a , or who makes a successful  check while examining the carved visage from afar, discovers that some kind of jewel gleams within one of its eye sockets. The gleaming jewel is a large black pearl worth .</p><p>To recover the black pearl, a character must:</p><ul><li><p>Reach the base of the visage (60 feet along the shelf road).</p></li><li><p>Climb 30 feet by making a successful  check — on a failure, roll on the Climbing Hazards table, and apply the result to the climbing character only (not the entire party).</p></li><li><p>Make a successful  check to dislodge it from its stone setting. If the character fails this check by 10 or more, the black pearl pops out, falls, skips off the shelf road, and vanishes into the ravine below.</p></li></ul></section>

<section class="block hazard"><h4>Falling</h4><p>A character that falls from the effects of a Climbing Hazard while attempting to retrieve the black pearl falls 30 feet onto the shelf road, taking ( damage) and landing &amp;reference[Prone]. This immediately triggers the Crumbling Shelf hazard for  randomly selected characters as described below.</p></section>

### Crossing the Span

<section class="block exploration"><h4>Crossing the Span</h4><p>The shelf road is 120-feet-long, 5-feet-wide, and lies 120 feet over the ravine below. At intervals of 30 feet, the party must make a  group check: if at least half of the characters succeed, they proceed without incident. If over half of the character fail, however,  randomly selected characters are subjected to the Crumbling Shelf hazard.</p><ul><li><p>Characters that identified the architectural pattern while inspecting the span have  on this check.</p></li></ul></section>

<section class="block hazard"><h4>Crumbling Shelf</h4><p><strong>Description: </strong>The shelf road suddenly crumbles under the character's feet, leaving them grasping at the side of the cliff face for support.</p><p><strong>Effect: </strong>The character must make a successful  save or take  damage from sharp rocks and suffer one level of &amp;Reference[exhaustion]. Any character that fails by 10 or more must also make a successful  check or fall 120 feet into the ravine below, taking ( damage) and landing &amp;reference[Prone]. Any character who succeeded on the initial save (or was not subjected to the hazard at all) may take the Help action to grant  to one character making this check.</p><p>If this hazard occurs three or more times, the entire shelf road crumbles into the ravine after  days, and the hex becomes impassible.</p></section>

<section class="block attunement ragen"><h4>Ragen Attunement: Across the Shelf Road</h4><p>If the party cross the shelf road, they advance their  at the conclusion of the event.</p></section>

### Climbing Hazards

### Concluding the Event

Once the party has crossed the giants' span or decided to circumnavigate it, they're free to continue on their journey.

## Overview

The party reaches an ancient shelf road carved into the mountainside by the mighty Shent. The old route is the most direct path forward, but it is visibly failing. The party must decide to brave the giants' span or circumvent it at the expense of time.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>What was once a broad shelf road has narrowed to a tapering ledge of cracked slate and weathered stone. Loose shale chips skip from the cliffside and vanish into the ravine below. Above, a massive visage looms carved into the mountainside; its features are worn smooth and split by age, but the eyes remain deep-set beneath a moss-covered brow, and seem to follow your every step. The way forward may be treacherous, but circumventing it would cost you time.</p>
</section>

## Summary

While traveling across the Wedgelands, we came upon a crumbling shelf road carved into the side of the mountain, looked over by an aged, formidable visage.