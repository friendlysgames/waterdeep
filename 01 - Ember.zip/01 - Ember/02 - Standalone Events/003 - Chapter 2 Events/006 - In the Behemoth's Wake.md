# In the Behemoth's Wake

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This repeatable Exploration Event can occur while traveling through the Golden Flats. In this Event, the party can:</p><ul><li><p>Discover a destroyed site recently laid waste by a Pathways behemoth.</p></li><li><p>Examine the ruined site, possibly uncovering clues about the strange subterranean creature responsible.</p></li><li><p>Recover a small trophy or other remnant of the creature if they successfully identify it.</p></li></ul><p>This Event can repeat, but will not reoccur for at least 24 hours after each incident.</p><h4>Randomization Procedure</h4><p>To run this Standalone Event, follow these steps:</p><ol><li><p>Determine what kind of site the characters discover in ruins by rolling on or choosing from the Golden Flats Ruins table.</p></li><li><p>Determine what kind of Pathways behemoth recently passed through the area by rolling on or choosing from the Pathways Behemoth Encounters table.</p></li><li><p>Use these results to describe a specific scene of destruction shaped by both the place itself and the creature responsible; have the characters Survey the Ruins.</p></li></ol></section>

<section class="block wip"><h4>Under Development - Early Access</h4><p>This event is currently in development and may be missing some important pieces of gameplay, such as actors for the beasts, crafting components, and other aspects that may make it difficult to play through.</p></section>

Determine what kind of site the characters discover in ruins by rolling on or choosing from the table below:

Determine what kind of Pathways behemoth recently passed through the area by rolling on or choosing from the table below:

The characters should not be told the behemoth's identity outright. Instead, they may infer it by examining the physical aftermath of the destruction and interpreting the creature's likely behavior. Refer to the sections below for gameplay details on the combination of ruin and behemoth that were selected.

### Ruined Farmstead

<section class="block readaloud"><p>The walls of this farmhouse have been split open, its roof sundered and strewn across the golden grasses. A partially devoured human corpse lies outside. Insects writhe on its surface.</p></section>

<section class="block exploration"><h4>Trapped Cat</h4><p>A frightened cat is stranded atop a tilted beam or broken roof section, hissing at anyone who gets too close.</p><p>Any character who makes a successful <sup class="system-swap-inline"><sub data-system="dnd5e"> </sub><sub data-system="crucible"></sub></sup> check convinces the cat to come down over the course of 10 minutes.</p><ul><li><p>Characters with  succeed on this check automatically.</p></li></ul></section>

### Collapsed Granary

<section class="block readaloud"><p>This timber-and-brick granary has been cleft in twain, one side burst open into a swell of loose grain and shattered wood. The partially devoured remains of a yarnac lie bloody on the ground.</p></section>

<section class="block exploration"><h4>Injured Beast</h4><p>A second Yarnac, still tethered to a post and grievously injured, lows weakly as the characters approach.</p><p>Any character who makes a successful <sup class="system-swap-inline"><sub data-system="dnd5e"> </sub><sub data-system="crucible"></sub></sup> check can stabilize the Yarnac over the course of 30 minutes.</p><ul><li><p>Characters with  gain <strong> </strong>on this check.</p></li></ul></section>

### Broken Aedir Watchtower

<section class="block readaloud"><p>The weathered remains of an old Aedir watchtower lie in fresh ruin, its frame reduced to a heap of fallen stone blocks.</p></section>

<section class="block exploration"><h4>Fallen Signal Bell</h4><p>Amid the rubble lies a weathered bronze signal bell, still fixed to part of its cracked mounting — and clutched in the hands of a crushed cadaver. It can be worked loose and recovered, though doing so without further collapse requires care.</p><p>Any character can attempt to retrieve the signal bell over the course of 10 minutes with a <sup class="system-swap-inline"><sub data-system="dnd5e"> </sub><sub data-system="crucible"></sub></sup> check. Characters with  gain  on this roll.</p><p>On a success, the character retrieves the signal bell, which is worth <sup class="system-swap-inline"><sub data-system="dnd5e">25 gp</sub> <sub data-system="crucible">3gp</sub></sup>. On a failure, the character still retrieves the signal bell, but the rubble pile collapses, <sup class="system-swap-inline"><sub data-system="dnd5e">causing  Bludgeoning damage and trapping the character</sub> <sub data-system="crucible">and the character suffers {Minor Crush Injuries}</sub></sup>. The character can be extricated over the course of 1 hour.</p></section>

### Shattered Irrigation Terrace

<section class="block readaloud"><p>This stretch of farmland has been violently torn asunder, its irrigation channels collapsed and the cultivated furrows churned to thick mud.</p></section>

<section class="block exploration"><h4>Slain Farmers</h4><p>Any character with <sup class="system-swap-inline"><sub data-system="dnd5e">a , or who makes a successful </sub> <sub data-system="crucible"></sub></sup> check while examining the terrace, discovers the bloated and mangled remains of several farmers buried in the mud. Nothing of value is on their person.</p></section>

### Surveying the Ruins

The party can inspect the ruins of the scene to learn about what happened here.

<section class="block exploration"><h4>Examine Physical Clues</h4><p>Any character with <sup class="system-swap-inline"><sub data-system="dnd5e">a , or that succeeds on a </sub> <sub data-system="crucible">a successful </sub></sup> check while examining the scene, gains some insight into the creature's Physical Clues as described in the relevant behemoth table entry. Use these clues in conjunction with the destroyed site result to describe the aftermath.</p><ul><li><p>Characters with , , or  have  on this roll.</p></li></ul><h4>Infer Behavioral Clues</h4><p>Any character with <sup class="system-swap-inline"><sub data-system="dnd5e">a , or that succeeds on a </sub> <sub data-system="crucible">a successful </sub></sup> check while examining the scene, gets an overview of the creature's Behavioral Clues as described in the relevant behemoth table entry. Use these clues in conjunction with the destroyed site result to describe the creature's likely behavior.</p><ul><li><p>Characters with , , or  have  on this roll.</p></li></ul><h4>Outcome</h4><p>If the party successfully identifies both the creature's Physical Clues and Behavioral Clues, they learn the name of the creature, and also discover that creature's Aftermath Loot as described in the relevant behemoth table entry.</p></section>

### Katherim

<section class="block readaloud"><p>The katherim is a towering, six-legged grazer, broad-shouldered and heavy. Its immense weight can ruin fields, walls, and structures simply by passing through them. Though not wantonly destructive, it is stubborn, powerful, and difficult to divert once it has set its course.</p></section>

<section class="block exploration"><h4>Physical Clues</h4><p>Six deep prints appear in a paired sequence, often sunk deepest at the front where the creature bears most of its weight.</p><h4>Behavioral Clues</h4><p>A katherim tends to lumber toward sources of food and water, crashing through obstacles instead of avoiding them; the destruction it wreaks is often incidental to its single-minded goal.</p><h4>Aftermath Loot</h4><p>A tuft of katherim hair, torn from its body by another animal — likely the result of a Gore Bird Swarm, with whom the katherim share a symbiotic relationship. A character <sup class="system-swap-inline"><sub data-system="dnd5e">with Proficiency in  </sub><sub data-system="crucible">that is a capable </sub></sup> can knit the hair into a small charm, such as a bracelet, worth <sup class="system-swap-inline"><sub data-system="dnd5e">25 sp</sub> <sub data-system="crucible">25 cp</sub></sup> .</p><h4>Encounter Loot</h4><p>See the creature's Actor for harvestable materials and other loot.</p></section>

If the characters successfully identify the katherim from the clues it has left behind, mark the following outcome as complete:

### Avir

<section class="block readaloud"><p>Avir are enormous pack-hunting birds, lean and vicious, with hooked beaks, powerful legs, and sharp vision.</p></section>

<section class="block exploration"><h4>Physical Clues</h4><p>Multiple sets of three-toed tracks, deep talon punctures, and tears in wood or thatch; any carcasses present show signs of precise tearing.</p><h4>Behavioral Clues</h4><p>Avir prefer to drive prey in different directions, separating the slow and maiming others to prevent them from escaping. They seem to delight in the chase, prolonging death for as long as possible.</p><h4>Aftermath Loot</h4><p> long, dark avir feathers, streaked with blood. A character with Proficiency in  can sew the feathers into a small charm, such as a bracelet or necklace, worth 25 sp.</p><h4>Encounter Loot</h4><p>See the creature's Actor for harvestable materials and other loot.</p></section>

If the characters successfully identify the avir from the clues they have left behind, mark the following outcome as complete:

### Garganthus

<section class="block readaloud"><p>The garganthus is a pale, hulking reptilian creature with a long prehensile tail, many pearlescent eyes, and massive clawed limbs built for impossible bursts of speed.</p></section>

<section class="block exploration"><h4>Physical Clues</h4><p>Damage appears most heavily on vertical surfaces, with deep claw gouges high on structures or stone faces. There are only intermittent signs of its presence on the ground, as though the creature preferred to leap; long drag marks suggest the use of a long tail.</p><h4>Behavioral Clues</h4><p>Despite its size, the Garganthus moves like a stalking predator, favoring sudden changes of height and direction over a direct charge. Much of its destruction is generated from pouncing atop things, rather than striking them head-on.</p><h4>Aftermath Loot</h4><p>A fragment of the garganthus's claw, worth 25 sp, which can be wielded as a .</p><h4>Encounter Loot</h4><p>See the creature's Actor for harvestable materials and other loot.</p></section>

If the characters successfully identify the garganthus from the clues it has left behind, mark the following outcome as complete:

### Urkon

<section class="block readaloud"><p>The urkon is an ill-tempered and brutish beast of massive proportions, given to direct charges and explosive violence. Wherever it passes, the earth looks rent apart.</p></section>

<section class="block exploration"><h4>Physical Clues</h4><p>The ground is gouged by broad tracks that overlap in straight lines, like furrows torn by many plows. Any stone it contacts is likely covered in spiderweb cracks, and timber objects are pulverized into splinters.</p><h4>Behavioral Clues</h4><p>An Urkon will repeatedly charge the same structure or creature from different angles until its rage is sated, often leaving signs of repeated impacts.</p><h4>Aftermath Loot</h4><p>A fragment of the urkon's tusk, worth 25 sp, which can be wielded as a .</p><h4>Encounter Loot</h4><p>See the creature's Actor for harvestable materials and other loot.</p></section>

If the characters successfully identify the urkon from the clues it has left behind, mark the following outcome as complete:

### Concluding the Event

Once the party has finished surveying the ruined site and gathering any information they can glean from the aftermath, they're free to continue on their journey.

## Overview

While traveling through the Golden Flats, the party comes across a ruined site recently devastated by a Pathways behemoth. By examining the aftermath, they may piece together what kind of colossal creature passed this way.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>The golden grasses ahead have been trampled flat; they bow toward a scene of ruin. Whatever passed through here did so with terrible force, leaving only wreckage in its wake — violence on a scale no ordinary beast could inflict. The marks of destruction are still stark and unmistakable. By examining the ruined site, you may be able to discover what passed this way.</p>
</section>

## Summary

While traveling through the Golden Flats, we came across a site recently devastated by a behemoth from the Pathways. We examined the wreckage for signs of the strange creature responsible.