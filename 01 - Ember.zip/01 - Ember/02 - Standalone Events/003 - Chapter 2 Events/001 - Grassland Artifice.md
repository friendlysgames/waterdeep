# Grassland Artifice

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This social event allows the characters to encounter the agrimage Moriah Foxhaven, whom they've found roaming the Golden Flats with her caravan of beast-riding companions. In this event, the characters can:</p><ul><li><p>Meet Moriah Foxhaven, an Arcturian agrimage from Steed's Point who is known for crafting wondrous items like the Grassland Talisman.</p></li><li><p>Procure a Grassland Talisman from Moriah, which will protect them from Jurtak poison while they traverse Steed's Point.</p></li></ul></section>

### The Wandering Agrimage

With guidance from Rattletrap, the party can locate a roving agrimage on the plains westward of the Eastern River to procure a Grassland Talisman, which should help the characters as they explore the Jurtak-infested reaches of Steed's Point.

The sun-kissed agrimage Moriah Foxhaven lives amongst a group of beast-riding nomads, and is known to fashion these talismans with her arcane craft. Moriah and her companions are happy to welcome the party into their camp for a while if their intentions are pure and their gold or barter is worthy.

<section class="block social"><h4>Meeting the Agrimage</h4><p>Moriah Foxhaven and her community of beast-riding wanderers are used to meeting all sorts of folk on the dusty path to here and there, so the appearance of the party should come as no surprise to the unnamed band of rovers.</p><p>Headstrong and heartfelt, Moriah is quick to strike up conversation with the characters when they arrive, and is willing to discuss the following:</p><ul><li><p>The Grassland Talisman and how it might help the party survive the poisonous Jurtak attacks they've been warned about.</p></li><li><p>More about herself and her beast-riding companions.</p></li><li><p>A brief history about the rise and fall of Steed's Point, with discourse about its most prominent denizens — including Rattletrap, Kali Andrella, and Bertron Steed.</p></li><li><p>A short introduction to agrimagic.</p></li></ul></section>

<section class="block qna"><p class="question">About yourself?</p><div class="answer"><blockquote><p>I'm just a traveler, like yourselves. One who has seen more than her fair share of hardship in too short an amount of time. So I put my agrimagic to good use by cultivating this little community of ours and helping the good people of the Golden Flats when I can.</p></blockquote></div></section>

<section class="block qna"><p class="question">About Agrimagic?</p><div class="answer"><blockquote><p>Agrimagic is an Arcturian tradition I've always studied with pride, not simply because it runs in the family, but due to some longing I've felt since youth. My sorcery stems from Ember itself, and I'm fortunate to be able to give a little magic back to the world from time to time.</p></blockquote></div></section>

<section class="block qna"><p class="question">Steed's Point?</p><div class="answer"><blockquote><p>It started with an earthquake. Then the Jurtak came. Soon, a well-meaning but misguided agrimage — one considerably more powerful than myself — summoned scores of gore birds to stem the saurian tide. Steed's Point was caught up in the fray, and that's how I lost my hometown. I abandoned Steed's Point before it got too dangerous to leave.</p></blockquote></div></section>

<section class="block qna"><p class="question">The Grassland Talisman?</p><div class="answer"><blockquote><p>Nobody deserves to die from the venom on a Jurtak's blade. Thanks to Ember's bounties, I've managed to weave a special magic that wards against the deadly toxin. A Grassland Talisman will certainly help you mitigate the mortal threat of Jurtak poison. But it's magic is fleeting, and it won't save you from a Jurtak geomancer's umbral sorcery.</p></blockquote></div></section>

<section class="block qna"><p class="question">About Jurtak?</p><div class="answer"><blockquote><p>The Jurtak are foul and verminous creatures that hail from the deepest, lightless depths of Ember's Pathways. These aberrations are motivated by little more than sheer cruelty and their carnivorous appetites.</p></blockquote></div></section>

<section class="block exploration"><h4>The Grassland Talisman</h4><p>The so-called Grassland Talisman is a peculiar magic item fashioned by Moriah Foxhaven, utilizing her skills as an agrimage to ward its wearer against the potent poison used by the Jurtak.</p><p>Moriah Foxhaven charges a sum of 50 gp for the consumable item, but can be persuaded to lower the price.</p><p>Any character who succeeds on a  check is able to convince Moriah to sell the item at a discount for 40 gp.</p></section>

## Overview

The party tracks down the wandering agrimage Moriah Foxhaven, who is known for crafting a wondrous item known as a Grassland Talisman. This talisman is rumored to be an effective ward against the deadly poison of the Jurtak that inhabit Steed's Point.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>You spy a caravan of beast riders on the amber plains ahead, with humanoids mounted atop a half-dozen yarnac and other gentle beasts of burden. They amble slowly across the Golden Flats in graceful harmony with each other and the very land they stride upon.</p>
</section>

## Summary

We met the roving agrimage Moriah Foxhaven, from whom we procured a Grassland Talisman. The wondrous item should provide us with a measure of protection against the deadly Jurtak poison we'll encounter in Steed's Point.