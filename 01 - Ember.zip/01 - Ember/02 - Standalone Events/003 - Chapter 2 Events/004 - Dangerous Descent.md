# Dangerous Descent

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This Exploration Event can occur while traveling into the Splinter Canyons from the Golden Flats. In this Event, the party can:</p><ul><li><p>Demonstrate their wilderness survival skills by preparing for and charting a course down the perilous cliff face.</p></li><li><p>Potentially overcome one or more hazards.</p></li></ul><h4>Stages of Descent</h4><p>The canyon wall is 360 feet tall. The party must complete three stages of descent in order to reach the canyon floor; each stage represents approximately 120 feet of movement and takes approximately 1 hour. The stages of descent are:</p><ul><li><p>Stage 1: Charting a Course</p></li><li><p>Stage 2: Making the Descent</p></li><li><p>Stage 3: Reaching the Canyon Floor</p></li></ul></section>

Each stage represents a group check Group Check — if at least half of the characters succeed, they proceed to the next stage of descent without incident. If over half of the characters fail, however, roll on the Climbing Hazards table. After resolving the hazard, the party proceeds to the next stage.

<section class="block exploration"><h4>Making Preparations</h4><p>Before embarking on the journey, the party may describe any preparations they're making for the climb. Appropriate tools, equipment, magic, or other precautions may grant  or automatic success on a relevant roll, per the Gamemaster's discretion.</p><p>Such preparations may include: rope, pitons, climbing gear, anchored vines, magical flight, or any other sensible method of descent.</p></section>

### Stage 1: Charting a Course

<section class="block exploration"><h4>Stage 1: Chart a Course</h4><p>The characters must first identify a safe path down the canyon wall with a group skill challenge. Every member of the party must make one of the following tests:</p><div class="system-swap-block"><div data-system="dnd5e"><ul><li><p>A successful  check to clamber down the thick vines cascading down the cliff face.</p></li><li><p>A successful  check to carefully edge across a series of narrow ledges and shallow footholds that pockmark the cliff face.</p></li></ul></div><div data-system="crucible"><ul><li><p>A successful  check to identify a navigable way down the thick vines cascading down the cliff face.</p></li><li><p>A successful  check to determine the best course carefully edging across a series of narrow ledges and shallow footholds that pockmark the cliff face.</p></li></ul></div></div><p>If the group check is failed, roll on the Climbing Hazards table.</p></section>

<section class="block hazard"><h4>Stage 1: Falling</h4><div class="system-swap-block"><div data-system="dnd5e"><p>Characters that fall from the effects of a Climbing Hazard fall 360 feet, taking ( damage) and landing &amp;reference[Prone].</p></div><div data-system="crucible"><p>Characters that fall from the effects of a Climbing Hazard fall 360 feet, suffering a {Terminal Fall} and landing .</p></div></div></section>

### Stage 2: Making the Descent

<section class="block exploration"><h4>Stage 2: Making the Descent</h4><p>The characters must next traverse the most dangerous portion of the climb with a group skill challenge. Every member of the party must make one of the following tests:</p><div class="system-swap-block"><div data-system="dnd5e"><ul><li><p>A successful  check to use their strength and leverage, performing the heavy lifting across difficult stretches and securing handholds for their companions.</p></li><li><p>A successful  check to use their agility and balance to trailblaze nimbly across narrow ledges, ensuring a steady footing for their companions.</p></li></ul></div><div data-system="crucible"><ul><li><p>A successful  check to use their strength and leverage, performing the heavy lifting across difficult stretches and securing handholds for their companions.</p></li><li><p>A successful  check to use their agility and balance to trailblaze nimbly across narrow ledges, ensuring a steady footing for their companions.</p></li></ul></div></div><p>If the group check is failed, roll on the Climbing Hazards table.</p></section>

<section class="block hazard"><h4>Stage 2: Falling</h4><div class="system-swap-block"><div data-system="dnd5e"><p>Characters that fall from the effects of a Climbing Hazard fall 240 feet, taking ( damage) and landing &amp;reference[Prone].</p></div><div data-system="crucible"><p>Characters that fall from the effects of a Climbing Hazard fall 240 feet, suffering {Critical Fall} and landing .</p></div></div></section>

### Stage 3: Reaching the Canyon Floor

<section class="block exploration"><h4>Stage 3: Reaching the Canyon Floor</h4><p>The party must succeed on a final <sup class="system-swap-inline"><sub data-system="dnd5e"></sub><sub data-system="crucible"></sub></sup> group check to withstand the grueling demands of the extended descent to safely reach the canyon floor below.</p><p>If the group check is failed, roll on the Climbing Hazards table.</p></section>

<section class="block hazard"><h4>Stage 3: Falling</h4><div class="system-swap-block"><div data-system="dnd5e"><p>Characters that fall from the effects of a Climbing Hazard fall 120 feet, taking ( damage) and landing &amp;reference[Prone].</p></div><div data-system="crucible"><p>Characters that fall from the effects of a Climbing Hazard fall 120 feet, suffering {Deadly Fall} and landing .</p></div></div></section>

### Climbing Hazards

### Concluding the Event

Once the party has reached the floor of the Splinter Canyons, they're free to continue on their journey.

## Overview

While traveling along the edge of the Splinter Canyons, the party is confronted with a difficult choice: brave a perilous climb down the cliff face, or seek a safer ingress elsewhere at the expense of time.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>Up close, the descent into the Splinter Canyons is steeper than it first appeared. Curtains of vine sway against broken stone, and the rattle of rock and small puffs of dust mark places where the cliff face is already giving way. You may be able to climb down, but doing so safely will require preparation and care.</p>
</section>

## Summary

While descending into the Splinter Canyons from the Golden Flats, we undertook a perilous climb down the cliff face. Though the journey was fraught with danger, we eventually reached the canyon floor below.