# Flash Flood

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This Exploration Event can occur while traveling through the Splinter Canyons on any river-adjacent hex or hex containing a river. In this Event, the party can:</p><ul><li><p>Demonstrate their wilderness survival skills by withstanding a deadly flash flood.</p></li></ul><p>The flash flood occurs over the course of 10 minutes, affecting all hexes inside the Splinter Canyons and escalating in intensity every 5 minutes. This event is more likely to occur if the party is traveling at a Fast or Reckless pace. Once the Event has occurred, it cannot occur again for at least 48 hours.</p><h4>Stages of Flooding</h4><p>The party must survive two stages of flooding:</p><ul><li><p>Stage 1: Rising Waters</p></li><li><p>Stage 2: Canyon Rapids</p></li></ul><p>Each stage represents a <sup class="system-swap-inline"><sub data-system="dnd5e">group check </sub><sub data-system="crucible">Group Check</sub></sup> — if at least half of the characters succeed, they proceed to the next stage of flooding without incident. If over half of the characters fail, however, roll on the Rushing Water Perils table. After resolving the hazard, the party proceeds to the next stage of flooding.</p></section>

At the beginning of each stage, the party may describe any tools they're utilizing to aid them.

<section class="block exploration"><h4>Preparedness</h4><p>Appropriate tools, equipment, magic, or other precautions may grant  on a relevant roll or an automatic success, per the Gamemaster's discretion.</p><p>Such preparations may include: pitons, magical flight, floatation devices, spells <sup class="system-swap-inline"><sub data-system="dnd5e">such as Control Water</sub><sub data-system="crucible">that can be used to control water</sub></sup>, or any other sensible method of withstanding rushing water.</p></section>

### Stage 1: Rising Waters

<section class="block readaloud"><p>The river in the crevasse swells, drawing even with its banks. Though the waters look calm, they are rapidly intensifying by the minute. Even now, rivulets begin pooling beneath you and spilling through well-worn channels toward the canyon walls. It won't be long until the entire canyon is overcome by white-foamed rapids.</p></section>

<section class="block exploration"><h4>Stage 1: Rising Waters</h4><p>The characters must react to the rising floodwaters before they overtake the canyon floor with a group skill challenge. Every member of the party must make one of the following tests:</p><div class="system-swap-block"><div data-system="dnd5e"><ul><li><p>A successful  check to pull themselves onto firmer footing, secure a handhold, or brace themselves against a perpendicular surface to withstand the oncoming surge.</p></li><li><p>A successful  check to stay ahead of the spillover, darting across slick ground before the flood closes around them.</p></li></ul></div><div data-system="crucible"><ul><li><p>A successful  check to pull themselves onto firmer footing, secure a handhold, or brace themselves against a perpendicular surface to withstand the oncoming surge.</p></li><li><p>A successful  check to stay ahead of the spillover, darting across slick ground before the flood closes around them.</p></li></ul></div></div><p>If the group check is failed, roll on the Rushing Water Perils table.</p></section>

### Stage 2: Canyon Rapids

<section class="block readaloud"><p>The river picks up speed, roaring through the canyons as a churn of white-foamed wrath; the water has swelled all the way to the canyon walls. It fills the canyon with a deafening rush. Branches, debris, and a few small, unlucky beasts caught in the flood's path are dashed against the cliff face and vanish beneath the white, borne swiftly to their deaths.</p></section>

<section class="block exploration"><h4>Stage 2: Canyon Rapids</h4><p>The characters must struggle to survive the canyon rapids without being swept away with a group skill challenge. Every member of the party must make one of the following tests:</p><div class="system-swap-block"><div data-system="dnd5e"><ul><li><p>A successful  check to use their strength to cling to vines, roots, or stone outcroppings, withstanding the torrent by brute force.</p></li><li><p>A successful  check to move with the rushing water rather than against it, keeping their footing or timing their movements to avoid debris, sudden drops, and the worst of the current.</p></li></ul></div><div data-system="crucible"><ul><li><p>A successful  check to use their strength to cling to vines, roots, or stone outcroppings, withstanding the torrent by brute force.</p></li><li><p>A successful  check to move with the rushing water rather than against it, keeping their footing or timing their movements to avoid debris, sudden drops, and the worst of the current.</p></li></ul></div></div><p>If the group check is failed, roll on the Rushing Water Perils table.</p></section>

### Rushing Water Perils

<section class="block hazard"><h4>Drowning</h4><p>A character that is forced beneath the water from the effects of a Rushing Water Peril begins to &amp;Reference[Suffocation]{Suffocate}. The number of minutes the creature Suffocates is determined by the table result.</p></section>

### Concluding the Event

The flash flood rapidly subsides, allowing the characters to regroup, recover, and continue on their journey.

## Overview

While traveling through the Splinter Canyons along the river, the party is overtaken by a sudden flash flood that threatens to sweep them downstream — or drown them where they stand.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>You feel a tremor in the earth, a deep vibration, like something breaking free. Seconds later, a geyser of steaming water erupts from beneath the river upstream of your position. Then another. And another. One by one, a cascading line of superheated geysers disgorges its contents into the Splinter Canyons. You can do nothing but watch as the water begins to rise with startling speed.</p>
</section>

## Summary

While traveling through the Splinter Canyons along the river, we were overtaken by a devastating flash flood that filled the entire canyon. We managed to survive by strength and wit, but the ordeal did not leave us unscathed.