# Shent Observatory

<section class="block gamemaster"><h4>Gamemaster's Summary</h4><p>This Exploration and Combat Event can occur while traveling through the Rustvar Valleys. In this Event, the party can:</p><ul><li><p>Investigate a ruined observatory once used by the Shent to study cosmological forces, and later repurposed by Arcturians as a barrow.</p></li><li><p>Realign its rusting instrument to reveal a treasure cache.</p></li><li><p>Fend off a group of undead warriors that rise to defend the site.</p></li></ul></section>

### Exploring the Observatory

The observatory lies in ruin atop a stone outcropping. A broad stepped platform dominates the site, crumbling around a mechanism half-buried in mossy rubble.

<section class="block exploration"><h4>Identifying the Ruin</h4><p>Characters with , , or Proficiency in  identify the site as a ruined Shent observatory, and can estimate its age as approximately 3,000 years old.</p><p> characters, characters with  or , and characters with Proficiency in  identify markers — burial niches and engraved funerary script — that suggest the site was used, or later repurposed, as a barrow by early Arcturian settlers. They can estimate the age of these markers as approximately 1,000 years old.</p><p>Characters who make a successful  check recognize the engraved funerary script as ritualized Gentle Repose spells, though their magic has long since faded.</p></section>

When a character inspects the stepped platform, read or paraphrase the following:

<section class="block readaloud"><p>The faded stepped platform is scored with weathered carvings, though much of it still lies beneath rubble and overgrowth. The lengths of metal jutting from its surface sway with the wind, and their slow movement sends a faint grinding sound through the stone.</p></section>

<section class="block exploration"><h4>Investigating the Stepped Platform</h4><p>Any character who makes a successful  check while examining the stepped platform determines that the rusting metal arms were once part of a larger astronomical mechanism. Most still rest in deliberate relation to the carvings on the stone, but one has long since slipped from its proper alignment.</p><ul><li><p>Characters with , characters who can understand , and characters who identified the ruin as an observatory automatically succeed on this check.</p></li></ul><h4>Restoring the Mechanism</h4><p>A character who understands the stepped platform's function may attempt to force the unaligned metal arm into alignment by making a  check. On a failure, the arm groans and shifts, but does not lock into place. On a success, the mechanism settles into place with a heavy clunk, a hidden compartment grinds open at the base of the stepped platform, and the interred dead stir to life.</p><p>If the characters attempt to move the arm three separate times and fail each time, the arm snaps off but jams partially into place, forcing the hidden compartment halfway open and triggering the skallith encounter. The cache can then be excavated over the course of 1 hour using appropriate tools, such as Mason's Tools.</p><h4>The Funerary Cache</h4><p>Inside the hidden compartment lies a sealed funerary cache placed there by ancient Arcturian settlers: a collection of ritual objects once used to prepare and honor the dead. The cache is a large, lacquered wood chest that contains the following:</p><ul><li><p>A bronze funerary mask with severe expression, covered in verdigris and wrapped in stiff linen cloth (worth ).</p></li><li><p>A Spell Scroll of Gentle Repose, featuring the same funerary script present on the ruins.</p></li><li><p>A bronze urn engraved with ancient Arcturian ritual symbols and covered in verdigris, containing trace amounts of foul-smelling oil (worth ).</p></li><li><p>An ancient Arcturian Funerary Ritual Garb.</p></li><li><p>A linen bundle of 20 Tallow Candles, rancid with age.</p></li><li><p>Dried herbs that crumble at the touch.</p></li></ul></section>

<section class="block attunement signara"><h4>Signara Attunement: Funerary Cache Found</h4><p>If the party discovers the funerary cache, they advance their  at the conclusion of the event.</p></section>

### Rising Skallith

When the mechanism locks into place, read or paraphrase the following:

<section class="block readaloud"><p>The metal arm settles into alignment with a deep, grinding scream. For a moment, nothing happens. Then a deeper groan rattles through the ruin; dust spills from the seams cut through the stonework, and old niches grind open, exhaling air that smells of death. Something buried here is beginning to stir.</p></section>

<section class="block hazard"><h4>Skallith Numbers</h4><p>There are 4 Skallith and 3 Skallith Warriors.</p><h4>Skallith Tactics</h4><p>As undead, the skallith prioritize the closest enemy they can see, with no regard for tactical optimization beyond what weapon can strike their target.</p><h4>Fight or Flight</h4><p>The skallith fight until destroyed.</p><p>If the party chooses to flee, the skallith pursue, but not past the edges of the Scene.</p></section>

### Concluding the Event

Once the party has defeated the skallith and finished exploring the Shent observatory, they're free to continue on their journey.

## Overview

The party discovers a crumbling observatory left behind by the mysterious Shent, later reappropriated by early Arcturian settlers as a barrow. Investigating the observatory's ruined mechanisms may reveal a hidden treasure, but doing so risks awakening the interred dead.

<section class="block read-aloud">
<h4>Read Aloud</h4>
<p>A scatter of broken stone crowns the rise ahead, overgrown with brush and thorned vines. At the center stands a broad, stepped ruin of faded rock, surrounded by smaller squat structures that lean at odd angles; several have fallen into rubble at the base of the outcropping. Lengths of rusting metal jut from the central platform, and narrow seams divide the stonework in careful lines, as though sections of the ruin were made to open. Whatever purpose this place once served, it has stood empty for a very long time.</p>
</section>

## Summary

While traveling through the Rustvar Valleys, we discovered a ruin perched atop a rocky outcropping.